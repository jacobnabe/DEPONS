/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.agents.misc;

import java.awt.Color;

import dk.au.bios.porpoise.Agent;
import dk.au.bios.porpoise.CellData;
import dk.au.bios.porpoise.Globals;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.continuous.NdPoint;
import repast.simphony.space.grid.Grid;
import repast.simphony.space.grid.GridPoint;

/**
 * Utility-agent to display the distance to the coast based on the CellData. This is the most efficient way to display
 * the image. The agent does not perform any tasks beyond being displayed.
 */
public class CellDataDistToCoastAgent extends Agent {

	private static final Color LAND_COLOR = new Color(0.921f, 0.886f, 0.854f);

	private CellData data;

	private double minValue = Double.MAX_VALUE;
	private double maxValue = Double.MIN_VALUE;

	public CellDataDistToCoastAgent(ContinuousSpace<Agent> space, Grid<Agent> grid, CellData data) {
		super(space, grid, 0);
		this.data = data;

		for (int x = 0; x < Globals.WORLD_WIDTH; x++) {
			for (int y = 0; y < Globals.WORLD_HEIGHT; y++) {
				double val = data.getDistanceToCoast(x, y);
				if (val > maxValue) {
					maxValue = val;
				} else if (val < minValue && val > 0.00000f) { // Should really use the NODATA_value instead
					minValue = val;
				}
			}
		}
		System.out.println("CellDataDistToCoastAgent : " + minValue + " - " + maxValue);
	}

	public void initialize() {
		setPosition(new NdPoint(Globals.WORLD_WIDTH / 2, Globals.WORLD_HEIGHT / 2));
	}

	public int getPointRGB(int x, int y) {
		int realY = Globals.WORLD_HEIGHT - y - 1;

		double val = data.getDistanceToCoast(x, realY);
		if (val > 0.0000000f) {
			Color color = Color.RED;
			int alpha = 255;
			double pctInRange = (val - minValue) / maxValue;
			alpha *= pctInRange;
			if (alpha < 1) {
				alpha = 1;
			}
//			if (pctInRange < 0.0001f) {
//				alpha = 0;
				System.out.println("CellDataDistToCoastAgent : " + val + " (" + pctInRange + " / " + alpha + ")");
//			}
			return color.getRGB() + (alpha << 24);
		} else {
//			System.out.println("CellDataDistToCoastAgent : " + val +  " (LAND)");
			return LAND_COLOR.getRGB();
		}

	}

}
