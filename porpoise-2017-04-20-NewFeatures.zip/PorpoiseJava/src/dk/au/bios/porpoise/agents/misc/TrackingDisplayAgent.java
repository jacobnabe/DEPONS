/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.agents.misc;

import java.awt.Color;
import java.awt.image.BufferedImage;

import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.continuous.NdPoint;
import repast.simphony.space.grid.Grid;

import com.aragost.repast.ui.DirtyRegion;

import dk.au.bios.porpoise.Agent;
import dk.au.bios.porpoise.Globals;

/**
 * A helper-agent to display the cells visited by a tracked porpoise (RandomPorpoiseReportProxy) 
 */
public class TrackingDisplayAgent extends Agent {

	private BufferedImage img;
	private DirtyRegion dr = new DirtyRegion(Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT, 0, 0);

	public TrackingDisplayAgent(ContinuousSpace<Agent> space, Grid<Agent> grid, long id) {
		super(space, grid, id);
		img = new BufferedImage(Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT, BufferedImage.TYPE_INT_ARGB);
	}

	public void initialize() {
		setPosition(new NdPoint(Globals.WORLD_WIDTH / 2, Globals.WORLD_HEIGHT / 2));
	}

	public BufferedImage getImage() {
		return img;
	}

	public void visited(int x, int y, int visitType) {
		Color c;
		if (visitType == 2) {
			c = Color.DARK_GRAY; // PSM active
		} else if (visitType == 1) {
			c = Color.RED; // standard move
		} else {
			c = Color.MAGENTA; // Unknown visit!
		}
		if (x < img.getWidth() && y > 0 && y < img.getHeight()) { // Bounds-check for cases of "rounding" issues
			img.setRGB(x, img.getHeight() - y, c.getRGB());
			synchronized (dr) {
				dr.markPoint(x, img.getHeight() - y);
			}
		}
	}

	public DirtyRegion getDirtyRegion() {
		return dr;
	}

}
