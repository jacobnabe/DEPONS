/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise;

import repast.simphony.engine.environment.RunEnvironmentBuilder;
import repast.simphony.scenario.ModelInitializer;
import repast.simphony.scenario.Scenario;

/**
 * Model initializer. This is not currently doing anything but was used for testing some custom Data Sinks. The file is
 * retained in case this will be pursued further in the future.
 */
public class PorpoiseInitializer implements ModelInitializer {

	// private static final String DS_RANDOM_PORPOISE = "Random Porpoise";
	// private static final String DS_STATS = "Sim stats";
	// private static final int TICKS_PER_DAY = 48;

	@Override
	public void initialize(Scenario scenario, RunEnvironmentBuilder builder) {

		/* TODO: Enable. Disabled due to batch problem.
		RSApplication.getRSApplicationInstance().addCustomUserPanel(Globals.USER_PANEL);
		
		scenario.addMasterControllerAction(new NullAbstractControllerAction<Object>() {

//			private CSVFileDataSink randomPorpoiseDataSink;
//			private CSVFileDataSink statisticsDataSink;
			private DataSetBuilder<?> statisticsBuilder;

//			private List<BatchParamMapFileWriter> writers = new ArrayList<BatchParamMapFileWriter>();

			@Override
			public void runInitialize(RunState runState,
					Context<? extends Object> context, Parameters runParams) {
				super.runInitialize(runState, context, runParams);

//				Boolean logStats = runParams.getBoolean("logStatistics");
//				if (logStats != null && logStats) {
//					int statsOffset = runParams.getInteger("logStatisticsOffset") * TICKS_PER_DAY;
//					int statsInterval = runParams.getInteger("logStatisticsInterval") * TICKS_PER_DAY;

					int statsOffset = runParams.getInteger("logStatisticsOffset");
					int statsInterval = runParams.getInteger("logStatisticsInterval");
					ScheduleParameters sp = ScheduleParameters.createRepeating(statsOffset, statsInterval);
					statisticsBuilder.defineScheduleParameters(sp, false);

//					statisticsDataSink.setEnabled(true);
//				}

//				randomPorpoiseDataSink.setEnabled(runParams.getBoolean("logRandomPorpoise"));
//
//				for (BatchParamMapFileWriter writer : writers) {
//					writer.runStarted();
//				}
			}
			*/

			/**
			 * Called during initialization. Despite the name, this also happens during a "normal" run.
			 */
		    /* TODO: Enable. Disabled due to batch problem.
			@Override
			public void batchInitialize(RunState runState, Object contextId) {
				
				/* TODO: Enable. Disabled due to batch problem.
				DataSetRegistry registry = (DataSetRegistry) runState
						.getFromRegistry(DataConstants.REGISTRY_KEY);
				DataSetManager manager = registry.getDataSetManager(contextId);

//				SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMdd-HHmmss");
//				String timeStamp = fmt.format(new Date());

//				FileNameFormatter fnFormatter = new FileNameFormatter("Statistics.csv", true);

				statisticsBuilder = manager.getDataSetBuilder(DS_STATS);
//				statisticsDataSink = new CSVFileDataSink(fnFormatter.getFilename());
//				statisticsBuilder.addDataSink(statisticsDataSink);
//
//				DataSetBuilder<?> porpoiseBuilder = manager.getDataSetBuilder(DS_RANDOM_PORPOISE);
//				randomPorpoiseDataSink = new CSVFileDataSink("RandomPorpoise" + "_" + timeStamp + ".csv");
//				porpoiseBuilder.addDataSink(randomPorpoiseDataSink);
//				
//				if (runState.getRunInfo().isBatch()) {
//					BatchParamMapFileWriter writer = new BatchParamMapFileWriter(
//							manager.getBatchRunDataSource(), fnFormatter,
//							";", FormatType.TABULAR);
//					statisticsBuilder.addDataSink(writer);
//					writers.add(writer);
//				}
 

			}

			@Override
			public String toString() {
				return "DataSink initializer";
			}

//			@Override
//			public void batchCleanup(RunState runState, Object contextId) {
//			    writers.clear();
//			}
			

		});
		
*/
	}

}
