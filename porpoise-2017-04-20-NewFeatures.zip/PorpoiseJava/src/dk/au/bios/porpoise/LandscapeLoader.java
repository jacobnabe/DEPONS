/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise;

import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import repast.simphony.space.grid.GridPoint;
import dk.au.bios.porpoise.util.ASCUtil;
import dk.au.bios.porpoise.util.BlockQuarterCalculator;

/**
 * Loads the landscape data files and returns a CellData instance.
 */
public class LandscapeLoader {

	private final String dataPath;

	public LandscapeLoader() {
		dataPath = "data";
	}

	public LandscapeLoader(String dataPath) {
		this.dataPath = dataPath;
	}

	public CellData load(String landscape, boolean onDemandFood) {
		CellData cellData;
		try {
			if (Globals.HOMOGENOUS) {
				landscape = "Homogeneous";
			}

			String landScapeDataPath = dataPath + "/" + landscape;

			Future<double[][]> distance = ASCUtil.loadDoubleAscFileTask(Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT,
					landScapeDataPath + "/disttocoast.asc", false);
			Future<double[][]> depth = ASCUtil.loadDoubleAscFileTask(Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT,
					landScapeDataPath + "/bathy.asc", false);
			Future<double[][]> block = ASCUtil.loadDoubleAscFileTask(Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT,
					landScapeDataPath + "/blocks.asc", true);
			Future<double[][]> foodProb = ASCUtil.loadDoubleAscFileTask(Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT,
					landScapeDataPath + "/patches.asc", false);

			Future<double[][]> quarter1;
			Future<double[][]> quarter2;
			Future<double[][]> quarter3;
			Future<double[][]> quarter4;
			if (Globals.HOMOGENOUS) {
				quarter1 = ASCUtil.loadDoubleAscFileTask(Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT, landScapeDataPath
						+ "/quarter1.asc", false);
				quarter2 = ASCUtil.loadDoubleAscFileTask(Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT, landScapeDataPath
						+ "/quarter1.asc", false);
				quarter3 = ASCUtil.loadDoubleAscFileTask(Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT, landScapeDataPath
						+ "/quarter1.asc", false);
				quarter4 = ASCUtil.loadDoubleAscFileTask(Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT, landScapeDataPath
						+ "/quarter1.asc", false);
			} else {
				quarter1 = ASCUtil.loadDoubleAscFileTask(Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT, landScapeDataPath
						+ "/quarter1.asc", false);
				quarter2 = ASCUtil.loadDoubleAscFileTask(Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT, landScapeDataPath
						+ "/quarter2.asc", false);
				quarter3 = ASCUtil.loadDoubleAscFileTask(Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT, landScapeDataPath
						+ "/quarter3.asc", false);
				quarter4 = ASCUtil.loadDoubleAscFileTask(Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT, landScapeDataPath
						+ "/quarter4.asc", false);
			}
			boolean[][] mask = ASCUtil.loadBooleanAscFile(Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT, dataPath + "/"
					+ landscape + "/mask.asc");

			Future<GridPoint[]> bc = BlockQuarterCalculator.getBlockCenters(block);

			if (Globals.HOMOGENOUS) {
				Globals.BLOCK_VAL_Q1 = Globals.BLOCK_VAL_Q2 = Globals.BLOCK_VAL_Q3 = Globals.BLOCK_VAL_Q4 = new double[] {
						1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
						1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };
			} else {
				Future<double[]> q1 = BlockQuarterCalculator.calculateBlockVal(block, quarter1, mask, depth);
				Future<double[]> q2 = BlockQuarterCalculator.calculateBlockVal(block, quarter2, mask, depth);
				Future<double[]> q3 = BlockQuarterCalculator.calculateBlockVal(block, quarter3, mask, depth);
				Future<double[]> q4 = BlockQuarterCalculator.calculateBlockVal(block, quarter4, mask, depth);

				Globals.BLOCK_VAL_Q1 = q1.get();
				Globals.BLOCK_VAL_Q2 = q2.get();
				Globals.BLOCK_VAL_Q3 = q3.get();
				Globals.BLOCK_VAL_Q4 = q4.get();
			}

			// TODO: Make this wait a bit nicer, avoid all the .get calls here and in thew CellData constructor
			cellData = new CellData(distance, depth, block, foodProb, quarter1, quarter2, quarter3, quarter4,
					onDemandFood, mask, onDemandFood);
			if (!onDemandFood) {
				cellData.initializeFoodPatches().get();
			}

			Globals.BLOCK_CENTRES = bc.get();
		} catch (IOException | ExecutionException | InterruptedException e) {
			throw new RuntimeException(e);
		}

		return cellData;
	}

}
