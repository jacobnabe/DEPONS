/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise;

import java.awt.Color;

import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.continuous.NdPoint;
import repast.simphony.space.grid.Grid;
import repast.simphony.space.grid.GridPoint;

/**
 * Utility-agent to display the background image. This is the most efficient way to display the background image. The
 * agent does not perform any tasks beyond being displayed.
 */
public class BackgroundAgent extends Agent {

	private static final Color LAND_COLOR = new Color(0.921f, 0.886f, 0.854f);
	private static final Color[] SHADES_OF_BLUE = new Color[120];

	private static double GROWN_FOOD;

	private CellData data;

	private double minValue = Double.MAX_VALUE;
	private double maxValue = Double.MIN_VALUE;
	private double rangeDiv;

	public BackgroundAgent(ContinuousSpace<Agent> space, Grid<Agent> grid, CellData data) {
		super(space, grid, 0);
		this.data = data;

		for (int x = 0; x < Globals.WORLD_WIDTH; x++) {
			for (int y = 0; y < Globals.WORLD_HEIGHT; y++) {
				double val = data.getDepth(new GridPoint(x, y));
				if (val > maxValue) {
					maxValue = val;
				} else if (val < minValue && val > 0.00000f) { // Should really use the NODATA_value instead
					minValue = val;
				}
			}
		}

		double range = maxValue - minValue;
		rangeDiv = range / SHADES_OF_BLUE.length;

		// Calculate shades
		for (int i = 0; i < SHADES_OF_BLUE.length; i++) {
			float factor = ((SHADES_OF_BLUE.length - i) * (0.6f / SHADES_OF_BLUE.length));
			SHADES_OF_BLUE[i] = Color.getHSBColor(0.64f, 1.0f - factor, 0.75f);
		}
	}

	public void initialize() {
		setPosition(new NdPoint(Globals.WORLD_WIDTH / 2, Globals.WORLD_HEIGHT / 2));
	}

	public int getPointRGB(int x, int y) {
		int realY = Globals.WORLD_HEIGHT - y - 1;
		boolean masked = data.isPointMasked(x, realY);

		double val = data.getDepth(new GridPoint(x, realY));
		Color color;
		if (val >= 0.0000f) {
			int idx = (int) Math.round((val - minValue) / rangeDiv);
			if (idx > SHADES_OF_BLUE.length - 1) {
				idx = SHADES_OF_BLUE.length - 1;
			}
			color = SHADES_OF_BLUE[idx];

		} else {
			color = LAND_COLOR;
		}

		if (masked && color != LAND_COLOR) {
			return alphaBlend(color, Color.MAGENTA, 150).getRGB();
		} else {
			return color.getRGB();
		}
	}

	private Color alphaBlend(Color c1, Color c2, int alpha) {
		int r = (c1.getRed() * alpha + c2.getRed() * (255 - alpha)) / 255;
		int g = (c1.getGreen() * alpha + c2.getGreen() * (255 - alpha)) / 255;
		int b = (c1.getBlue() * alpha + c2.getBlue() * (255 - alpha)) / 255;
		return new Color(r, g, b);
	}

	public double getGrownFood() {
		return BackgroundAgent.GROWN_FOOD;
	}

	public static void setGrownFood(double grownFood) {
		BackgroundAgent.GROWN_FOOD = grownFood;
	}

}
