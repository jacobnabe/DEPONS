/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import repast.simphony.context.Context;
import repast.simphony.context.space.continuous.ContinuousSpaceFactory;
import repast.simphony.context.space.continuous.ContinuousSpaceFactoryFinder;
import repast.simphony.context.space.grid.GridFactory;
import repast.simphony.context.space.grid.GridFactoryFinder;
import repast.simphony.dataLoader.ContextBuilder;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.engine.schedule.IAction;
import repast.simphony.engine.schedule.ISchedule;
import repast.simphony.engine.schedule.ScheduleParameters;
import repast.simphony.parameter.Parameters;
import repast.simphony.space.continuous.BouncyBorders;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.continuous.NdPoint;
import repast.simphony.space.continuous.PointTranslator;
import repast.simphony.space.continuous.RandomCartesianAdder;
import repast.simphony.space.grid.Grid;
import repast.simphony.space.grid.GridBuilderParameters;
import repast.simphony.space.grid.GridPoint;
import repast.simphony.space.grid.SimpleGridAdder;
import repast.simphony.space.grid.WrapAroundBorders;
import repast.simphony.valueLayer.GridValueLayer;
import dk.au.bios.porpoise.agents.misc.TrackingDisplayAgent;
import dk.au.bios.porpoise.behavior.FastRefMemTurn;
import dk.au.bios.porpoise.behavior.GeneratedRandomSource;
import dk.au.bios.porpoise.behavior.RefMemTurnCalculator;
import dk.au.bios.porpoise.behavior.ReplayedRandomSource;
import dk.au.bios.porpoise.tasks.AddTrackedPorpoisesTask;
import dk.au.bios.porpoise.tasks.DailyTask;
import dk.au.bios.porpoise.tasks.DeterenceTask;
import dk.au.bios.porpoise.tasks.FoodTask;
import dk.au.bios.porpoise.tasks.MonthlyTasks;
import dk.au.bios.porpoise.tasks.YearlyTask;
import dk.au.bios.porpoise.util.LogisticDecreaseSSLogis;
import dk.au.bios.porpoise.util.Pair;
import dk.au.bios.porpoise.util.test.PorpoiseTestDataCapturer;

/**
 * Constructs the Context for the simulation. This includes setting up the space and grid, loading the environment and
 * creating the various agents.
 */
public class PorpoiseSimBuilder implements ContextBuilder<Agent> {

	@Override
	public Context<Agent> build(Context<Agent> context) {
		Globals.CONTEXT = context;
		context.setId("PorpoiseSim");

		// Currently disabled - Globals.initPSMVerificationOutput();

		Parameters params = RunEnvironment.getInstance().getParameters();
		PorpoiseTestDataCapturer.capture(params);

		if (Globals.RANDOM_REPLAY_SOURCE != null) {
			Globals.RANDOM_SOURCE = new ReplayedRandomSource(Globals.RANDOM_REPLAY_SOURCE);
		} else {
			Globals.RANDOM_SOURCE = new GeneratedRandomSource(params);
		}
		// Disabled, enable to capture replay output
		// setupReplay();

		Globals.INERTIA_CONST = params.getDouble("k");
		Globals.CORR_LOGMOV = params.getDouble("a");
		Globals.CORR_ANGLE = params.getDouble("b");
		Globals.DETERRENCE_COEFF = params.getDouble("c");
		Globals.M = Math.pow(10, params.getDouble("m"));
		Globals.DETER_RESPONSE_THRESHOLD = params.getDouble("RT");
		Globals.DETER_DECAY = params.getDouble("Psi_deter");
		Globals.DETER_MAX_DISTANCE = params.getDouble("dmax_deter") * 1000; // entered in KM but stored in meters.
		Globals.MEAN_DISP_DIST = params.getDouble("ddisp");
		Globals.MAX_MOV = params.getDouble("dmax_mov");
		Globals.E_USE_PER_30_MIN = params.getDouble("Euse");
		Globals.E_LACT = params.getDouble("Elact");
		Globals.E_WARM = params.getDouble("Ewarm");
		Globals.N_DISP_TARGET = 12; // Hardcoded value - params.getInteger("q"); 
		Globals.DETER_TIME = params.getInteger("tdeter");
		Globals.MAX_U = 1; // Hardcoded value - params.getDouble("Umax");
		Globals.MIN_DISP_DEPTH = params.getDouble("wdisp");
		Globals.MIN_DEPTH = params.getDouble("wmin");
		Globals.X_SURVIVAL_PROB_CONST = params.getDouble("beta");
		Globals.CONCEIVE_PROB = params.getDouble("h");
		Globals.GESTATION_TIME = params.getInteger("tgest");
		Globals.NURSING_TIME = params.getInteger("tnurs");
		Globals.MAX_AGE = params.getDouble("tmaxage");
		Globals.MATURITY_AGE = params.getDouble("tmature");
		Globals.REGROWTH_FOOD_QUALIFIER = params.getDouble("Umin");
		Globals.MAX_DIST_TO_TARGET = 0; // Hardcoded value - params.getDouble("maxDispersalDistance");
		Globals.PSM_PREFERRED_DISTANCE_TOLERANCE = params.getDouble("PSM_tol");
		Globals.PSM_TYPE2_RANDOM_ANGLE = params.getDouble("PSM_angle");

		String psmLog = params.getString("PSM_log");
		String[] psmLogDecrease = psmLog.split(";");
		if (psmLogDecrease.length == 1) {
			double phi1 = 1.0;
			double phi2 = 0.0;
			double phi3 = Double.parseDouble(psmLogDecrease[0]);
			Globals.PSM_LOGISTIC_DECREASE_FUNCTION = new LogisticDecreaseSSLogis(phi1, phi2, phi3);
		} else if (psmLogDecrease.length == 3) {
			double phi1 = Double.parseDouble(psmLogDecrease[0]);
			double phi2 = Double.parseDouble(psmLogDecrease[1]);
			double phi3 = Double.parseDouble(psmLogDecrease[2]);
			Globals.PSM_LOGISTIC_DECREASE_FUNCTION = new LogisticDecreaseSSLogis(phi1, phi2, phi3);
		} else {
			System.err.println("Invalid value for PSM_log - " + psmLog);
			throw new RuntimeException("Invalid value for PSM_log - " + psmLog);
		}
		
		if (Globals.MAX_DIST_TO_TARGET == 0) {
			Globals.MAX_DIST_TO_TARGET = Double.POSITIVE_INFINITY;
		}

		String landscape = (String) params.getValue("landscape");
		Globals.LANDSCAPE = landscape;

		try {
			loadLandscape("data/" + landscape + "/bathy.asc");
		} catch (Exception e1) {
			e1.printStackTrace(); // TODO Abort the simulation here, landscape was not loaded.
		}

		Globals.HOMOGENOUS = landscape.equals("Homogeneous");

		int porpoises = (Integer) params.getValue("porpoiseCount");
		boolean onDemandFood = false; // Hardcoded value - (Boolean)params.getValue("onDemandFood");

		Globals.MODEL = 4; // Hardcoded value - (Integer)params.getValue("model");
		Globals.DEBUG = (Integer) params.getValue("debug");
		Globals.PORPOISE_ID.set(0);
		Globals.MORTALITY_ENABLED = true; // Hardcoded value - (Boolean)params.getValue("mortality");
		String dispersalTypeStr = params.getString("dispersal");
		if ("PSM-Type1".equals(dispersalTypeStr)) {
			Globals.DISPERSAL_TYPE = DispersalType.PSM_Type1;
		} else if ("PSM-Type2".equals(dispersalTypeStr)) {
			Globals.DISPERSAL_TYPE = DispersalType.PSM_Type2;
		} else {
			Globals.DISPERSAL_TYPE = DispersalType.Off;
		}
		Globals.T_DISP = params.getInteger("tdisp");

		// Initialize deterrence ignore mode
		Globals.IGNORE_DETER_MIN_IMPACT = 0.0; // (Double) params.getValue("EBimpact");
		Globals.IGNORE_DETER_MIN_DISTANCE = 0.0; // ((Double) params.getValue("EBmin")) / 400;
		Globals.IGNORE_DETER_STUCK_TIME = 0; // (Integer) params.getValue("EBstucktime");
		Globals.IGNORE_DETER_NUMBER_OF_STEPS_IGNORE = 0; // (Integer) params.getValue("EBsteps");

		System.out.println("rS: " + params.getDouble("rS") + ", rR: " + params.getDouble("rR") + ", rU: "
				+ params.getDouble("rU"));
		Globals.initMemLists(params.getDouble("rS"), params.getDouble("rR"));
		Globals.FOOD_GROWTH_RATE = params.getDouble("rU");
		Globals.BYCATCH_PROB = params.getDouble("bycatchProb");

		boolean wrapBorder = Globals.HOMOGENOUS && params.getBoolean("wrapBorderHomo");
		PointTranslator pointTranslator;
		if (wrapBorder) {
			pointTranslator = new repast.simphony.space.continuous.WrapAroundBorders();
		} else {
			pointTranslator = new BouncyBorders();
		}
		ContinuousSpaceFactory factory = ContinuousSpaceFactoryFinder.createContinuousSpaceFactory(null);
		ContinuousSpace<Agent> space = factory.createContinuousSpace("space", context,
				new RandomCartesianAdder<Agent>(), pointTranslator, new double[] { Globals.WORLD_WIDTH,
						Globals.WORLD_HEIGHT }, new double[] { 0.5f, 0.5f });

		GridFactory gridFactory = GridFactoryFinder.createGridFactory(null);
		Grid<Agent> grid = gridFactory.createGrid("grid", context, new GridBuilderParameters<Agent>(
				new repast.simphony.space.grid.BouncyBorders(), new SimpleGridAdder<Agent>(), true,
				Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT));
		//		Grid<Agent> grid = gridFactory.createGrid("grid", context, new GridBuilderParameters<Agent>(new repast.simphony.space.grid.WrapAroundBorders(), new SimpleGridAdder<Agent>(), true, Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT));

		LandscapeLoader dataLoader = new LandscapeLoader();
		CellData cellData = dataLoader.load(landscape, onDemandFood);

		FoodAgentProxy foodAgent = new FoodAgentProxy(space, grid, 0, cellData);
		context.add(foodAgent);

		Globals.MONTHLY_STATS.resetStats();
		context.add(Globals.MONTHLY_STATS);

		int[] ageDistribution = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
				1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
				1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
				2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
				3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5,
				5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 8, 8, 8, 8, 8, 8, 8,
				8, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 10, 10, 10, 10, 10, 10, 11, 11, 11, 11, 11, 12, 12, 12, 12, 12,
				12, 12, 13, 13, 13, 13, 14, 14, 14, 14, 15, 15, 15, 15, 18, 18, 19, 19, 21, 22 };

		RefMemTurnCalculator refMemTurn = new FastRefMemTurn(); // : new OriginalRefMemTurn(); Fast ref mem is the one that has been validated;

		for (int i = 0; i < porpoises; i++) {
			Porpoise p = new Porpoise(space, grid, cellData, context,
					ageDistribution[Globals.RANDOM_SOURCE.nextAgeDistrib(0, ageDistribution.length)],
					refMemTurn);
			context.add(p);
			p.moveAwayFromLand();

			NdPoint initialPoint = Globals.RANDOM_SOURCE.getInitialPoint();
			Double initialHeading = Globals.RANDOM_SOURCE.getInitialHeading();

			if (initialPoint != null) {
				p.setPosition(initialPoint);
				p.reinitializePoslist();
				p.setHeading(initialHeading);
			}
			PorpoiseTestDataCapturer.capture(p);
		}

		int trackedPorpoisesCount = (Integer) params.getValue("trackedPorpoiseCount");
		if (trackedPorpoisesCount > 0) {
			AddTrackedPorpoisesTask addTrackedPorpoisesTask = new AddTrackedPorpoisesTask(context, space, grid,
					landscape, trackedPorpoisesCount);
			addTrackedPorpoisesTask.setup();
		}

		/* Parameter removed, should always be false
		if ((Boolean)params.getValue("ships"))
		{
			try
			{
				addShips(context, space, grid, "Aarhus-Odden.txt", new NdPoint[] {new NdPoint(119, 633), new NdPoint(157, 605), new NdPoint(197, 597), new NdPoint(288, 584)});
				addShips(context, space, grid, "Great-Belt.txt", new NdPoint[] {new NdPoint(288.66, 999), new NdPoint(366.56, 804.34), new NdPoint(210.04, 539.42), new NdPoint(205.78, 489.69), new NdPoint(249.14, 404.9), new NdPoint(259.2, 369.07), new NdPoint(249.49, 308.61), new NdPoint(225.86, 263.82), new NdPoint(228.83, 227.3), new NdPoint(377.59, 154.1), new NdPoint(438.14, 156.74), new NdPoint(445.4, 168), new NdPoint(524.38, 261.43), new NdPoint(599, 315.93)});
				addShips(context, space, grid, "Kattegat-Sound.txt", new NdPoint[] {new NdPoint(288.66, 999), new NdPoint(366.56, 804.34), new NdPoint(401.52, 678.13), new NdPoint(478, 628), new NdPoint(487.77, 620.61), new NdPoint(508.29, 575), new NdPoint(542.26, 500.6), new NdPoint(506.3, 407.47), new NdPoint(599, 315.93)});
			}
			catch (IOException e)
			{
				throw new RuntimeException(e);
			}
		} */

		String turbines = params.getString("turbines");
		if (turbines != null && !"off".equalsIgnoreCase(turbines)) {
			// Load and set up turbines
			try {
				Turbine.load(context, space, grid, turbines, RunEnvironment.getInstance().isBatch());
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}

		for (Agent a : context) {
			NdPoint pt = space.getLocation(a);
			grid.moveTo(a, (int) pt.getX(), (int) pt.getY());
		}

		ISchedule schedule = RunEnvironment.getInstance().getCurrentSchedule();
		ScheduleParameters foodParams = ScheduleParameters.createRepeating(48, 48, Globals.PRIO_FOOD);

		ScheduleParameters dailyParamsDay1 = ScheduleParameters.createOneTime(1, Globals.PRIO_DAILY); // Special tick#1 daily-tasks
		ScheduleParameters dailyParams = ScheduleParameters.createRepeating(48, 24 * 2, Globals.PRIO_DAILY);

		ScheduleParameters monthlyParamsDay1 = ScheduleParameters.createOneTime(1, Globals.PRIO_MONTHLY);
		ScheduleParameters monthlyParams = ScheduleParameters.createRepeating(30 * 24 * 2, 30 * 24 * 2,
				Globals.PRIO_MONTHLY);

		ScheduleParameters yearlyParamsDay1 = ScheduleParameters.createOneTime(1, Globals.PRIO_YEARLY);
		ScheduleParameters yearlyParams = ScheduleParameters.createRepeating(360 * 24 * 2, 360 * 24 * 2,
				Globals.PRIO_YEARLY);

		IAction dailyTask = new DailyTask(context);
		IAction monthlyTask = new MonthlyTasks();
		IAction yearlyTask = new YearlyTask(context);

		schedule.schedule(dailyParamsDay1, dailyTask);
		schedule.schedule(dailyParams, dailyTask);

		schedule.schedule(monthlyParamsDay1, monthlyTask);
		schedule.schedule(monthlyParams, monthlyTask);

		schedule.schedule(yearlyParamsDay1, yearlyTask);
		schedule.schedule(yearlyParams, yearlyTask);

		if (!onDemandFood) {
			schedule.schedule(foodParams, new FoodTask(cellData));
		}

		if (Globals.MODEL >= 3) {
			ScheduleParameters deterenceParams = ScheduleParameters.createRepeating(0, 1, Globals.PRIO_PORP_DETERRENCE);
			schedule.schedule(deterenceParams, new DeterenceTask(context, space, grid));
		}

		if (!RunEnvironment.getInstance().isBatch()) {
			GridValueLayer visitedCellValueLayer = new GridValueLayer("visitedCell", 0.000f, true,
					new WrapAroundBorders(), Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT);
			context.addValueLayer(visitedCellValueLayer);

			BackgroundAgent ba = new BackgroundAgent(space, grid, cellData);
			context.add(ba);
			ba.initialize();

			TrackingDisplayAgent tda = new TrackingDisplayAgent(space, grid, 0);
			context.add(tda);
			tda.initialize();

//			CellDataDistToCoastAgent cdd2ca = new CellDataDistToCoastAgent(space, grid, cellData);
//			context.add(cdd2ca);
//			cdd2ca.initialize();
		}

		addBlocks(cellData.getBlock(), space, grid, context);

		Globals.SIM_YEARS = params.getInteger("simYears");
		if (Globals.SIM_YEARS != null) {
			int numSimSteps = Globals.SIM_YEARS * 360 * 48;
			RunEnvironment.getInstance().endAt(numSimSteps);
		} else {
			// The batch always needs an end criteria (only time defined)
			if (RunEnvironment.getInstance().isBatch()) {
				Globals.SIM_YEARS = 30;
				int numSimSteps = 30 * 360 * 48;
				RunEnvironment.getInstance().endAt(numSimSteps);
			}
		}

		/* Parameter removed, should be hardcoded to false
		if (params.getBoolean("showFoodPatch"))
		{
			addFoodPatches(cellData, context, space, grid);
		} */

		return context;
	}

	private void addShips(Context<Agent> context, ContinuousSpace<Agent> space, Grid<Agent> grid, String file,
			NdPoint[] route) throws IOException {
		FileReader freader = new FileReader("data/Ships/" + file);
		BufferedReader reader = new BufferedReader(freader);

		// First line is header
		reader.readLine();

		String line;
		while ((line = reader.readLine()) != null) {
			String[] parts = line.split("\t");

			String id = parts[0];
			double speed = Double.parseDouble(parts[1]);
			double impact = Double.parseDouble(parts[2]);

			Ship s = new Ship(space, grid, route, impact, speed, id);
			context.add(s);
			s.initialize();
		}

		reader.close();
	}

	private void queueTask(String intervalText, ISchedule schedule, IAction action) {
		if (!intervalText.equals("off")) {
			int interval;
			if (intervalText.equals("step")) {
				interval = 1;
			} else if (intervalText.equals("daily")) {
				interval = 24 * 2;
			} else if (intervalText.equals("monthly")) {
				interval = 24 * 2 * 30;
			} else if (intervalText.equals("yearly")) {
				interval = 24 * 2 * 30 * 360;
			} else if (intervalText.equals("one-porp")) {
				throw new java.lang.NoSuchMethodError("Not implemented");
			} else {
				throw new RuntimeException("Unknown interval : " + intervalText);
			}

			ScheduleParameters scheduleParam = ScheduleParameters.createRepeating(0, interval,
					ScheduleParameters.LAST_PRIORITY);
			schedule.schedule(scheduleParam, action);
		}
	}

	private int optionToInteger(String s) {
		String value = s.substring(s.lastIndexOf(" ") + 1);
		return Integer.parseInt(value);
	}

	private double optionToDouble(String s) {
		String value = s.substring(s.lastIndexOf(" ") + 1);
		return Double.parseDouble(value);
	}

	/**
	 * Loads the landscape parameters from the passed asc file.
	 * 
	 * This function will update the Global parametes.
	 * 
	 * TODO: Get rid of the Global parameters and find a nicer way to distribute these values.
	 * 
	 * @param ascFile The asc to load the landscape parameters from.
	 * @throws Exception Thrown in the asc data cannot be read.
	 */
	private void loadLandscape(String ascFile) throws Exception {
		try (FileReader freader = new FileReader(ascFile); BufferedReader reader = new BufferedReader(freader);) {
			int ncols = optionToInteger(reader.readLine().trim());
			int nrows = optionToInteger(reader.readLine().trim());
			double xllcorner = optionToDouble(reader.readLine().trim());
			double yllcorner = optionToDouble(reader.readLine().trim());
			int cellsize = optionToInteger(reader.readLine().trim());

			if (cellsize != 400) {
				throw new Exception("Cell size != 400, not supported");
			}

			Globals.WORLD_WIDTH = ncols;
			Globals.WORLD_HEIGHT = nrows;
			Globals.XLLCORNER = xllcorner;
			Globals.YLLCORNER = yllcorner;
		}
	}

	// Utility to convert bathy file in case depth is negative. Uses -9999 as no value.
	private void convertBathy(String f) {
		try {
			BufferedWriter out = new BufferedWriter(new FileWriter("c:/temp/out.txt"));

			FileReader freader = new FileReader(f);
			BufferedReader reader = new BufferedReader(freader);

			for (int i = 0; i < 6; i++) {
				out.write(reader.readLine());
				out.write('\n');
			}

			int y = 0;
			String line;
			while ((line = reader.readLine()) != null) {
				String[] points = line.split(" ");
				for (int x = 0; x < points.length; x++) {
					int i = Integer.parseInt(points[x]);

					if (i == -9999) {
						out.write(Integer.toString(i));
					} else {
						out.write(Integer.toString(i * -1));
					}

					if (x + 1 < points.length) {
						out.write(' ');
					} else {
						out.write('\n');
					}
				}
				y++;
			}

			reader.close();
			freader.close();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void createFile(String file, int columns, int rows, String s) {
		try {
			BufferedWriter out = new BufferedWriter(new FileWriter(file));

			for (int row = 0; row < rows; row++) {
				for (int column = 0; column < columns; column++) {
					out.write(s);
					out.write(' ');
				}
				out.write('\n');
			}

			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void createFoodProbFile(String file, int columns, int rows, double prob) {
		try {
			BufferedWriter out = new BufferedWriter(new FileWriter(file));

			for (int row = 0; row < rows; row++) {
				for (int column = 0; column < columns; column++) {
					if (((int) Math.floor(Globals.randomFloat(0, prob))) == 1) {
						out.write('1');
					} else {
						out.write('0');
					}

					out.write(' ');
				}
				out.write('\n');
			}

			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Adds the required block dummy agents to the model. They are only there to enable the text sinks to use them for
	 * dumping the numnber of porpoises in them.
	 */
	private void addBlocks(int[][] blocks, ContinuousSpace<Agent> space, Grid<Agent> grid, Context<Agent> context) {
		int maxBlock = -1;

		for (int x = 0; x < blocks.length; x++) {
			for (int y = 0; y < blocks[x].length; y++) {
				if (blocks[x][y] > maxBlock) {
					maxBlock = blocks[x][y];
				}
			}
		}

		Block.initialize(maxBlock + 1);

		for (int i = 0; i < (maxBlock + 1); i++) {
			Block b = new Block(space, grid, i, context);
			context.add(b);
		}
	}

	private void addFoodPatches(CellData data, Context<Agent> context, ContinuousSpace<Agent> space, Grid<Agent> grid) {
		Pair[] patches = data.getFoodProbAboveZeroPatches();

		for (Pair p : patches) {
			FoodPatch fp = new FoodPatch(space, grid, new GridPoint(p.first, p.second), data);
			context.add(fp);
			fp.setPosition(new NdPoint(p.first, p.second));

			System.out.println("Adding <" + p.first + "," + p.second + ">");

		}
	}

	private void setupReplay() {
		int fileNum = 1;
		String fileName = null;
		do {
			String fName = "output/replay-" + fileNum + ".txt";
			if (!Files.exists(Paths.get(fName))) {
				fileName = fName;
				break;
			}
			fileNum++;
		} while (fileNum < 10001);

		try {
			Globals.REPLAY_OUT = new BufferedWriter(new FileWriter(fileName));
			System.out.println("Writing replay to " + fileName);
		} catch (IOException e) {
			throw new RuntimeException("Error creating replay file.", e);
		}
	}

}
