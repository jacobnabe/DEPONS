/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise;

import repast.simphony.context.Context;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.grid.Grid;

/**
 * Dummy placeholder for the squares in the model.
 */
public class Block extends Agent {

	private static double lastUpdate = -1;
	private static int[] blockCount;
	private static Context<Agent> CONTEXT;

	/**
	 * Constructor.
	 * 
	 * @param space A reference to the space.
	 * @param grid A reference to the grid.
	 * @param id The id number of the square, this is the number from the
	 * @param context The current context.
	 */
	public Block(ContinuousSpace<Agent> space, Grid<Agent> grid, long id, Context<Agent> context) {
		super(space, grid, id);
		CONTEXT = context;
	}

	public int getPorpoiseCount() {
		update();

		return blockCount[(int) this.id];
	}

	public static void initialize(int numBlocks) {
		blockCount = new int[numBlocks];
	}

	public synchronized static void update() {
		if (lastUpdate != Globals.getTick()) {
			// update is required

			for (int i = 0; i < blockCount.length; i++) {
				blockCount[i] = 0;
			}

			for (Agent a : CONTEXT.getObjects(Porpoise.class)) {
				Porpoise p = (Porpoise) a;
				int block = p.getBlock();

				if (block >= 0) {
					blockCount[block]++;
				} else {
					// Some water fields seems to be marked as "no block" -999  
					// System.out.println("Porpoise " + p.getId() + " is in block " + p.getBlock() + "?! " + p.getPosition());
				}
			}

			// Ensure that we only update the table once per tick.
			lastUpdate = Globals.getTick();
		}
	}

}
