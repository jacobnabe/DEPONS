/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise;

import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.grid.Grid;
import dk.au.bios.porpoise.tasks.FoodTask;
import dk.au.bios.porpoise.util.Pair;

/**
 * A proxy Agent to enable using food in a Data Source. This is considered a temporary measure - until a proper use of
 * food with a Data Source can be found.
 */
public class FoodAgentProxy extends Agent {

	private CellData cellData;

	public FoodAgentProxy(ContinuousSpace<Agent> space, Grid<Agent> grid, long id, CellData cellData) {
		super(space, grid, id);
		this.cellData = cellData;
	}

	public double getFoodEnergyLevel() {
		Pair[] patches = cellData.getFoodProbAboveZeroPatches();
		double foodSum = 0.0f;

		for (int i = 0; i < patches.length; i++) {
			double value = cellData.getFoodLevel(patches[i].first, patches[i].second);
			foodSum += value;
		}

		return foodSum;
	}

	public int getExtraGrowthCount() {
		return FoodTask.EXTRA_GROWTH_COUNT.get();
	}

}
