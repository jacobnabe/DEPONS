/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise;

/**
 * Class for updating a FoodPatch on demand.
 */
public class OnDemandFoodPatch {

	private double value;
	private double lastDayUpdate;
	private double[] maxEnt;

	public OnDemandFoodPatch(double[] maxEnt, double value) {
		this.value = value;
		this.maxEnt = maxEnt;
		this.lastDayUpdate = Globals.getDayOfSimulation();
	}

	public synchronized double getValue() {
		if (lastDayUpdate != Globals.getDayOfSimulation()) {
			calcValue();
		}

		return value;
	}

	public synchronized void eatFood(double amountEaten) {
		// TODO: Change this so we do not have to recalc the value here.
		if (lastDayUpdate != Globals.getDayOfSimulation()) {
			calcValue();
		}

		value -= amountEaten;

		if (Globals.ADD_ARTIFICIAL_FOOD && value < 0.01) {
			value = 0.01;
		}
	}

	private double getMaxEnt(int quarter) {
		return maxEnt[quarter];
	}

	private void calcValue() {
		if (!Globals.ADD_ARTIFICIAL_FOOD && value < 0.01) {
			value = 0.01;
		}

		for (double i = lastDayUpdate; i < Globals.getDayOfSimulation(); i++) {
			int quarterOfYear = Globals.getQuarterOfYear(i);
			if (value < ((double) Globals.MAX_U) * getMaxEnt(quarterOfYear)) {
				double fLevel = value
						+ (Globals.FOOD_GROWTH_RATE * value * (1.0 - value
								/ (Globals.MAX_U * getMaxEnt(quarterOfYear) / Globals.MEAN_MAXENT_IN_QUATERS[quarterOfYear])));

				if (Math.abs(fLevel - value) > Globals.REGROWTH_FOOD_QUALIFIER) {
					for (int k = 0; k < 47; k++) {
						fLevel += Globals.FOOD_GROWTH_RATE
								* fLevel
								* (1.0 - fLevel
										/ (Globals.MAX_U * getMaxEnt(quarterOfYear) / Globals.MEAN_MAXENT_IN_QUATERS[quarterOfYear]));
					}
				}

				value = fLevel;
			} else {
				// We have reached max, we can stop early
				break;
			}
		}

		lastDayUpdate = Globals.getDayOfSimulation();
	}

}
