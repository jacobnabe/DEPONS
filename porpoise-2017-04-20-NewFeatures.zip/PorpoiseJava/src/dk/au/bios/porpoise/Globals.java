/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicLong;

import repast.simphony.context.Context;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.engine.environment.RunState;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.grid.GridPoint;
import dk.au.bios.porpoise.behavior.RandomSource;
import dk.au.bios.porpoise.ui.PorpoiseUserPanel;
import dk.au.bios.porpoise.util.DaemonThreadFactory;
import dk.au.bios.porpoise.util.LogisticDecreaseSSLogis;

/**
 * Placeholder for NETLOGO globals and various utility functionality.
 * 
 * TODO This should be refactored.
 */
public class Globals {

	public static Context<Agent> CONTEXT; // TODO: Move elsewhere, don't keep a static reference

	public static double getTick() {
		return RunEnvironment.getInstance().getCurrentSchedule().getTickCount();
	}

	public static PorpoiseUserPanel USER_PANEL = new PorpoiseUserPanel();

	public static ExecutorService THREAD_POOL = Executors.newFixedThreadPool(8, new DaemonThreadFactory());

	// The priority of the different tasks in the model. The higher the number the earlier it is executed
	public static final double PRIO_PORP_DETERRENCE = 1100;
	public static final double PRIO_PORP_MOVE = 1000;
	public static final double PRIO_SHIP_MOVE = 800;

	public static final double PRIO_FOOD = 1700; // Looks like it has lower prio in Netlogo but it is in fact higher as it happens after time-step++ (mind blown!!)
	public static final double PRIO_YEARLY = 1600;
	public static final double PRIO_DAILY = 1500;
	public static final double PRIO_MONTHLY = 1400;

	public static String LANDSCAPE = null;

	// The source for random values - if not null, we are doing a replay scenario.
	// public static String RANDOM_REPLAY_SOURCE = "data/RandomReplay/test.txt";
	public static String RANDOM_REPLAY_SOURCE = null; // disable

	public static RandomSource RANDOM_SOURCE = null; // Defines the source of random numbers. Either generated or replayed.

	public static double REGROWTH_FOOD_QUALIFIER = 0.001;
	public static final boolean ADD_ARTIFICIAL_FOOD = true; // Whether or not to invent food if the porpoise eats all the food in a patch. NetLogo default behavior

	public static boolean SHIFT_QUARTER = true; // The NetLogo model shifted the quarters of the year 30 days, when this is enabled we do the same.
	public static boolean OFFSET_MONTH = true; // Netlogo shifts the month one tick "too" late, when this enabled then this model does the same.
	public static boolean HOMOGENOUS = true;

	public static GridPoint[] BLOCK_CENTRES;

	public static double[] BLOCK_VAL_Q1;
	public static double[] BLOCK_VAL_Q2;
	public static double[] BLOCK_VAL_Q3;
	public static double[] BLOCK_VAL_Q4;

	public static PorpoiseStatistics MONTHLY_STATS = new PorpoiseStatistics();

	public static LinkedList<Integer> LIST_OF_DEAD_AGE = new LinkedList<Integer>(); // Age of death for all animals that die. Reset every year
	public static LinkedList<Integer> LIST_OF_DEAD_DAY = new LinkedList<Integer>(); // Day of death for all animals that die. Reset every year

	//public static double[] MEAN_MAXENT_IN_QUATERS = {0.515686364223653, 0.888541219760357, 0.841346010536882, 1}; // standardized average maxent level in each quarter
	public static double[] MEAN_MAXENT_IN_QUATERS = { 1, 1, 1, 1 }; // standardized average maxent level in each quarter

	/**
	 * Maximum energy content in a food patch. In parameters.xml: Umax
	 */
	public static double MAX_U = 1.0; //; Maximum utility of a patch, set to 1 here

	public static double XLLCORNER = 529473;
	public static double YLLCORNER = 5972242;

	public static double CORR_LOGMOV = 0.94; // correlation in movement distance in CRW +
	public static double CORR_ANGLE = 0.26; // correlation in direction in CRW +

	public static double M = Math.pow(10, 0.74); // Limit for when turning angles stop decreasing with speed

	/**
	 * Minimum water depth [m] required by porpoises (J. Tougaard, pers. obs). In parameters.xml: wmin
	 */
	public static double MIN_DEPTH = 1.0; // Match NetLogo

	public final static int MEMORY_MAX = 120; // Maximum number of half-hour steps the amount of food can be remembered (120 steps is 2.5 days)

	/**
	 * Inertia constant; the animal's tendency to keep moving using CRW irrespective of foraging success. In
	 * parameters.xml: k
	 */
	public static double INERTIA_CONST = 0.001; // A, set to 0.001 like in ms

	// replaces ref-mem-strength-list, uses rR = 0.10 
	public static double[] REF_MEM_STRENGTH_LIST_FIXED = new double[] { 0.999, 0.9989, 0.9988, 0.9987, 0.9985, 0.9984,
			0.9982, 0.9981, 0.9979, 0.9976, 0.9974, 0.9972, 0.9969, 0.9966, 0.9962, 0.9958, 0.9954, 0.995, 0.9945,
			0.9939, 0.9933, 0.9926, 0.9919, 0.9911, 0.9902, 0.9893, 0.9882, 0.987, 0.9858, 0.9843, 0.9828, 0.9811,
			0.9793, 0.9772, 0.975, 0.9726, 0.9699, 0.967, 0.9638, 0.9603, 0.9565, 0.9523, 0.9478, 0.9428, 0.9375,
			0.9316, 0.9252, 0.9183, 0.9108, 0.9027, 0.8939, 0.8844, 0.8742, 0.8632, 0.8514, 0.8387, 0.8252, 0.8108,
			0.7954, 0.7792, 0.7619, 0.7438, 0.7248, 0.7048, 0.684, 0.6624, 0.64, 0.617, 0.5934, 0.5692, 0.5447, 0.5199,
			0.4949, 0.4699, 0.445, 0.4203, 0.396, 0.3721, 0.3487, 0.326, 0.304, 0.2828, 0.2626, 0.2432, 0.2248, 0.2074,
			0.1909, 0.1755, 0.161, 0.1475, 0.1349, 0.1233, 0.1125, 0.1025, 0.0933, 0.0848, 0.0771, 0.0699, 0.0634,
			0.0575, 0.0521, 0.0471, 0.0426, 0.0386, 0.0349, 0.0315, 0.0284, 0.0257, 0.0232, 0.0209, 0.0189, 0.017,
			0.0153, 0.0138, 0.0125, 0.0112, 0.0101, 0.0091, 0.0082, 0.0074 };

	// replaces work-mem-strength-list, uses rW = 0.20
	public static double[] WORK_MEM_STRENGTH_LIST_FIXED = new double[] { 0.9990, 0.9988, 0.9986, 0.9983, 0.9979,
			0.9975, 0.9970, 0.9964, 0.9957, 0.9949, 0.9938, 0.9926, 0.9911, 0.9894, 0.9873, 0.9848, 0.9818, 0.9782,
			0.9739, 0.9689, 0.9628, 0.9557, 0.9472, 0.9372, 0.9254, 0.9116, 0.8955, 0.8768, 0.8552, 0.8304, 0.8022,
			0.7705, 0.7351, 0.6962, 0.6539, 0.6086, 0.5610, 0.5117, 0.4617, 0.4120, 0.3636, 0.3173, 0.2740, 0.2342,
			0.1983, 0.1665, 0.1388, 0.1149, 0.0945, 0.0774, 0.0631, 0.0513, 0.0416, 0.0336, 0.0271, 0.0218, 0.0176,
			0.0141, 0.0113, 0.0091, 0.0073, 0.0058, 0.0047, 0.0037, 0.0030, 0.0024, 0.0019, 0.0015, 0.0012, 0.0010,
			0.0008, 0.0006, 0.0005, 0.0004, 0.0003, 0.0003, 0.0002, 0.0002, 0.0001, 0.0001, 0.0001, 0.0001, 0.0001,
			0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000,
			0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000,
			0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000 };

	public static boolean USE_EXP_FOOD_VAL; // get more attracted to the CRW path if food was found recently

	public final static double M_MORT_PROB_CONST = 1.0; // TODO: make this user definable

	public static boolean ALTERNATIVE_REF_MEM_TURN = false;

	/**
	 * Survival probability constant (calibrated). In parameters.xml: beta
	 */
	public static double X_SURVIVAL_PROB_CONST = 0.4;

	public final static double E_USE_PER_KM = 0.0; // TODO: make this user definable

	/**
	 * Energy use per half-hour step in May-September (calibrated). In parameters.xml: Euse
	 */
	public static double E_USE_PER_30_MIN = 4.5;

	/**
	 * Energy use multiplyer for lactating mammals (Magnus Wahlberg, unpubl. data). In parameters.xml: Elact
	 */
	public static double E_LACT = 1.4;

	/**
	 * Energy use multiplier in warm water (Lockyer et al. 2003). In parameters.xml: Ewarm
	 */
	public static double E_WARM = 1.3;

	/**
	 * In parameters.xml: bycatchProb
	 */
	public static double BYCATCH_PROB = 0.0;
	public final static double MIN_DIST_TO_TARGET = 100; // TODO: make this user definable

	public static double MAX_DIST_TO_TARGET;

	public static double PSM_PREFERRED_DISTANCE;
	public static double PSM_PREFERRED_DISTANCE_STDDEV;
	public static double PSM_PREFERRED_DISTANCE_TOLERANCE;
	public static double PSM_TYPE2_RANDOM_ANGLE;
	public static LogisticDecreaseSSLogis PSM_LOGISTIC_DECREASE_FUNCTION;

	/**
	 * Number of potential dispersal targets = 40x40 km blocks (calibrated visually). In parameters.xml: q
	 */
	public static int N_DISP_TARGET = 12;

	/**
	 * Minimum water depth when dispersing [m] (visual calibration). In parameters.xml: wdisp
	 */
	public static double MIN_DISP_DEPTH = 4.0;

	/**
	 * Dispersal distance per time step [km] (J. Teilmann, unpublished satellite data). In parameters.xml: ddisp
	 */
	public static double MEAN_DISP_DIST = 1.6;

	/**
	 * Porpoise max distance. In parameters.xml: dmax_mov
	 */
	public static double MAX_MOV = 1.18;

	/**
	 * Food replenishment rate [unitless] (Nabe-Nielsen et al., 2013). In parameters.xml: rU
	 */
	public static double FOOD_GROWTH_RATE = 0.10;

	/**
	 * The response-threshold for deterrence. In parameters.xml: RT
	 */
	public static double DETER_RESPONSE_THRESHOLD = 158;

	/**
	 * Deterrence time; number of time steps the deterrence effect lasts [time steps] (arbitrary). In parameters.xml:
	 * tdeter
	 */
	public static int DETER_TIME = 5;

	/**
	 * Deterrence decay; In parameter.xml: Psi_deter
	 */
	public static double DETER_DECAY = 50;

	/**
	 * Maximum deterrence distance. Animals that are more than this far from the noise source shold stop being deterred.
	 * Parameter is specified in KM but stored in this variable in meters. In parameter.xml: dmax_deter
	 */
	public static double DETER_MAX_DISTANCE = 50 * 1000; // 50 KM

	/**
	 * Probability of becoming pregnant (Read and Hohn, 1995). In parameters.xml: h
	 */
	public static double CONCEIVE_PROB = 0.68;

	/**
	 * Gestation time [days] (Lockyer et al., 2003). In parameters.xml: tgest
	 */
	public static int GESTATION_TIME = 300;

	public static double MATURITY_AGE = 3.44;

	/**
	 * Nursing time [days] (Lockyer et al., 2003; Lockyer and Kinze, 2003). In parameters.xml: tnurs
	 */
	public static int NURSING_TIME = 240;

	/**
	 * Porpoise maximum age. In parameters.xml: tmaxage
	 */
	public static double MAX_AGE = 30.0;

	public static boolean MORTALITY_ENABLED = true; // Affects whether porpoises die and reproduce
	public static DispersalType DISPERSAL_TYPE = DispersalType.Off; // Affects whether dispersal is applied daily to the porpoises

	/**
	 * Days of declining energy before activating dispersal. In parameters.xml: tdisp
	 */
	public static int T_DISP = 3;

	public static AtomicLong PORPOISE_ID = new AtomicLong();

	public static int MODEL = 1; // model seems to be a global variable in NETLOGO

	/**
	 * Deterrence coefficient [unitless] (calibrated). In parameters.xml: c
	 */
	public static double DETERRENCE_COEFF = 1; // Not declared in NETLOGO, only used
	public static int DEBUG = 0;

	public static int WORLD_WIDTH = 1000;
	public static int WORLD_HEIGHT = 600;

	public static Integer SIM_YEARS = null; // Limit simulation to number of years.

	/*
	 * If stuck and heavily deterred (more than ship noise, impact > c), 
	 * moving less than a in the last b steps, while being deterred. 
	 * Go back to random move for y steps, ignoring noise.
	 */
	public static double IGNORE_DETER_MIN_IMPACT = 10; // c
	public static double IGNORE_DETER_MIN_DISTANCE = 10; // a
	public static int IGNORE_DETER_STUCK_TIME = 10; // b
	public static int IGNORE_DETER_NUMBER_OF_STEPS_IGNORE = 10; // y

	public static double randomNormal(double mean, double standardDeviation) {
		return RandomHelper.createNormal(mean, standardDeviation).nextDouble();
	}

	public static int random(int from, int to) {
		return RandomHelper.nextIntFromTo(from, to - 1);
	}

	public static double randomFloat(double from, double to) {
		return RandomHelper.nextDoubleFromTo(from, to);
	}

	public static void print(String s) {
		long tick = (long) RunEnvironment.getInstance().getCurrentSchedule().getTickCount();
		System.out.println("" + tick + " - " + s);
	}

	public static void write(String s) {
		System.out.print(s);
	}

	/**
	 * If this is not null, replay information will be written to this Writer.
	 */
	public static BufferedWriter REPLAY_OUT = null;

	/**
	 * Write output capturing data for a later replay.
	 * 
	 * @param s The replay output to write
	 */
	public static void replayPrint(String s) {
		if (isReplayPrintEnabled()) {
			try {
				REPLAY_OUT.write(s);
				REPLAY_OUT.newLine();
				REPLAY_OUT.flush();
			} catch (IOException e) {
				throw new RuntimeException("Unable to write to replay file", e);
			}
		}
	}

	public static void replayPrint(String s, Object... params) {
		if (isReplayPrintEnabled()) {
			replayPrint(MessageFormat.format(s, params));
		}
	}

	public static boolean isReplayPrintEnabled() {
		return REPLAY_OUT != null;
	}

	public static int getDayOfSimulation() {
		return (int) (getTick() / 48);
	}

	public static int getDayOfYear() {
		return ((int) (getTick() / 48)) % 360;
	}

	public static int getYearOfSimulation() {
		return (int) (getTick() / (360 * 48));
	}

	/**
	 * @return The month of the year, 1 indexed, 1 = January
	 */
	public static int getMonthOfYear() {
		return getMonthOfYear(getTick());
	}

	/***
	 * 
	 * @param netLogoMonth Use NetLogos month implementataion (shifted 0 ticks from Repast)
	 * @return
	 */
	public static int getMonthOfYear(boolean netLogoMonth) {
		if (netLogoMonth) {
			return getMonthOfYear(getTick() - 1);
		} else {
			return getMonthOfYear();
		}
	}

	public static int getMonthOfYear(double tick) {
		return (int) ((tick / (30 * 48)) % 12) + 1;
	}

	public static int getQuarterOfYear() {
		return getQuarterOfYear(getTick());
	}

	public static int getQuarterOfYear(double step) {
		if (SHIFT_QUARTER) {
			step += 30 * 48;
		}

		return (int) ((step) / (3 * 30 * 48)) % 4;

	}

	public static double[] getBlockValues() {
		switch (Globals.getQuarterOfYear()) {
		case 0:
			return Globals.BLOCK_VAL_Q1;
		case 1:
			return Globals.BLOCK_VAL_Q2;
		case 2:
			return Globals.BLOCK_VAL_Q3;
		case 3:
			return Globals.BLOCK_VAL_Q4;
		default:
			throw new RuntimeException("Unexpected quarter");
		}
	}

	/**
	 * Initialization of the REF_MEM_STRENGTH_LIST_FIXED (rR) and WORK_MEM_STRENGTH_LIST_FIXED (rS).
	 */
	public static void initMemLists(final double rS, final double rR) {
		printDoubleArray(REF_MEM_STRENGTH_LIST_FIXED);
		REF_MEM_STRENGTH_LIST_FIXED = calcArray(0.999, rR, REF_MEM_STRENGTH_LIST_FIXED.length, 4);
		printDoubleArray(REF_MEM_STRENGTH_LIST_FIXED);

		printDoubleArray(WORK_MEM_STRENGTH_LIST_FIXED);
		WORK_MEM_STRENGTH_LIST_FIXED = calcArray(0.999, rS, WORK_MEM_STRENGTH_LIST_FIXED.length, 4);
		printDoubleArray(WORK_MEM_STRENGTH_LIST_FIXED);
	}

	private static double[] calcArray(double firstValue, double coff, int size, int roundingDecimals) {
		double[] answer = new double[size];
		answer[0] = firstValue;
		for (int i = 1; i < size; i++) {
			double prev = answer[i - 1];
			double curr = prev - coff * prev * (1 - prev);
			answer[i] = curr;
		}
		if (roundingDecimals > 0) {
			roundArray(answer, roundingDecimals);
		}
		return answer;
	}

	private static void roundArray(double[] arr, int decimals) {
		for (int i = 0; i < arr.length; i++) {
			arr[i] = new BigDecimal(arr[i]).setScale(4, BigDecimal.ROUND_HALF_UP).doubleValue();
		}
	}

	private static void printDoubleArray(double[] arr) {
		for (double d : arr) {
			System.out.printf("%f ", d);
		}
		System.out.println();
	}

	/**
	 * If not null, information for verifying the PSM behavior is written to this Writer.
	 */
	private static PrintWriter psmVerificationOutput = null;

	public static void initPSMVerificationOutput() {
		if (psmVerificationOutput != null) {
			psmVerificationOutput.close();
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MMM.dd.HH_mm_ss_SS");
		File psmVerificationOutputFile = new File("PersistentSpatialMemory." + sdf.format(new Date()) + ".csv");
		try {
			psmVerificationOutput = new PrintWriter(psmVerificationOutputFile);

			psmVerificationOutput.printf("\"stepType\",");
			if (RunEnvironment.getInstance().isBatch()) {
				psmVerificationOutput.printf("\"run\",");
			}
			psmVerificationOutput
					.printf("\"tick\",\"Id\",\"UtmX\",\"UtmY\",\"DispersalMode\",\"PSMActive\",\"PSMTargetUtmX\",\"PSMTargetUtmY\",\"psmHeading\",\"distance\",\"distanceLeft\"%n");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void writePSMVerificationPSM(String stepType, Porpoise porpoise, double distanceTravelled) {
		if (psmVerificationOutput == null) {
			return;
		}

		psmVerificationOutput.printf("%s,", stepType);
		if (RunEnvironment.getInstance().isBatch()) {
			psmVerificationOutput.printf("%d,", RunState.getInstance().getRunInfo().getRunNumber());
		}
		int psmUtmX;
		if (porpoise.getPersistentSpatialMemory() == null || !porpoise.getPersistentSpatialMemory().isActive()) {
			psmUtmX = -1;
		} else {
			psmUtmX = (int) Math.round(porpoise.getPersistentSpatialMemory().getTargetPosition().getX() * 400
					+ Globals.XLLCORNER);
		}
		int psmUtxY;
		if (porpoise.getPersistentSpatialMemory() == null || !porpoise.getPersistentSpatialMemory().isActive()) {
			psmUtxY = -1;
		} else {
			psmUtxY = (int) Math.round(porpoise.getPersistentSpatialMemory().getTargetPosition().getY() * 400
					+ Globals.YLLCORNER);
		}

		psmVerificationOutput.printf("%.1f,%d,%d,%d,%d,%s,%d,%d,%.3f,%.3f,%.3f%n", getTick(), porpoise.getId(),
				porpoise.getUtmX(), porpoise.getUtmY(), porpoise.getDispersalMode(),
				Boolean.toString(porpoise.getPersistentSpatialMemory().isActive()).toUpperCase(), psmUtmX, psmUtxY,
				porpoise.getPersistentSpatialMemory().getTargetHeading(), distanceTravelled * 400, porpoise
						.getPersistentSpatialMemory().getDistanceLeftToTravel() * 400);
		psmVerificationOutput.flush();
	}

}
