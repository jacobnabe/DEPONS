/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise;

import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.grid.Grid;

/**
 * Used to report on a porpoise in the simulation.
 */
public class RandomPorpoiseReportProxy extends Agent {

	private Porpoise porpoise;

	public RandomPorpoiseReportProxy(ContinuousSpace<Agent> space, Grid<Agent> grid, long id, Porpoise trackedPorpoise) {
		super(space, grid, id);

		this.porpoise = trackedPorpoise;
	}

	@Override
	public long getId() {
		return this.porpoise.getId();
	}

	public Porpoise getPorpoise() {
		return porpoise;
	}

	public int getUtmX() {
		if (porpoise.isAlive()) {
			return porpoise.getUtmX();
		} else {
			return -1;
		}
	}

	public int getUtmY() {
		if (porpoise.isAlive()) {
			return porpoise.getUtmY();
		} else {
			return -1;
		}
	}

	public double getEnergyLevel() {
		if (porpoise.isAlive()) {
			return porpoise.getEnergyLevel();
		} else {
			return -1;
		}
	}

	public double getDeterStrength() {
		if (porpoise.isAlive()) {
			return porpoise.getDeterStrength();
		} else {
			return -1;
		}
	}

	public int getPSMTargetUtmX() {
		if (porpoise.getPersistentSpatialMemory() == null || !porpoise.getPersistentSpatialMemory().isActive()) {
			return -1;
		}

		return (int) Math.round(porpoise.getPersistentSpatialMemory().getTargetPosition().getX() * 400
				+ Globals.XLLCORNER);
	}

	public int getPSMTargetUtmY() {
		if (porpoise.getPersistentSpatialMemory() == null || !porpoise.getPersistentSpatialMemory().isActive()) {
			return -1;
		}

		return (int) Math.round(porpoise.getPersistentSpatialMemory().getTargetPosition().getY() * 400
				+ Globals.YLLCORNER);
	}

	public int getDispersalMode() {
		return porpoise.getDispersalMode();
	}

	public boolean isPSMActive() {
		if (porpoise.getPersistentSpatialMemory() == null) {
			return false;
		}

		return porpoise.getPersistentSpatialMemory().isActive();
	}

	@ScheduledMethod(start = 0, interval = 1, priority = 100)
	public void updatePosition() {
		if (porpoise.isAlive()) {
			this.setPosition(porpoise.getPosition());
			this.setHeading(porpoise.getHeading());
		}
	}

}
