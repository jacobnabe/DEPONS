/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise;

import java.util.LinkedList;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import repast.simphony.space.continuous.NdPoint;
import repast.simphony.space.grid.GridPoint;
import dk.au.bios.porpoise.util.Pair;

/**
 * Encapsulates the data related to the simulation environment.
 */
public class CellData {

	private boolean onDemandFood;
	private boolean[][] mask;
	private double[][] distanceToCoast;
	private double[][] depth;
	private int[][] block;
	private double[][] foodProb;
	private double[][] foodValue;

	private OnDemandFoodPatch[][] foodPatch;

	private double[][] quarter1;
	private double[][] quarter2;
	private double[][] quarter3;
	private double[][] quarter4;

	private double[][] blockValQuarter1;
	private double[][] blockValQuarter2;
	private double[][] blockValQuarter3;
	private double[][] blockValQuarter4;

	private Pair[] foodProbAboveZeroCells;
	private boolean onDemandFoodUpdate;

	public CellData(Future<double[][]> distanceToCoast, Future<double[][]> depth, Future<double[][]> block,
			Future<double[][]> foodProb, Future<double[][]> quarter1, Future<double[][]> quarter2,
			Future<double[][]> quarter3, Future<double[][]> quarter4, boolean onDemandFoodUpdate, boolean[][] mask,
			boolean onDemandFood) throws ExecutionException, InterruptedException {
		this.onDemandFood = onDemandFood;
		this.distanceToCoast = distanceToCoast.get();
		this.depth = depth.get();
		this.foodProb = foodProb.get();
		this.onDemandFoodUpdate = onDemandFoodUpdate;

		this.quarter1 = quarter1.get();
		this.quarter2 = quarter2.get();
		this.quarter3 = quarter3.get();
		this.quarter4 = quarter4.get();
		this.mask = mask;

		this.foodValue = new double[this.foodProb.length][this.foodProb[0].length];

		double[][] blockDouble = block.get();
		this.block = new int[blockDouble.length][blockDouble[0].length];

		for (int i = 0; i < this.block.length; i++) {
			for (int j = 0; j < this.block[0].length; j++) {
				this.block[i][j] = (int) blockDouble[i][j];
			}
		}

		LinkedList<Pair> patches = new LinkedList<Pair>();
		for (int i = 0; i < this.foodProb.length; i++) {
			for (int j = 0; j < this.foodProb[0].length; j++) {
				if (this.foodProb[i][j] > 0) {
					patches.add(new Pair(i, j));
				}
			}
		}

		foodProbAboveZeroCells = new Pair[patches.size()];
		this.foodProbAboveZeroCells = patches.toArray(foodProbAboveZeroCells);

		if (onDemandFoodUpdate) {
			foodPatch = new OnDemandFoodPatch[this.foodProb.length][this.foodProb[0].length];

			for (Pair p : patches) {
				double value = Globals.MAX_U * this.quarter1[p.first][p.second]
						/ Globals.MEAN_MAXENT_IN_QUATERS[Globals.getQuarterOfYear()];
				foodPatch[p.first][p.second] = new OnDemandFoodPatch(new double[] { this.quarter1[p.first][p.second],
						this.quarter2[p.first][p.second], this.quarter3[p.first][p.second],
						this.quarter4[p.first][p.second] }, value);
			}
		}

	}

	public double getDistanceToCoast(int x, int y) {
		return distanceToCoast[x][y];
	}

	public double getDistanceToCoast(NdPoint point) {
		GridPoint p = Agent.ndPointToGridPoint(point);
		return distanceToCoast[p.getX()][p.getY()];
	}

	public double getDepth(GridPoint point) {
		return getDepth(point.getX(), point.getY());
	}

	public double getDepth(int x, int y) {
		try {
			return depth[x][y];
		} catch (ArrayIndexOutOfBoundsException e) {
			// TODO: Consider handling this better, i.e. propogate the error.
			return -9999; //0;			
		}
	}

	public double getDepth(NdPoint point) {
		return getDepth(Agent.ndPointToGridPoint(point));
	}

	public int getBlock(GridPoint point) {
		return block[point.getX()][point.getY()];
	}

	public int getBlock(NdPoint point) {
		return getBlock(Agent.ndPointToGridPoint(point));
	}

	public int[][] getBlock() {
		return block;
	}

	public double getFoodLevel(GridPoint p) {
		return getFoodLevel(p.getX(), p.getY());
	}

	public double getFoodLevel(int x, int y) {
		if (onDemandFoodUpdate) {
			if (foodPatch[x][y] != null) {
				return foodPatch[x][y].getValue();
			} else {
				return 0.0;
			}
		} else {
			return this.foodValue[x][y];
		}
	}

	public synchronized double eatFood(GridPoint point, double eatFraction) {
		double food = getFoodLevel(point.getX(), point.getY());

		if (food > 0.0) {
			double eaten = food * eatFraction;

			if (onDemandFoodUpdate) {
				this.foodPatch[point.getX()][point.getY()].eatFood(eaten);
			} else {
				this.foodValue[point.getX()][point.getY()] -= eaten;

				// The minimum food level has a strong impact on how fast food gets back
				if (Globals.ADD_ARTIFICIAL_FOOD && this.foodValue[point.getX()][point.getY()] < 0.01) {
					this.foodValue[point.getX()][point.getY()] = 0.01;
				}
			}

			return eaten;
		} else {
			return 0.0;
		}
	}

	public double[][] getFoodProb() {
		return this.foodProb;
	}

	public double getFoodProb(NdPoint p) {
		return getFoodProb(Agent.ndPointToGridPoint(p));
	}

	public double getFoodProb(GridPoint p) {
		return this.foodProb[p.getX()][p.getY()];
	}

	public double[][] getFoodValue() {
		if (this.onDemandFood) {
			throw new RuntimeException("FoodValue array may not be accessed directly when we calculate food on demand");
		}

		return this.foodValue;
	}

	public boolean isPointMasked(GridPoint p) {
		return isPointMasked(p.getX(), p.getY());
	}

	public boolean isPointMasked(int x, int y) {
		if (mask != null) {
			return mask[x][y];
		} else {
			return false;
		}
	}

	public double getMaxEnt(NdPoint p) {
		return getMaxEnt(Agent.ndPointToGridPoint(p));
	}

	public double getMaxEnt(GridPoint p) {
		return getMaxEnt()[p.getX()][p.getY()];
	}

	public double[][] getMaxEnt() {
		switch (Globals.getQuarterOfYear()) {
		case 0:
			return this.quarter1;
		case 1:
			return this.quarter2;
		case 2:
			return this.quarter3;
		case 3:
			return this.quarter4;
		}

		throw new RuntimeException("implementation error");
	}

	public double[][] getBlockValues() {
		switch (Globals.getQuarterOfYear()) {
		case 0:
			return this.blockValQuarter1;
		case 1:
			return this.blockValQuarter2;
		case 2:
			return this.blockValQuarter3;
		case 3:
			return this.blockValQuarter4;
		}

		throw new RuntimeException("implementation error");

	}

	public Pair[] getFoodProbAboveZeroPatches() {
		return this.foodProbAboveZeroCells;
	}

	public Future<?> initializeFoodPatches() {
		final CellData c = this;
		Runnable r = new Runnable() {
			public void run() {
				double[][] maxEnt = c.getMaxEnt();

				for (int i = 0; i < foodProb.length; i++) {
					for (int j = 0; j < foodProb[0].length; j++) {
						if (foodProb[i][j] > 0 && maxEnt[i][j] > 0) {
							foodValue[i][j] = Globals.MAX_U * maxEnt[i][j]
									/ Globals.MEAN_MAXENT_IN_QUATERS[Globals.getQuarterOfYear()];
						} else {
							foodValue[i][j] = 0;
						}
					}
				}
			}
		};

		return Globals.THREAD_POOL.submit(r);
	}

}
