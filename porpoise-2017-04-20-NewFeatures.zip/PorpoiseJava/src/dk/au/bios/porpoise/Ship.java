/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise;

import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.continuous.NdPoint;
import repast.simphony.space.grid.Grid;

/**
 * A ship agent. This is used in the Kattegat simulation and is not relevant for the current DEPONS model.
 */
public class Ship extends SoundSource {

	private NdPoint[] route;
	private int nextPoint;
	private double speed;
	private boolean forward = true;
	private String name;

	public Ship(ContinuousSpace<Agent> space, Grid<Agent> grid, NdPoint[] route, double impact, double speed,
			String name) {
		super(space, grid, impact);
		this.route = route;
		this.speed = speed;
		this.name = name;
		this.forward = false;
		this.nextPoint = -1;
	}

	public void initialize() {
		int pastLoc = Globals.RANDOM_SOURCE.pastLoc(name, route.length);

		if (pastLoc == route.length - 1) {
			// we are at the end and will move backward
			this.forward = false;
			this.nextPoint = pastLoc - 1;
		} else {
			this.forward = true;
			this.nextPoint = pastLoc + 1;

		}

		this.setPosition(route[pastLoc]);
		facePoint(route[nextPoint]);
	}

	@ScheduledMethod(start = 0, interval = 1, priority = Globals.PRIO_SHIP_MOVE)
	public void move() {
		double moveLength = 2.5 * this.speed / 2; // km / t to steps / 30 min

		// approaching next location on route?
		if (distanceXY(this.route[nextPoint]) <= moveLength) {
			// check wheter position numbers should increase, or if ships should turn around:
			if (forward) {
				this.nextPoint++;
				if (this.nextPoint >= this.route.length) {
					this.nextPoint -= 2;
					forward = false;
				}
			} else {
				this.nextPoint--;
				if (this.nextPoint < 0) {
					this.nextPoint += 2;
					forward = true;
				}
			}

			facePoint(this.route[this.nextPoint]);
		}

		forward(moveLength);
	}

	public double getSpeed() {
		return this.speed;
	}

	public String toString() {
		return name;
	}

}
