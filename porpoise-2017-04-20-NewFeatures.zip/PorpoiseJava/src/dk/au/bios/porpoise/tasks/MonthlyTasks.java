/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.tasks;

import java.text.DecimalFormat;

import repast.simphony.engine.schedule.IAction;
import dk.au.bios.porpoise.Globals;

/**
 * A scheduled action to run some code once a (simulation) month.
 */
public class MonthlyTasks implements IAction {

	private long startTime;
	private DecimalFormat format = new DecimalFormat("#0.00");

	public MonthlyTasks() {
		startTime = System.nanoTime();
	}

	@Override
	public void execute() {
		long diff = System.nanoTime() - startTime;

		if (Globals.getDayOfSimulation() > 0) {
			double timePerDay = (diff / (double) Globals.getDayOfSimulation()) / 1000000000;
			System.out.println(format.format(timePerDay) + " seconds per day of simulation");
			int simYears = 30;
			if (Globals.SIM_YEARS != null) {
				simYears = Globals.SIM_YEARS;
			}
			double minutesForSimulation = simYears * 360 * timePerDay / 60;
			double minutesRemaining = ((simYears * 360) - Globals.getDayOfSimulation()) * timePerDay / 60;

			int year = Globals.getYearOfSimulation();
			int month = Globals.getMonthOfYear();
			int quarter = Globals.getQuarterOfYear() + 1;

			System.out.println("y:" + year + " m: " + month + " q: " + quarter + " - " + simYears
					+ " Years simulated in " + format.format(minutesForSimulation) + " minutes. "
					+ format.format(minutesRemaining) + " minutes remaining of simulation.");
		}
	}

}
