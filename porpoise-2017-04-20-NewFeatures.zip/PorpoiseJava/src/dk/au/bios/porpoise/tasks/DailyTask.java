/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.tasks;

import java.util.LinkedList;

import repast.simphony.context.Context;
import repast.simphony.engine.schedule.IAction;
import dk.au.bios.porpoise.Agent;
import dk.au.bios.porpoise.Porpoise;

/**
 * A scheduled action to run some code once a (simulation) day.
 */
public class DailyTask implements IAction {
	private Context<Agent> context;

	public DailyTask(Context<Agent> context) {
		this.context = context;
	}

	/**
	 * Things to do daily or less often.
	 */
	@Override
	public void execute() {
		// The porpoise can die and will then dissapear from the context, that will cause an 
		// java.util.ConcurrentModificationException if we iterate the context.
		// We therefore create a copy of the porpoises we want to visit.
		LinkedList<Porpoise> porpoises = new LinkedList<Porpoise>();
		for (Agent a : this.context.getObjects(Porpoise.class)) {
			porpoises.add((Porpoise) a);
		}

		for (Porpoise p : porpoises) {
			// Update daily average energy level and corresponding positions for porps and use it to start/stop dispersing
			p.performDailyStep();
		}
	}

}
