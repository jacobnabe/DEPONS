/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.tasks;

import java.util.LinkedList;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

import repast.simphony.engine.schedule.IAction;
import dk.au.bios.porpoise.BackgroundAgent;
import dk.au.bios.porpoise.CellData;
import dk.au.bios.porpoise.Globals;
import dk.au.bios.porpoise.util.Pair;

/** 
 * Scheduled action responsible for the growing of food.
 */
public class FoodTask implements IAction {

	private CellData data;

	/**
	 * The number of patches where the food has been grown 47 times extra
	 */
	public static AtomicInteger EXTRA_GROWTH_COUNT = new AtomicInteger();

	double[][] foodProb;
	double[][] foodLevel;
	double[][] maxEnt;

	public FoodTask(CellData data) {
		this.data = data;
		this.foodProb = data.getFoodProb();
		this.foodLevel = data.getFoodValue();
	}

	@Override
	public void execute() {
		EXTRA_GROWTH_COUNT.set(0);

		// Get the right ent for the season
		this.maxEnt = data.getMaxEnt();

		// executeSingleThreadBruteForce(); // (0.30 seconds per day)
		// executeSingleThreadOptimized(); // (0.22 seconds per day)
		executeParallel(4096); // (0.23 seconds per day)
	}

	public void executeSingleThreadOptimized() {
		double grownFood = 0;
		Pair[] points = this.data.getFoodProbAboveZeroPatches();

		for (int idx = 0; idx < points.length; idx++) {
			int i = points[idx].first;
			int j = points[idx].second;

			// If we add food when eating then we do not want to add it here. (ADD_ARTIFICAL_FOOD = true)
			// If we do not add food in the eat step then we need to add it before calculating the food growth 
			// - otherwise the food growth can start on really small amounts which leads to very small increases (the patch is basically dead, and the 47 extra calcs is not sufficient to restore it). 
			if (!Globals.ADD_ARTIFICIAL_FOOD && foodLevel[i][j] < 0.01) {
				foodLevel[i][j] = 0.01;
			}

			if (foodLevel[i][j] < (Globals.MAX_U * maxEnt[i][j])) {
				double fLevel = foodLevel[i][j]
						+ (Globals.FOOD_GROWTH_RATE * foodLevel[i][j] * (1.0 - foodLevel[i][j]
								/ (Globals.MAX_U * maxEnt[i][j] / Globals.MEAN_MAXENT_IN_QUATERS[Globals
										.getQuarterOfYear()])));

				if (Math.abs(fLevel - foodLevel[i][j]) > Globals.REGROWTH_FOOD_QUALIFIER) {
					for (int k = 0; k < 47; k++) {
						fLevel = fLevel
								+ (Globals.FOOD_GROWTH_RATE * fLevel * (1.0 - fLevel
										/ (Globals.MAX_U * maxEnt[i][j] / Globals.MEAN_MAXENT_IN_QUATERS[Globals
												.getQuarterOfYear()])));
					}

					EXTRA_GROWTH_COUNT.incrementAndGet();
				}

				grownFood += (fLevel - foodLevel[i][j]);
				foodLevel[i][j] = fLevel;
			}
		}
		BackgroundAgent.setGrownFood(grownFood);
	}

	public void executeSingleThreadBruteForce() {
		// maxent-level is patch specific, between 0 and 1 (MAXENT-based); food-growth-rate (rU) is global variable
		double grownFood = 0;

		for (int i = 0; i < foodProb.length; i++) {
			for (int j = 0; j < foodProb[0].length; j++) {
				if (foodProb[i][j] > 0 && foodLevel[i][j] < (Globals.MAX_U * maxEnt[i][j])) {
					if (!Globals.ADD_ARTIFICIAL_FOOD && foodLevel[i][j] < 0.01) {
						foodLevel[i][j] = 0.01;
					}

					double fLevel = foodLevel[i][j]
							+ (Globals.FOOD_GROWTH_RATE * foodLevel[i][j] * (1.0 - foodLevel[i][j]
									/ (Globals.MAX_U * maxEnt[i][j] / Globals.MEAN_MAXENT_IN_QUATERS[Globals
											.getQuarterOfYear()])));

					if (Math.abs(fLevel - foodLevel[i][j]) > Globals.REGROWTH_FOOD_QUALIFIER) {
						for (int k = 0; k < 47; k++) {
							fLevel += Globals.FOOD_GROWTH_RATE
									* fLevel
									* (1 - fLevel
											/ (Globals.MAX_U * maxEnt[i][j] / Globals.MEAN_MAXENT_IN_QUATERS[Globals
													.getQuarterOfYear()]));
						}
						EXTRA_GROWTH_COUNT.incrementAndGet();
					}
					// If the food level is really low, let food grow 48 times -- like growing every half-hour step, only faster

					grownFood += (fLevel - foodLevel[i][j]);

					foodLevel[i][j] = fLevel;
					// here maxent-level is MAXENT prediction and food-growth-rate is a universal calibrated variable
				}
			}
		}

		BackgroundAgent.setGrownFood(grownFood);
	}

	private void executeParallel(int chunkSize) {
		// We have 4572 patches with foodProb > 0, break them into chunkSize point big jobs
		Pair[] points = this.data.getFoodProbAboveZeroPatches();
		LinkedList<Future<Boolean>> tasks = new LinkedList<Future<Boolean>>();

		int from = 0;
		int to = chunkSize;

		while (from < points.length) {
			if (to < points.length) {
				tasks.add(Globals.THREAD_POOL.submit(new Task(points, from, to)));
			} else {
				tasks.add(Globals.THREAD_POOL.submit(new Task(points, from, points.length)));
			}

			from = to;
			to += chunkSize;
		}

		for (Future<Boolean> f : tasks) {
			try {
				f.get();
			} catch (InterruptedException | ExecutionException e) {
				e.printStackTrace();
			}
		}
	}

	private class Task implements Callable<Boolean> {
		// private CellData data;
		private Pair[] points;
		private int from;
		private int to;

		public Task(Pair[] points, int from, int to) {
			this.from = from;
			this.to = to;
			this.points = points;
		}

		@Override
		public Boolean call() throws Exception {
			for (int idx = from; idx < to; idx++) {
				int i = points[idx].first;
				int j = points[idx].second;

				if (!Globals.ADD_ARTIFICIAL_FOOD && foodLevel[i][j] < 0.01) {
					foodLevel[i][j] = 0.01;
				}

				if (foodLevel[i][j] < (Globals.MAX_U * maxEnt[i][j])) {
					double fLevel = foodLevel[i][j]
							+ (Globals.FOOD_GROWTH_RATE * foodLevel[i][j] * (1.0 - foodLevel[i][j]
									/ (Globals.MAX_U * maxEnt[i][j] / Globals.MEAN_MAXENT_IN_QUATERS[Globals
											.getQuarterOfYear()])));

					if (Math.abs(fLevel - foodLevel[i][j]) > Globals.REGROWTH_FOOD_QUALIFIER) {
						for (int k = 0; k < 47; k++) {
							fLevel += Globals.FOOD_GROWTH_RATE
									* fLevel
									* (1 - fLevel
											/ (Globals.MAX_U * maxEnt[i][j] / Globals.MEAN_MAXENT_IN_QUATERS[Globals
													.getQuarterOfYear()]));
						}
						EXTRA_GROWTH_COUNT.incrementAndGet();
					}

					foodLevel[i][j] = fLevel;
				}
			}
			return true;
		}
	}

}
