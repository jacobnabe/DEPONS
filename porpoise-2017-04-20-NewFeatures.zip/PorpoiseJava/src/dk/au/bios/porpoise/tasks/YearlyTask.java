/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.tasks;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.TreeMap;

import repast.simphony.context.Context;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.engine.environment.RunState;
import repast.simphony.engine.schedule.IAction;
import dk.au.bios.porpoise.Agent;
import dk.au.bios.porpoise.Globals;
import dk.au.bios.porpoise.Porpoise;

/**
 * This executes annually. It currently performs two tasks, setting the random mating day of each porpoise for the year
 * and outputs some age and death statistics. This should be refactored to be in two different classes.
 */
public class YearlyTask implements IAction {

	private static Map<Integer, Integer> deathsAgeDistribution;

	private Context<Agent> context;

	private PrintWriter annualStatisticsOutput = null;

	public YearlyTask(Context<Agent> context) {
		resetDeathAgeDistribution(); // Initialization of a static member here is a bit messy but needed to collect the statistics!

		this.context = context;

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MMM.dd.HH_mm_ss_SS");
		File annualStatisticsOutputFile = new File("YearlyMortality." + sdf.format(new Date()) + ".csv");
		try {
			annualStatisticsOutput = new PrintWriter(annualStatisticsOutputFile);
			if (RunEnvironment.getInstance().isBatch()) {
				annualStatisticsOutput.printf("\"run\",");
			}
			annualStatisticsOutput.printf("\"year\",\"age\",\"count\",\"deaths\"%n");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void resetDeathAgeDistribution() {
		deathsAgeDistribution = new TreeMap<>();
		for (int i = 0; i <= Globals.MAX_AGE; i++) {
			deathsAgeDistribution.put(i, 0);
		}
	}

	public static void recordDeath(int age) {
		deathsAgeDistribution.put(age, deathsAgeDistribution.get(age) + 1);
	}

	@Override
	public void execute() {
		/* Key is age (years) and value is count (incremented) */
		Map<Integer, Integer> ageDistribution = new TreeMap<>();
		for (int i = 0; i <= Globals.MAX_AGE; i++) {
			ageDistribution.put(i, 0);
		}

		for (Agent a : this.context.getObjects(Porpoise.class)) {
			Porpoise p = (Porpoise) a;
			p.setRandomMatingDay();

			int pAge = (int) Math.floor(p.getAge());
			ageDistribution.put(pAge, ageDistribution.get(pAge) + 1);
		}

		// Make list of number of dead per age class and corresp pop nos in prev year
		ageDistribution.forEach((k, v) -> {
			if (RunEnvironment.getInstance().isBatch()) {
				annualStatisticsOutput.printf("%d,", RunState.getInstance().getRunInfo().getRunNumber());
			}
			annualStatisticsOutput.printf("%d,%d,%d,%d%n", Globals.getYearOfSimulation(), k, v,
					deathsAgeDistribution.get(k));
		});
		annualStatisticsOutput.flush();
		resetDeathAgeDistribution();
	}

}
