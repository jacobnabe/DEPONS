/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.tasks;

import repast.simphony.context.Context;
import repast.simphony.engine.schedule.IAction;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.grid.Grid;
import dk.au.bios.porpoise.Agent;
import dk.au.bios.porpoise.Porpoise;
import dk.au.bios.porpoise.SoundSource;
import dk.au.bios.porpoise.Turbine;

/**
 * The scheduled action calling the deterrence functionality.
 */
public class DeterenceTask implements IAction {

	private Context<Agent> context;
	private ContinuousSpace<Agent> space;
	private Grid<Agent> grid;

	public DeterenceTask(Context<Agent> context, ContinuousSpace<Agent> space, Grid<Agent> grid) {
		this.context = context;
	}

	@Override
	public void execute() {
		for (Agent a : this.context.getObjects(Porpoise.class)) {
			((Porpoise) a).updateDeterence();
		}

		Turbine.activateTurbines(context, space, grid);

		for (Agent a : this.context.getObjects(Turbine.class)) {
			((Turbine) a).deterPorpoise();
		}
		for (Agent a : this.context.getObjects(SoundSource.class)) {
			((SoundSource) a).deterPorpoise();
		}

		Turbine.deactiveTurbines(context);
	}

}
