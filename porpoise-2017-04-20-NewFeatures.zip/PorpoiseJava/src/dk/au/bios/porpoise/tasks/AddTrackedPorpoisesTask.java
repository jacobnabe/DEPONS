/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.tasks;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import repast.simphony.context.Context;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.engine.schedule.IAction;
import repast.simphony.engine.schedule.ISchedule;
import repast.simphony.engine.schedule.ScheduleParameters;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.continuous.NdPoint;
import repast.simphony.space.grid.Grid;
import dk.au.bios.porpoise.Agent;
import dk.au.bios.porpoise.Globals;
import dk.au.bios.porpoise.Porpoise;
import dk.au.bios.porpoise.RandomPorpoiseReportProxy;

/**
 * A scheduled action to run some code once a (simulation) day.
 */
public class AddTrackedPorpoisesTask implements IAction {

	private final Context<Agent> context;
	private final ContinuousSpace<Agent> space;
	private final Grid<Agent> grid;
	private final String landscape;
	private final int trackedPorpoisesCount;

	// Used in case of delayed selection
	private int tick;
	private double locX;
	private double locY;

	public AddTrackedPorpoisesTask(final Context<Agent> context, final ContinuousSpace<Agent> space,
			final Grid<Agent> grid, final String landscape, final int trackedPorpoisesCount) {
		this.context = context;
		this.space = space;
		this.grid = grid;
		this.landscape = landscape;
		this.trackedPorpoisesCount = trackedPorpoisesCount;
	}

	public void setup() {
		Path trackedPorpoisePath = Paths.get("data", landscape, "/trackedporpoise.txt");
		List<String> trackedPorpoiseLocations = Collections.emptyList();
		if (Files.exists(trackedPorpoisePath)) {
			try {
				trackedPorpoiseLocations = Files.readAllLines(trackedPorpoisePath);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		String delayedSelection = null;
		for (String tpl : trackedPorpoiseLocations) {
			if (tpl.startsWith("delayedSelection;")) {
				delayedSelection = tpl;
				break;
			}
		}

		if (delayedSelection != null) {
			String[] delayedSelectionParts = delayedSelection.substring("delayedSelection;".length()).split(",");
			this.tick = Integer.valueOf(delayedSelectionParts[0]);
//			this.locX = (Double.valueOf(delayedSelectionParts[1]) - Globals.XLLCORNER) / 400;
//			this.locY = (Double.valueOf(delayedSelectionParts[2]) - Globals.YLLCORNER) / 400;
			this.locX = (Double.parseDouble(delayedSelectionParts[1]) - Globals.XLLCORNER) / 400;
			this.locY = (Double.parseDouble(delayedSelectionParts[2]) - Globals.YLLCORNER) / 400;
//			this.locX = Double.valueOf(delayedSelectionParts[1]);
//			this.locY = Double.valueOf(delayedSelectionParts[2]);

			ISchedule schedule = RunEnvironment.getInstance().getCurrentSchedule();
			ScheduleParameters schedParams = ScheduleParameters.createOneTime(this.tick, Globals.PRIO_DAILY);
			schedule.schedule(schedParams, this);
		} else {
			Iterable<Agent> agents = context.getRandomObjects(Porpoise.class, trackedPorpoisesCount);
			int ti = 0;
			for (Agent a : agents) {
				Porpoise p = (Porpoise) a;

				RandomPorpoiseReportProxy randomPorpoiseAgent = new RandomPorpoiseReportProxy(space, grid, 1, p);
				if (trackedPorpoiseLocations.size() > ti) {
					String[] locParams = trackedPorpoiseLocations.get(ti).split(",");
					double locX = (Double.parseDouble(locParams[0]) - Globals.XLLCORNER) / 400;
					double locY = (Double.parseDouble(locParams[1]) - Globals.YLLCORNER) / 400;
					randomPorpoiseAgent.getPorpoise().setPosition(new NdPoint(locX, locY));
					randomPorpoiseAgent.getPorpoise().reinitializePoslist();
					randomPorpoiseAgent.getPorpoise().setHeading(Double.parseDouble(locParams[2]));
				}
				context.add(randomPorpoiseAgent);
				ti++;

				randomPorpoiseAgent.getPorpoise().setTrackVisitedCells(true);
				randomPorpoiseAgent.getPorpoise().setWritePsmSteps(true);
			}
		}
	}

	/**
	 * Method called if the selection is delayed
	 */
	@Override
	public void execute() {
		List<Porpoise> porpoisesToTrack = getClosestPorpoises(new NdPoint(locX, locY), trackedPorpoisesCount);
		for (Porpoise p : porpoisesToTrack) {
			RandomPorpoiseReportProxy randomPorpoiseAgent = new RandomPorpoiseReportProxy(space, grid, 1, p);
			context.add(randomPorpoiseAgent);

			randomPorpoiseAgent.getPorpoise().setTrackVisitedCells(true);
			randomPorpoiseAgent.getPorpoise().setWritePsmSteps(true);
		}
	}

	/**
	 * Return a number of porpoises closest to a point. This is not an optimized implementation!
	 * 
	 * @param point
	 * @param numPorpoises
	 * @return
	 */
	private List<Porpoise> getClosestPorpoises(final NdPoint point, final int numPorpoises) {
		List<Porpoise> allPorps = new ArrayList<Porpoise>();
		Iterable<Agent> agents = space.getObjects();
		for (Agent a : agents) {
			if (a instanceof Porpoise) {
				Porpoise p = (Porpoise) a;
				allPorps.add(p);
			}
		}
		Collections.sort(allPorps, new Comparator<Porpoise>() {

			@Override
			public int compare(Porpoise p1, Porpoise p2) {
				double p1Dist = space.getDistance(point, p1.getPosition());
				double p2Dist = space.getDistance(point, p2.getPosition());
				return (int)p1Dist - (int)p2Dist;
			}
		});
		
		List<Porpoise> selectedPorps = new ArrayList<>(numPorpoises);
		for (int i = 0; i < allPorps.size() && i < numPorpoises; i++) {
			selectedPorps.add(allPorps.get(i));
		}

		return selectedPorps;
	}

}
