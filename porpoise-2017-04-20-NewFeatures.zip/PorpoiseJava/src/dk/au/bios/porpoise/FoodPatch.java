/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise;

import java.util.concurrent.atomic.AtomicLong;

import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.grid.Grid;
import repast.simphony.space.grid.GridPoint;

/**
 * Symbolizes a food patch in the model.
 */
public class FoodPatch extends Agent {

	private static AtomicLong nextId = new AtomicLong(0);
	private GridPoint location;
	private CellData data;

	protected FoodPatch(ContinuousSpace<Agent> space, Grid<Agent> grid, GridPoint location, CellData data) {
		super(space, grid, nextId.incrementAndGet());
		this.location = location;
		this.data = data;
	}

	public double getFoodValue() {
		return this.data.getFoodLevel(location);
	}

	public double getMaxEnt() {
		return this.data.getMaxEnt(location);
	}
}
