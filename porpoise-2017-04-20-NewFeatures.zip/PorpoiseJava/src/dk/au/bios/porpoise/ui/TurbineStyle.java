/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.ui;

import java.awt.Color;
import java.awt.Shape;
import java.awt.geom.GeneralPath;

import repast.simphony.gis.styleEditor.SimpleMarkFactory;
import repast.simphony.visualizationOGL2D.DefaultStyleOGL2D;
import saf.v3d.ShapeFactory2D;
import saf.v3d.scene.VSpatial;
import dk.au.bios.porpoise.Globals;
import dk.au.bios.porpoise.Turbine;

/**
 * The visual style for a Turbine. This color-codes the turbine based on the start and end ticks.
 */
public class TurbineStyle extends DefaultStyleOGL2D {

	private static SimpleMarkFactory markFac = new SimpleMarkFactory();

	@Override
	public void init(ShapeFactory2D factory) {
		super.init(factory);
	}

	@Override
	public VSpatial getVSpatial(Object agent, VSpatial spatial) {
		if (spatial == null) {
			Shape mark = markFac.getMark("X");
			GeneralPath path = new GeneralPath(mark);
			path.closePath();
			spatial = shapeFactory.createShape(path, true);
		}

		return spatial;
	}

	@Override
	public Color getColor(Object object) {
		Turbine t;
		if (object instanceof Turbine) {
			t = (Turbine) object;
		} else {
			return Color.BLACK;
		}

		double tickNow = Globals.getTick();
		if (tickNow < t.getStartTick()) {
			return Color.GRAY;
		} else if (tickNow > t.getEndTick()) {
			return Color.DARK_GRAY;
		} else {
			// larger than startTick and smaller than endTick
			return Color.RED;
		}
	}

	@Override
	public float getRotation(Object object) {
		return 0;
	}

	@Override
	public float getScale(Object object) {
		return 10;
	}

}
