/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.ui;

import java.awt.Color;

import repast.simphony.gis.styleEditor.SimpleMarkFactory;
import repast.simphony.visualizationOGL2D.DefaultStyleOGL2D;
import saf.v3d.ShapeFactory2D;
import saf.v3d.scene.VSpatial;
import dk.au.bios.porpoise.FoodPatch;
import dk.au.bios.porpoise.Globals;

/**
 * The visual style for the FoodPatch agent.
 */
public class FoodPatchStyle extends DefaultStyleOGL2D {

	private static SimpleMarkFactory markFac = new SimpleMarkFactory();

	@Override
	public void init(ShapeFactory2D factory) {
		super.init(factory);
	}

	@Override
	public VSpatial getVSpatial(Object agent, VSpatial spatial) {
		if (spatial == null) {
			spatial = shapeFactory.createShape(markFac.getMark("square"), true);
		}
		return spatial;
	}

	@Override
	public Color getColor(Object object) {
		if (object instanceof FoodPatch) {
			FoodPatch p = (FoodPatch) object;

			double foodValue = p.getFoodValue();
			double maxU = Globals.MAX_U;

			if (foodValue <= 0) {
				return Color.WHITE;
			} else if (foodValue <= 0.02 * maxU) {
				return Color.RED;
			} else if (foodValue <= 0.1 * maxU) {
				return Color.PINK;
			} else if (foodValue <= 0.25 * maxU) {
				return Color.ORANGE;
			} else if (foodValue <= 0.5 * maxU) {
				return Color.YELLOW;
			} else {
				return Color.GREEN;
			}
		}

		return Color.MAGENTA;
	}

	@Override
	public float getScale(Object object) {
		return 2;
	}

}
