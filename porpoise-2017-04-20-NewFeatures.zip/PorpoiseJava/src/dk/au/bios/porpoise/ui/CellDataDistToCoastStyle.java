/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.ui;

import java.awt.Color;
import java.awt.image.BufferedImage;

import repast.simphony.visualizationOGL2D.DefaultStyleOGL2D;
import saf.v3d.ShapeFactory2D;
import saf.v3d.scene.VSpatial;
import dk.au.bios.porpoise.Globals;
import dk.au.bios.porpoise.agents.misc.CellDataDistToCoastAgent;

/**
 * The visual style for the CellDataDistToCoast. Renders the distance to the coast based on the data in CellData.
 */
public class CellDataDistToCoastStyle extends DefaultStyleOGL2D {

	@Override
	public void init(ShapeFactory2D factory) {
		super.init(factory);
	}

	@Override
	public VSpatial getVSpatial(Object agent, VSpatial spatial) {
		CellDataDistToCoastAgent ba = (CellDataDistToCoastAgent) agent;

		if (spatial == null) {
			BufferedImage bi = new BufferedImage(Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT, BufferedImage.TYPE_INT_ARGB);

			spatial = shapeFactory.createImage("test", bi);

			// Not really fast, but we only need to do this at startup 
			for (int x = 0; x < Globals.WORLD_WIDTH; x++) {
				for (int y = 0; y < Globals.WORLD_HEIGHT; y++) {
					bi.setRGB(x, y, ba.getPointRGB(x, y));
				}
			}
		}

		return spatial;
	}

	@Override
	public Color getColor(Object object) {
		return Color.MAGENTA;
	}

	@Override
	public float getScale(Object object) {
		return 2.5f;
	}

}
