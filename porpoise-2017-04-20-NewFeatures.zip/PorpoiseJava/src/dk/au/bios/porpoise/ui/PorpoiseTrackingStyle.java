/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.ui;

import java.awt.Color;

import repast.simphony.visualizationOGL2D.DefaultStyleOGL2D;
import saf.v3d.scene.VImage2D;
import saf.v3d.scene.VSpatial;

import com.aragost.repast.ui.UpdatableTexture2D;

import dk.au.bios.porpoise.agents.misc.TrackingDisplayAgent;

/**
 * The visual style for the TrackingDisplayAgent. This holds the updateable image used to display the tracking paths of
 * one or more tracked porpoises.
 */
public class PorpoiseTrackingStyle extends DefaultStyleOGL2D {

	private UpdatableTexture2D td;

	@Override
	public VSpatial getVSpatial(Object agent, VSpatial spatial) {
		TrackingDisplayAgent tda = (TrackingDisplayAgent) agent;
		if (spatial == null) {
			td = new UpdatableTexture2D(tda.getImage(), tda.getDirtyRegion());
			spatial = new VImage2D(td);
			// spatial = new VImage2D(new Texture2D(tda.getImage()));
		}

		return spatial;
	}

	@Override
	public Color getColor(Object object) {
		return Color.MAGENTA;
	}

	@Override
	public float getScale(Object object) {
		return 2.5f;
	}

}
