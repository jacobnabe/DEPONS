/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.ui;

import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JTable;

/**
 * A custom user panel for the Repast UI. This is not currently being used. The file is being kept in case it will be
 * used in the future.
 */
public class PorpoiseUserPanel extends JPanel {

	private static final long serialVersionUID = 1L;

	private JTable statisticsTable;

	public PorpoiseUserPanel() {
		this.setLayout(new GridLayout(1, 1));

		JPanel statisticsPanel = new JPanel();
		statisticsPanel.setBorder(BorderFactory.createTitledBorder("Statistics"));

		String[] colNames = { "Statistic", "Value" };
		Object[][] values = { { "Number of Births: ", 0 }, { "Number of Deaths: ", 0 },
				{ "Number of Deaths by Starvation: ", 0 }, { "Number of Deaths by Old Age: ", 0 },
				{ "Number of Deaths by By Catch: ", 0 }, };
		statisticsTable = new JTable(values, colNames);
		statisticsPanel.setLayout(new BorderLayout());
		statisticsPanel.add(statisticsTable, BorderLayout.NORTH);
		this.add(statisticsPanel);
	}

	public void setNumberOfBirths(int numBirths) {
		this.statisticsTable.getModel().setValueAt(numBirths, 0, 1);
	}

	public void setNumberOfDeaths(int numDeaths) {
		this.statisticsTable.getModel().setValueAt(numDeaths, 1, 1);
	}

	public void setNumberOfDeathsStarvation(int numDeaths) {
		this.statisticsTable.getModel().setValueAt(numDeaths, 2, 1);
	}

	public void setNumberOfDeathsByOldAge(int numDeaths) {
		this.statisticsTable.getModel().setValueAt(numDeaths, 3, 1);
	}

	public void setNumberOfDeathsByByCatch(int numDeaths) {
		this.statisticsTable.getModel().setValueAt(numDeaths, 4, 1);
	}

}
