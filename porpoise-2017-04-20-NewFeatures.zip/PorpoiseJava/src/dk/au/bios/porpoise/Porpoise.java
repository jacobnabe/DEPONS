/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 * 
 * This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 * License version 2 and only version 2 as published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with this program; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

package dk.au.bios.porpoise;

import java.text.DecimalFormat;

import repast.simphony.context.Context;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.Dimensions;
import repast.simphony.space.SpatialMath;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.continuous.NdPoint;
import repast.simphony.space.continuous.PointTranslator;
import repast.simphony.space.grid.Grid;
import repast.simphony.space.grid.GridPoint;
import dk.au.bios.porpoise.agents.misc.TrackingDisplayAgent;
import dk.au.bios.porpoise.behavior.Dispersal;
import dk.au.bios.porpoise.behavior.DispersalOff;
import dk.au.bios.porpoise.behavior.DispersalPSMType1;
import dk.au.bios.porpoise.behavior.DispersalPSMType2;
import dk.au.bios.porpoise.behavior.PersistentSpatialMemory;
import dk.au.bios.porpoise.behavior.RefMemTurnCalculator;
import dk.au.bios.porpoise.tasks.YearlyTask;
import dk.au.bios.porpoise.util.CircularBuffer;
import dk.au.bios.porpoise.util.test.PorpoiseTestDataCapturer;

/**
 * A Porpoise, a primary agent in the simulation.
 */
public class Porpoise extends Agent {

	private Context<Agent> context;
	private CellData cellData;
	private double energyConsumedDailyTemp; // The energy spent today by the porpoise - At the end of the day it becomes "energyConsumedDaily"
	private double energyConsumedDaily; // The energy consumed yesterday by the porpoise
	private double foodEatenDailyTemp; // The energy so far today.
	private double foodEatenDaily; // The energy eaten yesterday by the porpoise

	private double age; // Age in years (remember, 360 days per year)
	private double ageOfMaturity; // Age when becoming receptive, in years
	private byte pregnancyStatus; // 0 (unable to mate, young/low energy); 1 (unable to mate, pregnant); 2 (ready to mate)
	private int matingDay; // Day of year. Most mating occurs in August (Lockyer 2003)
	private int daysSinceMating; // Days since mating. -99 if not pregnant
	private int daysSinceGivingBirth; // Days since giving birth. -99 if not with lactating calf
	private boolean withLactCalf; // true/false, with lactating calf
	private double energyLevel; // Porpoises get energy by eating and loose energy by moving.
	private double energyLevelSum; // Sum of energy levels. Reset to 0 every day
	private CircularBuffer<Double> energyLevelDaily; // List with average energy for last ten days. Latest days first.
	private int dispNumTicks; // The number of ticks the porp has been dispersing for.
	private double prevAngle; // Last turning angle (not the heading!)
	private double presAngle; // Present turning angle
	private double prevLogMov; // Previous Log10 (move length [measured in 100-m steps])
	private double presLogMov; // Present Log10 (move length [measured in 100-m steps])
	private boolean enoughWaterAhead; // Turn to avoid land if false
	private CircularBuffer<NdPoint> posList; // Coordinates of previous positions -- one per 30 min
	private CircularBuffer<NdPoint> posListDaily; // Coordinates of previous 10 daily positions -- daily, corresponding to energy-level-daily
	private int ignoreDeterrence; // The number of steps to keep ignoring deterrence. While >0 then the deterrence vector is ignored.

	private CircularBuffer<Double> storedUtilList = new CircularBuffer<Double>(Globals.MEMORY_MAX); // Remembered feeding success (after memory decay)

	private double[] VT = new double[] { 0.0, 0.0 }; //resultant attraction vector, resulting from reference memory of food availability (model >=2)

	private double[] deterVt = new double[] { 0.0, 0.0 }; // Vector (= list) determining which direction a porp is deterred from wind turbines and ships, and how much
	private double deterStrength; // The strength of the deterrence, is adjusted based on Psi_deter every step while the porpoise is deterred.
	private int deterTimeLeft; // The number of steps remaining while the porpoise is deterred.
	private double VETotal; // Total value of food expected to be found in the future

	private double soundSourceDistance = -1;
	private double soundSourceAngle;
	private double soundSourceImpact = 10.0;
	private RefMemTurnCalculator refMemTurnCalculator;
	
	private Dispersal dispersalBehaviour;

	/**
	 * Used to adjust the step-length when the porpoise is moved in multiple parts during a tick. Value between 0.0 (no
	 * further movement) and 1.0 (no movement done yet). When the porpoise is moved, the caller is responsible for
	 * adjusting this value.
	 */
	private double tickMoveAdjustMultiplier = 1.0;

	/** Track whether the porpoise is alive. */
	private boolean alive = true;

	private final PersistentSpatialMemory psm; // Always enabled for now.
	private boolean trackVisitedCells = false;
	private boolean writePsmSteps = false;

	/**
	 * Constructor for a newborn porpoised.
	 * @param parent
	 */
	public Porpoise(Porpoise parent) {
		this(parent.space, parent.grid, parent.cellData, parent.context, 0, parent.refMemTurnCalculator, parent.psm.getPreferredDistance());
	}

	/**
	 * Constructor for a porpoise part of the initial population (not born during simulation)
	 *
	 * @param space
	 * @param grid
	 * @param cellData
	 * @param context
	 * @param age
	 * @param hatched
	 * @param refMemTurnCalculator
	 */
	public Porpoise(ContinuousSpace<Agent> space, Grid<Agent> grid, CellData cellData, Context<Agent> context,
			double age, RefMemTurnCalculator refMemTurnCalculator) {
		this(space, grid, cellData, context, age, refMemTurnCalculator, PersistentSpatialMemory.generatedPreferredDistance());

		if (age > 0) {
			// This is the model setup, there is a probability that the porpoise is with a lactating calf.
			// Notice: The probability is not dependent on the age of the porpoise if it is above the age of 0 .

			this.pregnancyStatus = 2;
			// become pregnanat with prob. taken from Read & Hohn 1995
			if (this.pregnancyStatus == 2
					&& Globals.RANDOM_SOURCE.nextPregnancyStatusConceive(0, 1) < Globals.CONCEIVE_PROB) {
				this.pregnancyStatus = 1;
				this.daysSinceMating = (int) (360 - Math.round(Globals.randomNormal(7.5 * 360 / 12, 20)));
			} else {
				this.pregnancyStatus = 0;
			}
		}
	}

	private Porpoise(ContinuousSpace<Agent> space, Grid<Agent> grid, CellData cellData, Context<Agent> context,
			double age, RefMemTurnCalculator refMemTurnCalculator, double psmPreferredDistance) {
		super(space, grid, Globals.PORPOISE_ID.getAndIncrement());
		this.cellData = cellData;
		this.posList = new CircularBuffer<NdPoint>(Globals.MEMORY_MAX);
		this.posListDaily = new CircularBuffer<NdPoint>(10);
		for (int i = 0; i < 10; i++) {
			this.posListDaily.add(new NdPoint(0, 0));
		}

		this.energyLevelDaily = new CircularBuffer<Double>(10);
		for (int i = 0; i < 10; i++) {
			this.energyLevelDaily.add(0.0);
		}

		this.refMemTurnCalculator = refMemTurnCalculator;
		this.context = context;
		this.psm = new PersistentSpatialMemory(this, Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT, cellData, psmPreferredDistance);

		switch (Globals.DISPERSAL_TYPE) {
		case Off:
			this.dispersalBehaviour = new DispersalOff();
			break;
		case PSM_Type1:
			this.dispersalBehaviour = new DispersalPSMType1(this);
			break;
		case PSM_Type2:
			this.dispersalBehaviour = new DispersalPSMType2(this);
			break;
		default:
			throw new RuntimeException("Unknown dispersal type.");
		}
		

		// Setup
		this.ageOfMaturity = Globals.MATURITY_AGE;
		this.energyLevel = Globals.RANDOM_SOURCE.nextEnergyNormal();
		this.prevLogMov = 0.8;
		this.prevAngle = 10;
		this.age = age;
	}

	@ScheduledMethod(start = 0, interval = 1, priority = Globals.PRIO_PORP_MOVE)
	public void move() {
		if (Globals.RANDOM_REPLAY_SOURCE != null) {
			DecimalFormat fmt = new DecimalFormat("0.###");

			NdPoint p = getPosition();

			int tick = (int) Globals.getTick();
			System.out.println("pos#" + tick + "#" + fmt.format(p.getX()) + "#" + fmt.format(p.getY()) + "#E"
					+ fmt.format(this.energyLevel) + "#H" + fmt.format(getHeading()) + "#D"
					+ fmt.format(this.deterVt[0]) + ";" + fmt.format(this.deterVt[1]));
			System.out.println("disp#" + tick + "#" + this.dispersalBehaviour.getDispersalType());
			Globals.replayPrint("pos#" + tick + "#" + fmt.format(p.getX()) + "#" + fmt.format(p.getY()) + "#E"
					+ fmt.format(this.energyLevel) + "#H" + fmt.format(getHeading()) + "#D"
					+ fmt.format(this.deterVt[0]) + ";" + fmt.format(this.deterVt[1]));
		}

		if (this.soundSourceDistance != -1) {
			new SoundSource(context, space, grid, this, this.soundSourceAngle, this.soundSourceDistance,
					this.soundSourceImpact);
			this.soundSourceDistance = -1;
		}

		this.tickMoveAdjustMultiplier = 1.0;

		// Dispersal step (before actual stdMove())
		if (isAlive()) {
			if (cellData.getDepth(ndPointToGridPoint(getPosition())) <= 0) {
				System.out.println("No water : " + cellData.getDepth(ndPointToGridPoint(getPosition())));
			}

			// Track the number of ticks dispersed
			if (!this.dispersalBehaviour.isDispersing()) {
				dispNumTicks = 0;
			} else {
				dispNumTicks++;
			}

			dispersalBehaviour.disperse();
		}

		if (isAlive()) {
			// Simple implementation
			if (Globals.MODEL == 1) {
				Globals.USE_EXP_FOOD_VAL = false;
				stdMove();
				// update position list:
				NdPoint pos = getPosition();
				this.posList.add(pos);
			} else if (Globals.MODEL == 2) {
				Globals.USE_EXP_FOOD_VAL = true;
	
				// get attracted to places where food was found. Influences direction moved in stdMove() through vector 'VT'
				double[] temp = this.refMemTurnCalculator.refMemTurn(this, cellData, storedUtilList, posList);
				if (temp != null) {
					VT = temp;
				}
	
				getExpFoodVal(); // determines the tendency to move following CRW behaviour based on foraging success in recent past
				if (!this.dispersalBehaviour.isDispersing()) {
					stdMove(); // this is where the porp moves forward
				}
				// update position list:
				NdPoint pos = getPosition();
				this.posList.add(pos);

				updEnergeticStatus(); // food level increases in 'go' -- affect the landscape and energetic status of the porpoise
	
			} else if (Globals.MODEL >= 3) {
				Globals.USE_EXP_FOOD_VAL = true;
	
				// get attracted to places where food was found. Influences direction moved in stdMove() through vector 'VT'
				double[] temp = this.refMemTurnCalculator.refMemTurn(this, cellData, storedUtilList, posList);
				if (temp != null) {
					VT = temp;
				}
	
				getExpFoodVal(); // determines the tendency to move following CRW behaviour based on foraging success in recent past
				if (!this.dispersalBehaviour.isDispersing()) {
					stdMove(); // this is where the porp moves forward and responds to noise by turning away
				}
				// update position list:
				NdPoint pos = getPosition();
				this.posList.add(pos);

				updEnergeticStatus(); // transform food to energy and spend energy based on step length. Food level in patches increases in 'go'
				// mortality and pregnancy status is set in class DailyTask for models > 4
			}
		
			PorpoiseTestDataCapturer.capture(this);
		}

		trackCellVisit();
	}

	/**
	 * Implementation of standard movement.
	 */
	private void stdMove() {
		// int startUtmX = getUtmX(); // PSM Verification
		// int startUtmY = getUtmY(); // PSM Verification
		// double startHeading = getHeading(); // PSM Verification

		double prevMov = Math.pow(10, this.prevLogMov); // Consider saving prevMov instead of calculating.
		double presHeading = getHeading();
		this.presAngle = 999;
		int j = 1;
		double tmpAngle = 0;

		// for increasing mean turning angle
		if (this.prevAngle < 0) {
			tmpAngle = this.prevAngle - 24;
		} else {
			tmpAngle = this.prevAngle + 24;
		}

		while (Math.abs(this.presAngle) > 180) {
			double ran = Globals.RANDOM_SOURCE.nextNormal_0_38();
			Globals.replayPrint("normal-0-38:{0}", ran);

			// Autoreg can't be used for estimating parameter as estimated turns are changed if on shallow water. 
			this.presAngle = tmpAngle * (-Globals.CORR_ANGLE) + ran;
			j++;
			if (j == 200) {
				this.presAngle = this.presAngle * 90 / Math.abs(this.presAngle);

				if (Globals.DEBUG == 3) {
					Globals.print("exiting loop 1, ang=" + this.presAngle);
				}
			}
		}

		Globals.replayPrint("std-move-1 pres-angle:{0} pres-heading: {1} tmp-angle: {2} heading:{3}", this.presAngle,
				presHeading, tmpAngle, getHeading());
		Globals.replayPrint("std-move-1 deter-vt:[{0} {1}]", this.deterVt[0], this.deterVt[1]);
		double sign = this.presAngle < 0 ? -1.0 : 1.0;

		this.presAngle = Math.abs(this.presAngle);
		// Make angle decrease linearly with mov-dist
		boolean goOn = true;

		j = 1;
		double rnd = 0;

		while (goOn) {
			rnd = Globals.RANDOM_SOURCE.nextNormal_96_28(); // draws the number to be added to presAngle
			Globals.replayPrint("normal-96-28:{0}", rnd);
			if (prevMov <= Globals.M) {
				this.presAngle = this.presAngle + rnd - (rnd * prevMov / Globals.M);
			}

			// remember that turning angle is unsigned here
			goOn = this.presAngle >= 180; // Continue while presAngle is 180 and above			

			j++;
			if (j == 200) {
				presAngle = Globals.RANDOM_SOURCE.nextStdMove(0, 20) + 90;  // FIXME ! THIS GENERATES INCONSISTENT RANDOM NUMBER!!!
				goOn = false;

				if (Globals.DEBUG == 3) {
					Globals.print("exiting loop 2, ang=" + presAngle);
				}
			}
		}

		Globals.replayPrint("std-move-2 pres-angle:{0} pres-heading: {1} tmp-angle: {2} heading:{3}", this.presAngle,
				presHeading, tmpAngle, getHeading());
		this.presAngle = this.presAngle * sign;

		double angleBeforeAvoidLand = this.presAngle; // for printing later using debug 2
		incHeading(this.presAngle);

		double angleTurnedRight = this.presAngle; // for updating prevAngle at end of stdMove()
		this.presAngle = 0;
		Globals.replayPrint(
				"std-move-3 pres-angle:{0} pres-heading: {1} tmp-angle: {2} heading:{3} angle-turned-right: {4}",
				presAngle, presHeading, tmpAngle, getHeading(), angleTurnedRight);

		this.presLogMov = 999;
		double porpMaxDist = Globals.MAX_MOV;

		j = 1;
		while (this.presLogMov > porpMaxDist) {
			double ran = Globals.RANDOM_SOURCE.nextNormal_42_48();
			Globals.replayPrint("normal-042-048:{0}", ran);
			this.presLogMov = Globals.CORR_LOGMOV * this.prevLogMov + ran;
			j++;
			if (j == 200) { // this has no effect, it will not stop the loop as prevLogMov is not changed.
				if (presAngle == 0) { // presAngle will always be 0 here.
					presAngle += 0.00001;
				}

				this.presAngle = this.presAngle * 90 / Math.abs(presAngle);

				if (Globals.DEBUG == 3) {
					Globals.print("exiting loop 3, ang=" + presAngle);
				}

				// Introduced to check whether we reach this point. Nothing here changes the while condition 
				// meaningless to do this after 200 iterations.
				throw new RuntimeException("loop 3 iterated 200 times, not expected.");
			}
		}
		double presMov = Math.pow(10, this.presLogMov);

		// Turn to avoid swimming on land if necessary:
		this.enoughWaterAhead = false;

		int countI = 0;

		while (!this.enoughWaterAhead) {
			Globals.replayPrint(
					"std-move-4 pres-angle:{0} pres-heading: {1} tmp-angle: {2} heading:{3} enoughW: {4} angle-turned-right: {5}",
					presAngle, presHeading, tmpAngle, getHeading(), enoughWaterAhead, angleTurnedRight);
			checkDepth();
			Globals.replayPrint("std-move-5 enough-water-ahead {0}", enoughWaterAhead);

			if (!this.enoughWaterAhead) {
				avoidLand();
			}
			presMov = Math.pow(10, this.presLogMov); // because presLogMov may have changed in avoidLand()

			incHeading(presAngle); // angle to turn -- presAngle -- is changed in avoidLand()

			angleTurnedRight += presAngle;

			if (angleTurnedRight > 180) {
				angleTurnedRight -= 360;
			}
			if (angleTurnedRight < -180) {
				angleTurnedRight += 360;
			}

			presAngle = 0;
			countI++;

			if (countI == 100) {
				this.enoughWaterAhead = true;

				if (Globals.DEBUG == 1) {
					Globals.print("caught water-ahead loop");
				}
			}
		}

		// test depth again, avoid-beh = 5:
		checkDepth();

		if (!this.enoughWaterAhead) {
			GridPoint max = null;
			for (GridPoint g : getNeighbors()) {
				if (max == null) {
					max = g;
				} else if (this.cellData.getDepth(max) < this.cellData.getDepth(g)) {
					max = g;
				}
			}

			facePoint(new NdPoint(max.getX(), max.getY()));

			angleTurnedRight += presAngle;
			if (angleTurnedRight > 180) {
				angleTurnedRight -= 360;
			}
			if (angleTurnedRight < -180) {
				angleTurnedRight += 360;
			}

			presMov = 1;

			if (Globals.DEBUG == 1) {
				Globals.write("beh =  5 ; tck " + Globals.getTick());
			}
		}

		// slow down if turning sharply:
		if (presMov > 10 && Math.abs(angleTurnedRight) > 90) {
			presMov /= 5.0;
		}
		if (presMov > 7 && Math.abs(angleTurnedRight) > 50) {
			presMov /= 2.0;
		}

		// Change direction if attracted / deterred by certain areas (model >= 2)
		double totalDX = 0;
		double totalDY = 0;
		NdPoint pos = getPosition();

		if (!Globals.USE_EXP_FOOD_VAL) {
			totalDX = getDx() * presMov + this.VT[0]; // VT isn't used in stdMove() till here
			totalDY = getDy() * presMov + this.VT[1]; // note that dx is change in x if taking ONE step forward

			facePoint(new NdPoint(pos.getX() + totalDX, pos.getY() + totalDY)); // really not needed, it already points that way
		} else if (Globals.MODEL < 3) {
			// length of vector pointing in direction predicted by CRW (VE-total and pres-mov are porp variables)
			// Used to use Globals.CRW_CONTRIB instead of this.crwContrib
			double crwContrib = Globals.INERTIA_CONST + presMov * this.VETotal;
			totalDX = getDx() * crwContrib + this.VT[0];
			totalDY = getDy() * crwContrib + this.VT[1];

			facePoint(new NdPoint(pos.getX() + totalDX, pos.getY() + totalDY));
		} else if (Globals.MODEL >= 3) {
			// Used to use Globals.CRW_CONTRIB instead of this.crwContrib 
			double crwContrib = Globals.INERTIA_CONST + presMov * this.VETotal;
			Globals.replayPrint(
					"std-move-4 pres-angle:{0} presheading: {1} tmp-angle: {2} heading:{3} crwcontrib: {4} VT: [{5} {6}]",
					presAngle, presHeading, tmpAngle, getHeading(), crwContrib, this.VT[0], this.VT[1]);

			// deterrence behaviour -- get scared away from ships and wind turbines
			checkDeterrence();

			if (this.ignoreDeterrence <= 0) {
				totalDX = getDx() * crwContrib + this.VT[0] + this.deterVt[0] * Globals.DETERRENCE_COEFF;
				totalDY = getDy() * crwContrib + this.VT[1] + this.deterVt[1] * Globals.DETERRENCE_COEFF;
			} else {
				// We are ignoring deterrence, don't apply
				totalDX = getDx() * crwContrib + this.VT[0];
				totalDY = getDy() * crwContrib + this.VT[1];

				this.ignoreDeterrence--;
			}
			Globals.replayPrint("facexy:{0}:{1}", (pos.getX() + totalDX), (pos.getY() + totalDY));
			facePoint(new NdPoint(pos.getX() + totalDX, pos.getY() + totalDY));
			Globals.replayPrint("heading after facexy:{0}", getHeading());
		}

		// Store turn for calc of turning angle in next step:

		// total change in heading, including all adjustments till here. 'presHeading' was calc in beginning of stdMove()
		double totalTurn = substractHeadings(getHeading(), presHeading);

		// Move: 
		// In the population model all movement lengths are still calculated in 100 m steps, but the cell size has increased from 100 m to 400 m
		// The step should therefore be divided by 4.
		double moveDistance = tickMoveAdjustMultiplier * (presMov / 4.0); // movement length isn't affected by presence of food
		tickMoveAdjustMultiplier = 0.0; // using up all the distance allowed left
		Globals.replayPrint("std-move-4 total-turn:{0} pres-mov:{1}", totalTurn, prevMov);
		Globals.replayPrint("std-move-4 posA:{0} heading:{1}", pos, getHeading());
		Globals.replayPrint("std-move-4 forward{0}:", moveDistance);
		forward(moveDistance);
		// REMOVED - PSM distance tracking changed to only track distance in dispersal, excluding standard move
		// psm.addDistanceTraveled(moveDistance);
		Globals.replayPrint("std-move-4 posB:{0} heading:{1}", getPosition(), getHeading());

		if (Globals.DEBUG == 2) {
			if (Globals.getTick() == 0) {
				// I assume we need to get the pos after the move here
				pos = getPosition();
				Globals.print("dist angle-before-avoid-land angle-turned-right x y");

				StringBuilder sb = new StringBuilder();
				sb.append(Math.round(Math.pow(10, prevLogMov) * 100) / 100); // THIS IS IMPORTANT -- the porp turns before it moves, so turning angle is affected by previous moving dist
				sb.append(" ");
				sb.append(angleBeforeAvoidLand);
				sb.append(" ");
				sb.append(angleTurnedRight);
				sb.append(" ");
				sb.append(pos.getX() * 100 + Globals.XLLCORNER);
				sb.append(" ");
				sb.append(pos.getY() * 100 + Globals.YLLCORNER);
				Globals.print(sb.toString());
			}
		} else if (Globals.DEBUG == 5) {
			pos = getPosition();
			Globals.print("CRW-contrib: [" + pos.getX() * (Globals.INERTIA_CONST + presMov * this.VETotal) + ","
					+ pos.getY() * (Globals.INERTIA_CONST + presMov * this.VETotal) + "]"); // Not sure how the list function in NETLOGO works..
			Globals.print("MR-Contrib: [" + this.VT[0] + "," + this.VT[1] + "]");
			Globals.print("dx, dy (after): [" + totalDX + "," + totalDY + "] ");
			Globals.print("heading (after): " + getHeading());
			Globals.print("total-turn: " + getHeading()); // ??!
		}

		// Remember current moves for the next iteration
		// if attraction to food alters the movement angle (i.e. VT != 0), this isn't remembered for next step
		this.prevAngle = totalTurn; // so the additional turn due to attraction to food DOES influence turning angle in next step
		this.prevLogMov = Math.log10(presMov); // total steplength, resulting from VT + presMov

		// test depth one last time, avoid-beh = 6 - move back on same track:
		if (!(getDepth() > 0)) {
			if (posList.size() > 1) {
				facePoint(this.posList.get(1));
			}

			angleTurnedRight += presAngle; // Is this right?

			if (angleTurnedRight > 180) {
				angleTurnedRight -= 360;
			} else if (angleTurnedRight < -180) {
				angleTurnedRight += 360;
			}

			// move 100 m towards deeper patch
			if (posList.size() > 1) {
				setTurtlePosition(this.posList.get(1));
			}

			if (Globals.DEBUG == 1) {
				StringBuilder sb = new StringBuilder();
				sb.append("beh =  6; tck ");
				sb.append(Globals.getTick());
				sb.append(" ; ");
				sb.append(angleTurnedRight);
				sb.append(" degr.");
				Globals.print(sb.toString());
			}
		}

		if (writePsmSteps) {
			Globals.writePSMVerificationPSM("STDMOVE", this, moveDistance);
		}
	}

	private void trackCellVisit() {
		if (trackVisitedCells && isAlive()) {
			TrackingDisplayAgent tda = (TrackingDisplayAgent) context.getObjects(TrackingDisplayAgent.class).get(0);
			GridPoint gp = grid.getLocation(this);
			int visitType;
			if (this.dispersalBehaviour.isDispersing()) {
				visitType = 2;
			} else {
				visitType = 1;
			}
			tda.visited(gp.getX(), gp.getY(), visitType);
		}
	}

	/**
	 * Calculate the expected value (VE-total) of the food to be found in the future based on food found in recent
	 * positions x the working memory Uses the values of the patches in "storedUtilList", calculated in
	 * RefMemTurnCalculator.
	 */
	private void getExpFoodVal() {
		int ii = 1;

		this.VETotal = 0;

		int maxI = Math.min(Globals.WORK_MEM_STRENGTH_LIST_FIXED.length, this.storedUtilList.size());
		while (ii < maxI) {
			this.VETotal += Globals.WORK_MEM_STRENGTH_LIST_FIXED[ii - 1] * this.storedUtilList.get(ii - 1);
			ii++;
		}

		if (Globals.DEBUG == 5) {
			Globals.print("");
			Globals.print("stored-util-list: " + this.storedUtilList);
			Globals.print("work-mem-strength-list: " + Globals.WORK_MEM_STRENGTH_LIST_FIXED);
			Globals.print("VE-total for porp " + id + ":" + this.VETotal);

		}
	}

	/**
	 * 1. Reduce food in the patch that the porp just has left. The amount eaten decreases linearly as the porp's energy
	 * level increases from 10 to 20 (=max e) this does not affect the porpoise's perception of the quality of the area,
	 * and therefore the movement is unaffected.
	 * 
	 * 2. Adjust porpoise energy level based on amount of food found and time spent per half hour Increase food level in
	 * cells with food-level > 0 AFTERWARDS in order to calc. stored-util-list correctly.
	 */
	private void updEnergeticStatus() {
		double foodEaten = 0;
		double fractOfFoodToEat = 0;

		if (this.energyLevel < 20) {
			fractOfFoodToEat = (20.0 - energyLevel) / 10.0;
		}
		if (fractOfFoodToEat > 0.99) {
			fractOfFoodToEat = 0.99;
		}

		foodEaten += this.cellData.eatFood(ndPointToGridPoint(this.posList.get(1)), fractOfFoodToEat);

		this.foodEatenDailyTemp += foodEaten;
		Globals.replayPrint("energy before eat food {0} eaten {1}", energyLevel, foodEaten);
		psm.updateMemory(getPosition(), foodEaten);
		this.energyLevel += foodEaten;

		// Scale e-use depending on season and lactation
		double scalingFactor = 1;

		// Animals have approximately 30% lower energy consumption when the water is cold, Nov-Mar, and approx. 
		// 15% lower energy consumption in Oct+Apr (Lockyer et al 2003. Monitoring growth and energy utilization 
		// of the harbour porpoise (Phocoena phocoena) in human care. Harbour porpoises in the North Atlantic 5:143-175.)
		if (Globals.getMonthOfYear(Globals.OFFSET_MONTH) == 4 || Globals.getMonthOfYear(Globals.OFFSET_MONTH) == 10) {
			scalingFactor = 1.15;
		} else if (Globals.getMonthOfYear(Globals.OFFSET_MONTH) > 4
				&& Globals.getMonthOfYear(Globals.OFFSET_MONTH) < 10) {
			scalingFactor = Globals.E_WARM;
		}

		// Food consumption increases approx 40% when lactating, there is apparently no effect of pregnancy. (Magnus Wahlberg <magnus@fjord-baelt.dk>, unpubl. data)
		if (this.withLactCalf) {
			scalingFactor *= Globals.E_LACT;
		}

		// Probability of dying increases with decreasing energy level
		double yearlySurvProb = 1 - (Globals.M_MORT_PROB_CONST * Math.exp(-this.energyLevel
				* Globals.X_SURVIVAL_PROB_CONST));
		double stepSurvProb = 0;

		if (this.energyLevel > 0) {
			stepSurvProb = Math.exp(Math.log(yearlySurvProb) / (360 * 48));
		}

		double ran = Globals.RANDOM_SOURCE.nextEnergeticUpdate(0, 1);
		Globals.replayPrint("porp-upd-energetic-status:{0}", ran);
		if (ran > stepSurvProb) {
			if (!this.withLactCalf || this.energyLevel <= 0) {
				Globals.LIST_OF_DEAD_AGE.addLast((int) this.age);
				Globals.LIST_OF_DEAD_DAY.addLast(Globals.getDayOfSimulation());
				die(CauseOfDeath.Starvation);
			}
			// Better abandoning calf than dying
			if (this.withLactCalf) {
				this.withLactCalf = false;
			}
		}

		double consumed = (0.001 * scalingFactor * Globals.E_USE_PER_30_MIN + (Math.pow(10, this.prevLogMov) * 0.001
				* scalingFactor * Globals.E_USE_PER_KM / 0.4));
		Globals.replayPrint(
				"energy before consume food {0} consumed  {1} prev-logmov {2} scaling-factor {3} month {4} with-lact-calf {5}",
				energyLevel, consumed, prevLogMov, scalingFactor, Globals.getMonthOfYear(Globals.OFFSET_MONTH),
				withLactCalf);
		consumeEnergy(consumed);

		this.energyLevelSum += this.energyLevel;
	}

	public String toString() {
		DecimalFormat df = new DecimalFormat("#.00");
		return "[" + df.format(getHeading()) + ":" + df.format(this.energyLevel) + "]";
	}

	private void checkDepth() {
		// Check that there is enough water at all steplengths ahead, set enough-water-ahead to false if < min-depth
		this.enoughWaterAhead = true;

		double presMov = Math.pow(10, this.presLogMov);
		double dd = Math.ceil(presMov / 0.1);

		GridPoint pointAhead = Agent.ndPointToGridPoint(getPointAhead(presMov));

		if (this.cellData.getDepth(pointAhead) < 0 || this.cellData.isPointMasked(pointAhead)) {
			// Globals.replayPrint("porp-check-depth enough-water-ahead false . depth-list " depth-list " depth-path " depth-path);
			Globals.replayPrint("porp-check-depth enough-water-ahead false . depth-list [NA NA] depth-path [NA]");
			this.enoughWaterAhead = false;
			return;
		}

		double[] vector = getVector(0.1);

		GridPoint[] points = new GridPoint[(int) dd + 1];

		//Globals.replayPrint("porp-check-depth depth-list " depth-list " patch ahead " patch-ahead pres-mov " bath " [ bathymetry ] of patch-ahead pres-mov);
		Globals.replayPrint("porp-check-depth depth-list [NA NA] patch ahead (patch NA NA) bath NA");

		for (int i = 0; i < dd; i++) {
			GridPoint p = Agent.ndPointToGridPoint(getPointFromVector(vector, i + 1));

			points[i] = p;

			if (!isPointGood(p, 0, false)) {
				// Globals.replayPrint("porp-check-depth enough-water-ahead false . depth-list " depth-list " depth-path " depth-path);
				Globals.replayPrint("porp-check-depth enough-water-ahead false . depth-list [NA NA] depth-path [NA]");
				this.enoughWaterAhead = false;
				break;
			}
		}
	}

	public NdPoint getPointAhead(double dist) {
		return getPointAhead(dist, 0);
	}

	public NdPoint getPointAhead(double dist, double angleOffset) {
		return getPointAtHeadingAndDist(angleOffset + getHeading(), dist);
	}

	public NdPoint getPointAtHeadingAndDist(double heading, double distance) {
		heading = normHeading(heading);

		double[] anglesInRadians = { (Math.PI / 2) - getHeadingInRads(heading), 0.0 };
		double[] displacement = SpatialMath.getDisplacement(2, 0, distance, anglesInRadians);

		double[] movedCoords = new double[2];
		getPosition().toDoubleArray(movedCoords);
		PointTranslator trans = space.getPointTranslator();
		trans.translate(movedCoords, displacement);

		return new NdPoint(movedCoords);
	}

	public NdPoint getPointAtHeadingAndDistNoBorder(double heading, double distance) {
		heading = normHeading(heading);

		double[] anglesInRadians = { (Math.PI / 2) - getHeadingInRads(heading), 0.0 };
		double[] displacement = SpatialMath.getDisplacement(2, 0, distance, anglesInRadians);

		double[] movedCoords = new double[2];
		getPosition().toDoubleArray(movedCoords);
		movedCoords[0] += displacement[0];
		movedCoords[1] += displacement[1];

		return new NdPoint(movedCoords);
	}

	private double[] getVector(double distance) {
		double[] anglesInRadians = { (Math.PI / 2) - getHeadingInRads(), 0.0 };
		return SpatialMath.getDisplacement(2, 0, distance, anglesInRadians);
	}

	private NdPoint getPointFromVector(double[] vector, int scale) {
		double[] movedCoords = new double[2];
		getPosition().toDoubleArray(movedCoords);
		PointTranslator trans = space.getPointTranslator();
		trans.translate(movedCoords, vector[0] * scale, vector[1] * scale);

		return new NdPoint(movedCoords);
	}

	private void avoidLandTurn(GridPoint r, GridPoint l, double randAng, int degrees) {
		if (isPointGood(r) && isPointGood(l)) {
			double bathR = cellData.getDepth(r);
			double bathL = cellData.getDepth(l);

			// comparison can be true only if neither bath-r or bath-l are NaN, i.e. if both are > min-depth
			// both points are good, pick the deepest
			if (bathR >= bathL) {
				this.presAngle += degrees + randAng;
			} else {
				this.presAngle -= degrees + randAng;
			}
		} else {
			if (isPointGood(r)) {
				this.presAngle += degrees + randAng;
			} else {
				this.presAngle -= degrees + randAng;
			}
		}
	}

	private boolean isPointGood(GridPoint p, double minDepth, boolean allowEqual) {
		if (allowEqual) {
			return cellData.getDepth(p) >= minDepth && !cellData.isPointMasked(p);
		} else {
			return cellData.getDepth(p) > minDepth && !cellData.isPointMasked(p);
		}

	}

	private boolean isPointGood(GridPoint p) {
		return isPointGood(p, Globals.MIN_DEPTH, true);
	}

	private void avoidLand() {
		/* If shallow water ahead, turn right or left depending on where water is deeper. Turn as little as possible.
		 * Don't do the turning here, but change angle to be turned in stdMove().
		 * Note that the emergency procedure "avoid-beh 5" is found in stdMove().
		 */
		double randAng = Globals.RANDOM_SOURCE.nextAvoidLand(0, 10);
		Globals.replayPrint("porp-avoid-land:{0}",randAng);
		NdPoint pos = getPosition();
		Globals.replayPrint("porp-avoid-land#0 pres angle :{0} x:{1} y:{2}", presAngle, pos.getX(), pos.getY());
		int avoidBeh = 0;
		double presMov = Math.pow(10, this.presLogMov); // ?!

		GridPoint leftPoint = ndPointToGridPoint(getPointLeftAndAhead(40 + randAng, presMov));
		GridPoint rightPoint = ndPointToGridPoint(getPointRightAndAhead(40 + randAng, presMov));

		// alternative kinds of evasive behaviour:
		if (isPointGood(rightPoint) || isPointGood(leftPoint)) {
			avoidBeh = 1; // evasive behaviour type 1

			avoidLandTurn(rightPoint, leftPoint, randAng, 40);
		} else if (isPointGood(rightPoint = ndPointToGridPoint(getPointRightAndAhead(70 + randAng, presMov))) | // Should not be replaced with || as we do an update of leftPoint
				isPointGood(leftPoint = ndPointToGridPoint(getPointLeftAndAhead(70 + randAng, presMov)))) {
			// try turning more aprubtly ( = 70 deg )
			avoidBeh = 2; // evasive behaviour type 2

			if (isPointGood(rightPoint) || isPointGood(leftPoint)) {
				avoidLandTurn(rightPoint, leftPoint, randAng, 70);
			}
		} else if (isPointGood(rightPoint = ndPointToGridPoint(getPointRightAndAhead(120 + randAng, presMov)))
				| isPointGood(leftPoint = ndPointToGridPoint(getPointLeftAndAhead(120 + randAng, presMov)))) {
			avoidBeh = 3;

			if (isPointGood(rightPoint) || isPointGood(leftPoint)) {
				avoidLandTurn(rightPoint, leftPoint, randAng, 120);
			}
		} else {
			// if everything else fails, turn around
			avoidBeh = 4;

			int j = 0;
			checkDepth();
			while (!this.enoughWaterAhead && j < this.posList.size()) {
				NdPoint prevPoint = this.posList.get(j);
				this.facePoint(prevPoint);
				this.setPosition(prevPoint);
				j++;
				checkDepth();

				if (j == 20) {
					this.enoughWaterAhead = true;
				}
			}
		}

		if (Globals.DEBUG == 1) {
			Globals.print("beh = " + avoidBeh + "; tck = " + Globals.getTick() + "; " + Math.round(this.presAngle)
					+ " degr.");
		}
	}

	/**
	 * Computes the difference between the given headings, that is, the number of degrees in the smallest angle by which
	 * heading2 could be rotated to produce heading1. A positive answer means a clockwise rotation, a negative answer
	 * counterclockwise. The result is always in the range -180 to 180, but is never exactly -180. Note that simply
	 * subtracting the two headings using the - (minus) operator wouldn't work. Just subtracting corresponds to always
	 * rotating clockwise from heading2 to heading1; but sometimes the counterclockwise rotation is shorter. For
	 * example, the difference between 5 degrees and 355 degrees is 10 degrees, not -350 degrees.
	 * 
	 * @param heading1 The first heading.
	 * @param heading2 The second heading.
	 * @return The difference in the headings.
	 */
	private double substractHeadings(double heading1, double heading2) {
		double diff = heading1 - heading2;

		if (diff <= -180) {
			// It is shorter to turn right
			return diff + 360;
		} else if (diff > 180) {
			return diff - 360;
		} else {
			return diff;
		}
	}

	private NdPoint getPointLeftAndAhead(double angle, double distance) {
		return getPointAhead(distance, -angle);
	}

	private NdPoint getPointRightAndAhead(double angle, double distance) {
		return getPointAhead(distance, angle);
	}

	private double getDepth() {
		return this.cellData.getDepth(Agent.ndPointToGridPoint(this.getPosition()));
	}

	private void setTurtlePosition(NdPoint pos) {
		this.setPosition(pos);
	}

	// Reports the x-increment or y-increment (the amount by which the turtle's xcor or ycor would change) if the 
	// turtle were to take one step forward in its current heading.
	private double getDx() {
		return Math.sin(getHeadingInRads());
	}

	// Reports the x-increment or y-increment (the amount by which the turtle's xcor or ycor would change) if the 
	// turtle were to take one step forward in its current heading.
	private double getDy() {
		return Math.cos(getHeadingInRads());
	}

	private void die(CauseOfDeath cause) {
		//System.out.println("Porpoise " + id + " died of : " + cause);
		this.alive = false;
		context.remove(this);
		Globals.MONTHLY_STATS.addDeath(cause);
		YearlyTask.recordDeath((int) Math.floor(this.getAge()));
	}

	public boolean isAlive() {
		return alive;
	}

	// TODO: this should be an initialise function for the entire porpoise object
	public void moveAwayFromLand() {
		Dimensions dim = space.getDimensions();

		// Only the space is initialized at this time..
		while (this.cellData.getDepth(ndPointToGridPoint(getPosition())) <= 0
				|| this.cellData.isPointMasked(ndPointToGridPoint(getPosition()))) {
			space.moveTo(this, RandomHelper.nextDoubleFromTo(0, dim.getWidth() - dim.getOrigin(0)),
					RandomHelper.nextDoubleFromTo(0, dim.getHeight() - dim.getOrigin(1)));
		}

		// Initialize the posList
		this.posList.add(getPosition());
	}

	/**
	 * The tasks to perform daily. This is called from the DailyTask class.
	 * Consider making this a @ScheduledMethod and removing the DailyTask class.
	 */
	public void performDailyStep() {
		Globals.replayPrint("perform-daily-step");

		this.foodEatenDaily = this.foodEatenDailyTemp;
		this.foodEatenDailyTemp = 0;

		this.energyConsumedDaily = this.energyConsumedDailyTemp;
		this.energyConsumedDailyTemp = 0;

		this.age += 1.0 / 360; // TODO: We can avoid this if we record the born tick.

		double eMean = this.energyLevelSum / 48.0;
		this.energyLevelDaily.add(Math.round(eMean * 1000.0) / 1000.0); // TODO: Do we need precision 3?

		this.posListDaily.add(getPosition());

		if (Globals.MODEL >= 3 && Globals.DISPERSAL_TYPE != DispersalType.Off) {
			if (!this.dispersalBehaviour.isDispersing())
			{
				Globals.replayPrint("daily-step energy-level-daily:{0}", this.energyLevelDaily);
				boolean decreasingEnergy = true;
				for (int i = 0; i < Globals.T_DISP; i++) {
					if (this.energyLevelDaily.get(i) >= this.energyLevelDaily.get(i+1)) {
						decreasingEnergy = false;
						break;
					}
				}
				if (decreasingEnergy) {
					// decreasing energy for three days

					if (Globals.DISPERSAL_TYPE == DispersalType.PSM_Type1
							|| Globals.DISPERSAL_TYPE == DispersalType.PSM_Type2) {
						if (!this.psm.isActive()) { // Only go into dispersal if the PSM is not currently active (i.e. seeking back to a known good location
							this.psm.setActive(true);
							if (this.psm.isActive()) {
								this.dispersalBehaviour.activate();  // TODO, should be moved somewhere else, since not related to PSM
							}
						}
					}
				}
			}

			// Energy level higher than any of the previous seven days, stop dispersing;
			if (this.dispersalBehaviour.isDispersing()) {
				double min = this.energyLevelDaily.get(1);
				for (int i = 2; i < 8; i++) {
					min = Math.min(min, this.energyLevelDaily.get(i));
				}

				if (this.energyLevelDaily.get(0) > min) {
					this.dispersalBehaviour.deactivate();

					if (Globals.DEBUG == 7 && (id == 0 || id == 1)) {
						Globals.print("Food found, stop disp., (porp " + id + ")");
					}
				}
			}
		} // End model >= 3 tasks.

		this.energyLevelSum = 0; // reset daily

		if (Globals.MODEL >= 4 && Globals.MORTALITY_ENABLED) {
			if (updMortality()) {
				updPregnancyStatus();
			}
		}
	}

	/**
	 * Updates the mortality state of the porpoise. If the porpoise is still alive true is returned. Otherwise false is
	 * returned.
	 * 
	 * @return Whether not the porpoise is still alive.
	 */
	private boolean updMortality() {
		double dailySurvivalProb = Math.exp(Math.log(1 - Globals.BYCATCH_PROB) / 360); // Ok that only divided by 360, called once per day

		double ran = Globals.RANDOM_SOURCE.nextMortality(0, 1);
		Globals.replayPrint("porp-upd-mortality:{0}", ran);
		if (ran > dailySurvivalProb || this.age > Globals.MAX_AGE) { // Introducing maximum age and Mortality due to by-catch
			Globals.LIST_OF_DEAD_AGE.addLast((int) this.age);
			Globals.LIST_OF_DEAD_DAY.addLast(Globals.getDayOfSimulation());
			die(this.age > Globals.MAX_AGE ? CauseOfDeath.OldAge : CauseOfDeath.ByCatch);
			return false;
		} else {
			return true;
		}

	}

	private void updPregnancyStatus() {
		// 0 (unable to mate, young/low energy); 1 (unable to mate, pregnant); 2 (ready to mate)
		// Become ready to mate:
		if (this.pregnancyStatus == 0 && this.age >= this.ageOfMaturity) {
			this.pregnancyStatus = 2;
		}

		// Mate:
		if (this.pregnancyStatus == 2 && Globals.getDayOfYear() == this.matingDay) {
			if (Globals.RANDOM_SOURCE.nextPregnancyStatusConceive(0, 1) < Globals.CONCEIVE_PROB) { // become pregnanat with prob. taken from Read & Hohn 1995
				this.pregnancyStatus = 1;
				if (Globals.DEBUG == 9) {
					Globals.print(this.id + " pregnant");
				}
				this.daysSinceMating = 0;
			}
		}

		// Give birth:
		if (this.pregnancyStatus == 1 && this.daysSinceMating == Globals.GESTATION_TIME) { // give birth. Gestation time = approx 10 mo (Lockyer 2003)
			this.pregnancyStatus = 2; // so it is ready to mate even though it has a very young calf
			this.withLactCalf = true;

			this.daysSinceMating = -99;
			this.daysSinceGivingBirth = 0;

			if (Globals.DEBUG == 9) {
				Globals.print(this.id + " with lact calf");
			}
		}

		if (this.withLactCalf && this.daysSinceGivingBirth == Globals.NURSING_TIME) { // nursing for 8 months
			this.withLactCalf = false;
			this.daysSinceGivingBirth = -99;

			int nOffspr = 0;

			if (Globals.RANDOM_SOURCE.nextPregnancyStatusBoyGirl(0, 1) > 0.5) { // assuming 50 % males and no abortions
				nOffspr = 1;
			}

			if (Globals.DEBUG == 9) {
				Globals.print(id + " hatching " + nOffspr);
			}

			if (nOffspr > 0) {
				Porpoise calf = new Porpoise(this);
				this.context.add(calf);
				calf.setPosition(this.getPosition());
				calf.moveAwayFromLand(); // Initializes the pos list. TODO: not nice to do here, should be done elsewhere
				Globals.MONTHLY_STATS.addBirth();
			}
		}

		if (this.pregnancyStatus == 1) {
			this.daysSinceMating++;
		}

		if (this.withLactCalf) {
			this.daysSinceGivingBirth++;
		}
	}

	public int getMatingDay() {
		return this.matingDay;
	}

	public void setRandomMatingDay() {
		double ran = Globals.RANDOM_SOURCE.nextMatingDayNormal();
		Globals.replayPrint("mating-day:{0}", ran);
		this.matingDay = (int) Math.round(ran);
	}

	public synchronized void deter(double currentDeterenceStrength, SoundSource s) {
		NdPoint shipPosition = s.getPosition();
		NdPoint porpPosition = getPosition();

		// become deterred if not already more scared of other sound source
		if (this.deterStrength < currentDeterenceStrength) {
			this.deterStrength = currentDeterenceStrength;
			// vector pointing away from turbine
			this.deterVt[0] = currentDeterenceStrength * ((porpPosition.getX() - shipPosition.getX()));
			this.deterVt[1] = currentDeterenceStrength * ((porpPosition.getY() - shipPosition.getY()));

			this.deterTimeLeft = Globals.DETER_TIME; // how long to remain affected
		}

		// Porpoises nearby stop dispersing (which could force them to cross over disturbing agents very fast)
		dispersalBehaviour.deactivate();
	}

	public synchronized void deter(double currentDeterenceStrength, Turbine t) {
		// Deterrence by wind farms
		NdPoint turbPosition = t.getPosition();
		NdPoint porpPosition = getPosition();

		// become deterred if not already more scared of other wind turbine
		if (this.deterStrength < currentDeterenceStrength) {
			this.deterStrength = currentDeterenceStrength;
			// vector pointing away from turbine
			this.deterVt[0] = currentDeterenceStrength * ((porpPosition.getX() - turbPosition.getX()));
			this.deterVt[1] = currentDeterenceStrength * ((porpPosition.getY() - turbPosition.getY()));

			this.deterTimeLeft = Globals.DETER_TIME; // how long to remain affected
		}

		// Porpoises nearby stop dispersing (which could force them to cross over disturbing agents very fast)
		dispersalBehaviour.deactivate();
	}

	public void updateDeterence() {
		if (this.deterTimeLeft <= 0) {
			this.deterStrength = 0;
			this.deterVt[0] = 0;
			this.deterVt[1] = 0;
		} else {
			this.deterTimeLeft--;
			this.deterStrength *= (100 - Globals.DETER_DECAY) * 0.01;
			this.deterVt[0] /= 2.0;
			this.deterVt[1] /= 2.0;
		}
	}

	public void consumeEnergy(double energyAmount) {
		this.energyLevel -= energyAmount;
		this.energyConsumedDailyTemp += energyAmount;
	}

	public double getEnergyLevel() {
		return this.energyLevel;
	}

	public double getSoundSourceDistance() {
		return soundSourceDistance;
	}

	public void setSoundSourceDistance(double soundSourceDistance) {
		this.soundSourceDistance = soundSourceDistance;
	}

	public double getSoundSourceAngle() {
		return soundSourceAngle;
	}

	public void setSoundSourceAngle(double soundSourceAngle) {
		this.soundSourceAngle = soundSourceAngle;
	}

	public void setSoundSourceImpact(double impact) {
		this.soundSourceImpact = impact;
	}

	public double getSoundSourceImpact() {
		return soundSourceImpact;
	}

	public double getDeterStrength() {
		return this.deterStrength;
	}

	public int getDeterTimeLeft() {
		return this.deterTimeLeft;
	}

	public String getDeterVector() {
		return "[" + this.deterVt[0] + "," + this.deterVt[1] + "]";
	}

	public String getVT() {
		return "[" + this.VT[0] + "," + this.VT[1] + "]";
	}

	public int getBlock() {
		return this.cellData.getBlock(getPosition());
	}

	public PersistentSpatialMemory getPersistentSpatialMemory() {
		return psm;
	}

	public int getUtmX() {
		return (int) Math.round(getPosition().getX() * 400 + Globals.XLLCORNER);
	}

	public int getUtmY() {
		return (int) Math.round(getPosition().getY() * 400 + Globals.YLLCORNER);
	}

	private void setPrevAngle(double prevAngle) {
		this.prevAngle = prevAngle;
	}

	/**
	 * Checks whether the porpoise is stuck and should go into deterrence ignore mode.
	 */
	private void checkDeterrence() {
		// Only check whether we should ignore deterrence if we are not already ignoring it.
		// If the porpoise has moved less than IGNORE_DETER_STUCK_TIME, e.g. right after start, then we ignore it for now.
		if (ignoreDeterrence == 0 && this.posList.size() > Globals.IGNORE_DETER_STUCK_TIME
				&& this.deterStrength > Globals.IGNORE_DETER_MIN_IMPACT) {
			double totalDistance = 0; // 

			if (this.posList.size() >= 2) {
				for (int i = 1; i < posList.size() && i < Globals.IGNORE_DETER_STUCK_TIME; i++) { // Max 15 last pos to check
					NdPoint p1 = posList.get(i);
					NdPoint p0 = posList.get(i - 1);
					totalDistance += space.getDistance(p0, p1);
				}
			}

			if (totalDistance <= Globals.IGNORE_DETER_MIN_DISTANCE) {
				ignoreDeterrence = Globals.IGNORE_DETER_NUMBER_OF_STEPS_IGNORE;
			}
		}
	}

	public int getIgnoreDeterrence() {
		// Used for the UI so the ignore deterrence state can be observed. 
		return this.ignoreDeterrence;
	}

	/**
	 * Gets the age of the porpoise. The unit is years.
	 * 
	 * @return The age of the porpoise in years.
	 */
	public double getAge() {
		return age;
	}

	/**
	 * Gets the position if the agent moved distance forward without taking border wrap or bounce into account. This
	 * position can therefore be of the edge of the map.
	 * 
	 * @param distance The distance to move forward.
	 */
	protected NdPoint getPositionForward(double distance) {
		// TODO: Copy paste from forward, find a way to have only one implementation.
		Dimensions d = space.getDimensions();
		double[] anglesInRadians = { (Math.PI / 2) - getHeadingInRads(), 0.0 };
		double[] displacement = SpatialMath.getDisplacement(d.size(), 0, distance, anglesInRadians);

		double[] newPos = new double[2];
		NdPoint pos = getPosition();
		pos.toDoubleArray(newPos);

		newPos[0] += displacement[0];
		newPos[1] += displacement[1];

		return new NdPoint(newPos);
	}

	/**
	 * Moves the agent forward and bounces the agent on the edge. The agent will
	 * 
	 * @param distance The distance to move forward.
	 */
	public void forward(double distance) {
		if (Globals.HOMOGENOUS || Globals.MODEL < 5) {
			super.forward(distance);
			return;
		}

		Dimensions d = space.getDimensions();
		double[] anglesInRadians = { (Math.PI / 2) - getHeadingInRads(), 0.0 };
		double[] displacement = SpatialMath.getDisplacement(d.size(), 0, distance, anglesInRadians);

		double[] newPos = new double[2];
		NdPoint pos = getPosition();
		pos.toDoubleArray(newPos);

		newPos[0] += displacement[0];
		newPos[1] += displacement[1];

		boolean angleChanged = false;

		if (newPos[0] >= d.getWidth() || newPos[0] < 0) {
			// we are moving off the right most edge or the left most edge
			// new angle will be {-dx,dy}
			angleChanged = true;
			// newPos[0] = -2*displacement[0]; // This is not a bounce, this is a turn before impact.
			displacement[0] = -displacement[0];
		}

		if (newPos[1] >= d.getHeight() || newPos[1] < 0) {
			// we are moving off the top or the bottom of the map
			// new angle will be {dx,-dy}
			angleChanged = true;
			// newPos[1] = -2*displacement[1];
			displacement[1] = -displacement[1];
		}

		if (angleChanged) {
			double angle = Math.atan(displacement[1] / displacement[0]) - (Math.PI / 2);
			double newHeading = Math.toDegrees(angle);
			setHeading(newHeading);
			setPrevAngle(0);
		}

		NdPoint temp = space.moveByVector(this, distance, anglesInRadians);
		this.setPosition(temp); // update the grid as well.
	}

	public int getLactatingCalf() {
		if (this.withLactCalf) {
			return 1;
		} else {
			return 0;
		}
	}

	public double getEnergyConsumedDaily() {
		return this.energyConsumedDaily;
	}

	public double getFoodEaten() {
		return this.foodEatenDaily;
	}

	public double getPrevLogMov() {
		return this.prevLogMov;
	}

	public double getPresLogMov() {
		return this.presLogMov;
	}

	public int getInFoodPatch() {
		GridPoint p = Agent.ndPointToGridPoint(getPosition());
		if (this.cellData.getFoodProb(p) > 0 && this.cellData.getMaxEnt(p) > 0) {
			return 1;
		} else {
			return 0;
		}
	}

	/***
	 * Gets the distance moved by the porpoise in the last day.
	 * 
	 * @return The distance moved (cells) in the last 48 steps.
	 */
	public double getDailyMovement() {
		double distance = 0;
		NdPoint lastPos = getPosition();

		int steps = Math.min(48, this.posList.size());

		for (int i = 0; i < steps; i++) {
			NdPoint currPos = this.posList.get(i);
			distance += this.space.getDistance(lastPos, currPos);
			lastPos = currPos;
		}

		if (steps < 48) {
			distance = (distance / steps) * 48.0;
		}

		return distance;
	}

	/***
	 * Returns 1 if the porpoise is in dispersal 3 mode. This allows us to sum the porpoises in dispersal 2 mode easily.
	 * 
	 * @return
	 */
	public int getIsInDisp3Mode() {
		return this.dispersalBehaviour.getDispersalType() == 3 ? 1 : 0;  // this.dispType == 3 ? 1 : 0;
	}

	/**
	 * Returns the number of ticks the porpoise has been dispersing. Zero (0) will be returned if the porpoise is not
	 * dispersing.
	 * 
	 * @return The number of ticks the porpoise has been dispersing
	 */
	public int getDispNumTicks() {
		return this.dispNumTicks;
	}

	public int getDispersalMode() {
		return this.dispersalBehaviour.getDispersalType(); //this.dispType;
	}

	public void reinitializePoslist() {
		this.posList = new CircularBuffer<NdPoint>(Globals.MEMORY_MAX);
		this.posList.add(getPosition());
	}

	public void setTrackVisitedCells(boolean track) {
		// We only enable this in the UI
		if (!RunEnvironment.getInstance().isBatch()) {
			this.trackVisitedCells = track;
		}
	}

	public void setWritePsmSteps(boolean writePsmSteps) {
		this.writePsmSteps = writePsmSteps;
	}

	public void setPosList(String s) {
		return; // does nothing, only here to enable edit box on UI
	}

	public String getPosList() {
		StringBuffer sb = new StringBuffer("[");
		for (int i = 0; i < this.posList.size(); i++) {
			if (i != 0) {
				sb.append(" "); // match NetLogo formatting
			}
			NdPoint pos = this.posList.get(i);
			sb.append("[").append(pos.getX()).append(" ").append(pos.getY()).append("]");
		}
		sb.append("]");

		return sb.toString();
	}

	public boolean isEnoughWaterAhead() {
		return enoughWaterAhead;
	}

	public CellData getCellData() {
		return cellData;
	}

	public boolean isWritePsmSteps() {
		return writePsmSteps;
	}

}
