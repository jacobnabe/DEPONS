/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import repast.simphony.data2.DataException;
import repast.simphony.data2.DataSink;
import dk.au.bios.porpoise.PorpoiseInitializer;

/**
 * A custom DataSink for CSV files. This data sink is driven by parameters, which determine whether the data sink is
 * enabled and what kind of data is being logged.
 * 
 * This class is not currently being used but is being kept in case it will be needed in the future.
 * @see PorpoiseInitializer
 */
public class CSVFileDataSink implements DataSink {

	private static final String DELIM = ";";

	private AtomicBoolean enabled = new AtomicBoolean(false);

	private String fileName;
	private BufferedWriter fileOut;

	private boolean isNewRecord = true;

	public CSVFileDataSink(String fileName) {
		this.fileName = fileName;
	}

	public void setEnabled(boolean enabled) {
		this.enabled.set(enabled);
	}

	public void setEnabled(Boolean enabled) {
		if (enabled != null) {
			this.enabled.set(enabled.booleanValue());
		} else {
			this.enabled.set(false);
		}
	}

	@Override
	public void open(List<String> sourceIds) {
		//		System.out.println("Opening CSV file " + fileName + " [" + enabled + "]");
		//		if (enabled.get()) {
		try {
			File f = new File(fileName);
			//				File f = new File("output" + File.separator + fileName);
			File p = f.getCanonicalFile().getParentFile();
			if (p != null && !p.exists()) {
				p.mkdirs();
			}
			System.out.println("Writing to " + f.getAbsolutePath());
			fileOut = new BufferedWriter(new FileWriter(f));

			boolean first = true;
			for (String s : sourceIds) {
				if (!first) {
					fileOut.write(DELIM);
				}
				fileOut.write("\"" + s + "\"");
				first = false;
			}
			fileOut.newLine();
		} catch (IOException e) {
			throw new DataException("Error opening CSVFileDataSink.", e);
		}
		//		}
	}

	@Override
	public void rowStarted() {
	}

	@Override
	public void append(String key, Object value) {
		// Assuming order is the same as with open()
		if (enabled.get()) {
			try {
				if (!isNewRecord) {
					fileOut.write(DELIM);
				}
				fileOut.write(value.toString());
				isNewRecord = false;
			} catch (IOException e) {
				throw new DataException("Error appending to CSVFileDataSink.", e);
			}
		}
	}

	@Override
	public void rowEnded() {
	}

	@Override
	public void recordEnded() {
		if (enabled.get()) {
			try {
				fileOut.newLine();
			} catch (IOException e) {
				throw new DataException("Error ending record for CSVFileDataSink", e);
			}
			isNewRecord = true;
		}
	}

	@Override
	public void flush() {
		if (enabled.get()) {
			try {
				fileOut.flush();
			} catch (IOException e) {
				throw new DataException("Error flushing CSVFileDataSink", e);
			}
		}
	}

	@Override
	public void close() {
		if (enabled.get()) {
			try {
				fileOut.close();
			} catch (IOException e) {
				throw new DataException("Error closing CSVFileDataSink", e);
			}
		}
	}

}
