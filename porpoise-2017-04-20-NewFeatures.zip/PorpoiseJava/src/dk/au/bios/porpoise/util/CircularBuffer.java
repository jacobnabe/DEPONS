/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.util;

/**
 * A simple circular buffer (FIFO).
 *
 * @param <T> The type in the buffer.
 */
public class CircularBuffer<T> {

	private Object[] buffer;
	private int idx;
	private int size; // number of elements

	public CircularBuffer(int capacity) {
		buffer = new Object[capacity];
		idx = 0;
	}

	public void add(T element) {
		buffer[idx] = element;
		idx = (idx + 1) % buffer.length;

		if (size < buffer.length) {
			size++;
		}
	}

	@SuppressWarnings("unchecked")
	public T get(int i) {
		// element i is (idx-1)
		int elementIdx = (idx - 1) - i;

		if (elementIdx < 0) {
			elementIdx += buffer.length;
		}

		return (T) buffer[elementIdx];
	}

	public int size() {
		return size;
	}

	public String toString() {
		StringBuilder sb = new StringBuilder("[");
		for (int i = 0; i < size(); i++) {
			if (i != 0) {
				sb.append(" "); // match NetLogo formatting
			}

			sb.append(get(i));
		}
		sb.append("]");

		return sb.toString();
	}

}
