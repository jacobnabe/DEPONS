/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.util;

import java.util.Arrays;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;

import repast.simphony.space.grid.GridPoint;
import dk.au.bios.porpoise.Globals;

/**
 * Utility class for (landscape) blocks.
 */
public class BlockQuarterCalculator {

	public static Future<double[]> calculateBlockVal(final Future<double[][]> block, final Future<double[][]> maxEnt,
			final boolean[][] mask, final Future<double[][]> depth) {
		Callable<double[]> c = new Callable<double[]>() {
			@Override
			public double[] call() throws Exception {
				double[][] blockDouble = block.get();
				double[][] maxEntDouble = maxEnt.get();
				double[][] depthDouble = depth.get();

				int blockCount = getBlockCount(blockDouble);

				// Sum the maxEnt in for all cells
				double[] blockCellSum = new double[blockCount];
				int[] blockCellCount = new int[blockCount];

				for (int x = 0; x < blockDouble.length; x++) {
					for (int y = 0; y < blockDouble[x].length; y++) {
						// TODO: define what is a valid cell centrally.
						if (depthDouble[x][y] > 0 && mask != null && !mask[x][y] && !Double.isNaN(blockDouble[x][y])) {
							blockCellCount[(int) blockDouble[x][y] - 1]++;
							blockCellSum[(int) blockDouble[x][y] - 1] += maxEntDouble[x][y];
						}
					}
				}

				// Calculate the average
				// We allocate a new array for readability (we could reuse blockCellSum if we run low on memory) 
				double[] blockVal = new double[blockCount];
				for (int i = 0; i < blockCellCount.length; i++) {
					if (blockCellCount[i] > 0) {
						blockVal[i] = blockCellSum[i] / (double) blockCellCount[i];
					}
				}

				return blockVal;
			}
		};

		return Globals.THREAD_POOL.submit(c);
	}

	public static Future<GridPoint[]> getBlockCenters(final Future<double[][]> block) {
		Callable<GridPoint[]> c = new Callable<GridPoint[]>() {
			@Override
			public GridPoint[] call() throws Exception {
				double[][] blockDouble = block.get();
				int blockCount = getBlockCount(blockDouble);

				GridPoint[] centers = new GridPoint[blockCount];

				int[] minX = new int[blockCount];
				int[] maxX = new int[blockCount];
				int[] minY = new int[blockCount];
				int[] maxY = new int[blockCount];

				// Use -1 as not set value
				Arrays.fill(minX, -1);
				Arrays.fill(maxX, -1);
				Arrays.fill(minY, -1);
				Arrays.fill(maxY, -1);

				// Determine max and min x,y coordinates for each block
				for (int x = 0; x < blockDouble.length; x++) {
					for (int y = 0; y < blockDouble[x].length; y++) {
						if (!Double.isNaN(blockDouble[x][y])) {
							int currIdx = (int) blockDouble[x][y] - 1; // Block 1 is in position 0

							if (currIdx < 0) {
								throw new RuntimeException("Cell (" + x + "," + y
										+ ") contains an illegal block number <" + blockDouble[x][y] + ">");
							}

							if (minX[currIdx] == -1 || minX[currIdx] > x) {
								minX[currIdx] = x;
							}

							if (minY[currIdx] == -1 || minY[currIdx] > y) {
								minY[currIdx] = y;
							}

							if (maxX[currIdx] == -1 || maxX[currIdx] < x) {
								maxX[currIdx] = x;
							}

							if (maxY[currIdx] == -1 || maxY[currIdx] < y) {
								maxY[currIdx] = y;
							}
						}
					}
				}

				for (int i = 0; i < centers.length; i++) {
					if (maxX[i] != -1 && maxY[i] != -1 && minX[i] != -1 && minY[i] != -1) {
						centers[i] = new GridPoint(minX[i] + (maxX[i] - minX[i]) / 2, minY[i] + (maxY[i] - minY[i]) / 2);
					} else {
						// System.out.println("Could not determine center for block <" + i + ">");
					}
				}

				return centers;
			}
		};

		return Globals.THREAD_POOL.submit(c);
	}

	public static int getBlockCount(double[][] block) {
		// Identify all blocks
		int blockCount = 1;
		for (int x = 0; x < block.length; x++) {
			for (int y = 0; y < block[x].length; y++) {
				if (block[x][y] != Double.NaN && block[x][y] > blockCount) {
					blockCount = (int) block[x][y];
				}
			}
		}
		return blockCount;
	}

}
