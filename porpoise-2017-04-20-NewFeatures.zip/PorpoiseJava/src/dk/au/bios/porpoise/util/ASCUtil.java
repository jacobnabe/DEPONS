/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;

import dk.au.bios.porpoise.Globals;

/**
 * Utility class to load data froo ASCII (text) files.
 */
public class ASCUtil {

	public static boolean[][] loadBooleanAscFile(int width, int height, String file) throws IOException {
		File f = new File(file);
		if (f.exists()) {
			Boolean[][] data = new Boolean[width][height];
			loadData(data, file, new BooleanParser(), false);

			boolean[][] boolVal = new boolean[width][height];
			for (int x = 0; x < data.length; x++) {
				for (int y = 0; y < data[x].length; y++) {
					boolVal[x][y] = data[x][y];
				}
			}

			return boolVal;
		} else {
			return null;
		}
	}

	public static Future<double[][]> loadDoubleAscFileTask(int width, int height, String file,
			boolean replaceNoDataWithNull) {
		return Globals.THREAD_POOL.submit(new DoubleAscLoader(width, height, file, replaceNoDataWithNull));
	}

	private static class DoubleAscLoader implements Callable<double[][]> {
		int width;
		int height;
		String file;
		boolean replaceNoDataWithNull;

		public DoubleAscLoader(int width, int height, String file, boolean replaceNoDataWithNull) {
			this.width = width;
			this.height = height;
			this.file = file;
			this.replaceNoDataWithNull = replaceNoDataWithNull;
		}

		@Override
		public double[][] call() throws Exception {
			return loadDoubleAscFile(width, height, file, replaceNoDataWithNull);
		}
	}

	public static double[][] loadDoubleAscFile(int width, int height, String file, boolean replaceNoDataWithNull)
			throws IOException {
		Double[][] data = new Double[width][height];
		loadData(data, file, new DoubleParser(), replaceNoDataWithNull);

		double[][] primitive = new double[width][height];

		for (int x = 0; x < width; x++) {
			for (int y = 0; y < height; y++) {
				primitive[x][y] = data[x][y];
			}
		}

		return primitive;
	}

	private static <T> void loadData(T[][] array, String file, StringParser<T> parser, boolean replaceNoDataWithNull)
			throws IOException {
		FileReader freader = new FileReader(file);
		BufferedReader reader = new BufferedReader(freader);

		String noDataValue = null;

		for (int i = 0; i < 6; i++) {
			String line = reader.readLine();

			if (line.startsWith("NODATA_value")) {
				noDataValue = line.substring("NODATA_value".length()).trim();
			}
		}

		int y = 0;
		String line;
		while ((line = reader.readLine()) != null) {
			String[] points = line.split(" ");
			for (int x = 0; x < points.length; x++) {
				if (replaceNoDataWithNull && points[x].trim().equals(noDataValue)) {
					array[x][array[x].length - y - 1] = parser.getNullValue();
				} else {
					array[x][array[x].length - y - 1] = parser.parse(points[x]);
				}
			}
			y++;
		}

		reader.close();
		freader.close();
	}

	private interface StringParser<T> {
		T parse(String s);

		T getNullValue();
	}

	private static class BooleanParser implements StringParser<Boolean> {

		@Override
		public Boolean parse(String s) {
			return !s.trim().equals("1");
		}

		@Override
		public Boolean getNullValue() {
			return false;
		}

	}

	private static class DoubleParser implements StringParser<Double> {

		@Override
		public Double parse(String s) {
			return Double.parseDouble(s);
		}

		@Override
		public Double getNullValue() {
			return Double.NaN;
		}

	}

}
