/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.util.test

import repast.simphony.parameter.Parameters;
import repast.simphony.parameter.ParametersWriter;
import dk.au.bios.porpoise.Globals;
import dk.au.bios.porpoise.Porpoise;
import groovy.json.JsonBuilder

class PorpoiseTestDataCapturer {

	public static boolean capture = false;
	public static int tickMod = 1;
	public static long tickStartCapture = 0;
	public static long tickEndCapture = Long.MAX_VALUE;
	public static boolean includePosList = true;
	
	def static EOL = System.getProperty("line.separator")
	def static captureFile = new File("testdata_capture" + System.currentTimeMillis() + ".txt");

	def static capture(Parameters params) {
		if (!capture) {
			return;
		}
		def json = new JsonBuilder()
		def data = json {
			parameters {
				params.getSchema().parameterNames().each {
					"${it}" params.getValue(it)
				}
			}
		}
		
		captureFile << json.toString() << EOL
	}

	def static capture(Porpoise p) {
		if (!capture) {
			return;
		}
		if (!p.alive) {
			return;
		}
		if (Globals.getTick() < tickStartCapture || Globals.getTick() > tickEndCapture) {
			return;
		}
		if (Globals.getTick() % tickMod != 0) {
			return;
		}
		def json = new JsonBuilder()
		if (includePosList) {
			def data = json {
				tick Globals.getTick()
				porp {
					id p.getId()
					x p.getPosition().x
					y p.getPosition().y
					heading p.getHeading()
					prevAngle p.prevAngle
					prevLogMov p.prevLogMov
					dispType p.dispersalBehaviour.dispersalType
					age p.age
					ageOfMaturity p.ageOfMaturity
					pregnancyStatus p.pregnancyStatus
					matingDay p.matingDay
					energyLevel p.energyLevel
					energyLevelSum p.energyLevelSum
					deterStrength p.deterStrength
					VT p.VT
					deterVt p.deterVt
					posList p.posList
				}
			}
		} else {
			def data = json {
				tick Globals.getTick()
				porp {
					id p.getId()
					x p.getPosition().x
					y p.getPosition().y
					heading p.getHeading()
					prevAngle p.prevAngle
					prevLogMov p.prevLogMov
					dispType p.dispersalBehaviour.dispersalType
					age p.age
					ageOfMaturity p.ageOfMaturity
					pregnancyStatus p.pregnancyStatus
					matingDay p.matingDay
					energyLevel p.energyLevel
					energyLevelSum p.energyLevelSum
					deterStrength p.deterStrength
					VT p.VT
					deterVt p.deterVt
				}
			}
		}
		
		captureFile << json.toString() << EOL
	}

}
