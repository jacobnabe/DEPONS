/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.util;

/**
 * An implementation of the Simple Logistic Model (SSLogis). See slide in the product backlog.
 */
public class LogisticDecreaseSSLogis {

	private final double phi1;
	private final double phi2;
	private final double phi3;

	public LogisticDecreaseSSLogis(double phi1, double phi2, double phi3) {
		this.phi1 = phi1;
		this.phi2 = phi2;
		this.phi3 = phi3;
	}

	public double calculate(double x) {
		return (phi1 / (1 + Math.exp((phi2 - x) / phi3)));
	}

}
