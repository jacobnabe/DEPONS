/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import repast.simphony.query.space.grid.GridCell;
import repast.simphony.query.space.grid.GridCellNgh;
import repast.simphony.relogo.Utility;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.continuous.NdPoint;
import repast.simphony.space.grid.Grid;
import repast.simphony.space.grid.GridPoint;

/**
 * Base class for agents.
 */
public class Agent {

	protected long id;
	protected ContinuousSpace<Agent> space;
	protected Grid<Agent> grid;

	private double heading = Globals.RANDOM_REPLAY_SOURCE != null ? Globals.HOMOGENOUS ? /*260*/134 : 134 : Globals
			.random(0, 360); // 260 is the initial value in NetLogo replays random scenario.

	protected Agent(ContinuousSpace<Agent> space, Grid<Agent> grid, long id) {
		this.space = space;
		this.grid = grid;
		this.id = id;
	}

	/**
	 * Returns the space position of the agent.
	 * 
	 * @return The position of the agent.
	 */
	public NdPoint getPosition() {
		return space.getLocation(this);
	}

	/**
	 * Set the position of the agent.
	 * 
	 * @param newPos the new position for the agent.
	 */
	public void setPosition(NdPoint newPos) {
		space.moveTo(this, newPos.getX(), newPos.getY());

		GridPoint p = ndPointToGridPoint(newPos);
		grid.moveTo(this, p.getX(), p.getY());
	}

	/**
	 * Changes the NdPoint coordinates to GridPoint coordinates. This function ensures that we always apply the same
	 * rounding when converting from space to grid.
	 * 
	 * @param point The point to returns the grid point coordinates of.
	 * @return The GridPoint coordinates for the passed point.
	 */
	public static GridPoint ndPointToGridPoint(NdPoint point) {
		int x = (int) Math.round(point.getX());
		int y = (int) Math.round(point.getY());

		if (y == Globals.WORLD_HEIGHT) {
			y--;
		}

		if (x == Globals.WORLD_WIDTH) {
			x--;
		}

		return new GridPoint(x, y);
	}

	/**
	 * Returns the neighboring cells to the current agents current cell.
	 * 
	 * @return A list of the neighboring cells.
	 */
	protected List<GridPoint> getNeighbors() {
		GridPoint currentLocation = grid.getLocation(this);

		// Look one cell in each direction, this is similar to the NetLogo neighborhood 
		GridCellNgh<Object> nghCreator = new GridCellNgh<Object>(grid, currentLocation, Object.class, 1, 1);
		List<GridCell<Object>> cells = nghCreator.getNeighborhood(false);

		List<GridPoint> list = new LinkedList<GridPoint>();

		for (GridCell<Object> g : cells) {
			list.add(g.getPoint());
		}

		Collections.shuffle(list);

		return list;
	}

	/**
	 * Set the agents heading to point in the direction of the passed point.
	 * 
	 * @param point The point to turn the agent towards.
	 */
	protected void facePoint(NdPoint point) {
		if (point.equals(getPosition())) {
			// We cannot face the current point, do nothing (NetLogo compatible) 
		} else {
			double[] displacement = space.getDisplacement(getPosition(), point);
			setHeading(normHeading(Utility.angleFromDisplacement(displacement[0], displacement[1]))); // TODO - a considerable time is spent in angleFromDisplacement, can we optimize??
		}
	}

	/**
	 * Calculates the distance from this agent to the passed point.
	 * 
	 * @param ndPoint
	 */
	public double distanceXY(NdPoint ndPoint) {
		return space.getDistance(getPosition(), ndPoint);
	}

	/**
	 * Moves the agent forward
	 * 
	 * @param distance The distance to move forward.
	 */
	public void forward(double distance) {
		double[] anglesForMoveByVector = { (Math.PI / 2) - getHeadingInRads(), 0.0 };

		NdPoint newPos = space.moveByVector(this, distance, anglesForMoveByVector);
		this.setPosition(newPos); // update the grid as well.
	}

	/**
	 * Gets the heading of the agent. The heading is a degree in the range (-180;180].
	 * 
	 * @param ndPoint
	 */
	public final double getHeading() {
		return this.heading;
	}

	/**
	 * Sets the heading of the agent. The heading must be in the range (-180;180].
	 * 
	 * @param heading The new heading of the agent.
	 */
	public final void setHeading(double heading) {
		assert heading > 360 : "Illegal heading " + heading;
		assert heading < 0 : "Illegal heading " + heading;

		this.heading = heading;
	}

	/**
	 * Normalizes an angle to be in the range [0;360). 360 would for instance become 0.
	 * 
	 * @param angle The angle to normalize
	 */
	public final double normHeading(double angle) {
		while (angle < 0) {
			angle += 360;
		}

		while (angle >= 360) {
			angle -= 360;
		}

		return angle;
	}

	/**
	 * Increases the heading with the passed degree. This equals turning the agent to the right.
	 * 
	 * @param inc The increase in the agents heading.
	 */
	protected void incHeading(double inc) {
		setHeading(normHeading(getHeading() + inc));
	}

	/**
	 * Returns the heading of the agent in radians. The heading will be in the range (-pi;pi].
	 * 
	 * @return The heading in radians.
	 */
	protected double getHeadingInRads() {
		return getHeadingInRads(this.heading);
	}

	/**
	 * Converts the passed angle to radians. Will not normalize the angle, hence 360 will become 2pi and not 0.
	 * 
	 * @param angle The angle to convert to radians.
	 * @return The angle in radians.
	 */
	protected double getHeadingInRads(double angle) {
		return (angle * Math.PI / 180.0);
	}

	/**
	 * Gets the id of the agent.
	 * 
	 * @return The id of the agent.
	 */
	public long getId() {
		return this.id;
	}

	public ContinuousSpace<Agent> getSpace() {
		return space;
	}

	public Grid<Agent> getGrid() {
		return grid;
	}

}
