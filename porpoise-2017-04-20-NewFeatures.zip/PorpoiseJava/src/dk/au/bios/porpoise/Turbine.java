/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

import repast.simphony.context.Context;
import repast.simphony.query.space.continuous.ContinuousWithin;
import repast.simphony.space.SpatialException;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.continuous.NdPoint;
import repast.simphony.space.grid.Grid;

/**
 * A turbine in a wind farm.
 * 
 * Loaded from a data file in the "data/wind-farms" sub-folder.
 */
public class Turbine extends Agent {

	/**
	 * Hold a sorted list of turbines to create. If this is not null, the turbines will be dynamically added and removed
	 * from the context based on their start and end tick.
	 */
	private static LinkedList<Turbine> TURBINE_CREATE_QUEUE;

	private String name;

	/** Deterrence effect relative to standard Roedsand-turbine */
	private double impact;

	private double locX;
	private double locY;

	private int startTick;
	private int endTick;

	protected Turbine(ContinuousSpace<Agent> space, Grid<Agent> grid, String name, double impact, double locX,
			double locY, int startTick, int endTick, int id) {
		super(space, grid, id);
		this.name = name;
		this.impact = impact;
		this.locX = locX;
		this.locY = locY;
		this.startTick = startTick;
		this.endTick = endTick;
	}

	/**
	 * Load turbines from a data file. The corresponding methods in Netlogo are turbs-import-pos and turbs-setup.
	 * 
	 * @param fileName The name of the turbines file to load (excluding path and extension).
	 * @return List of turbines read from the file.
	 * @throws Exception Error reading the file.
	 */
	public static void load(Context<Agent> context, ContinuousSpace<Agent> space, Grid<Agent> grid, String fileName,
			boolean dynamicCreation) throws Exception {
		if (dynamicCreation) {
			TURBINE_CREATE_QUEUE = new LinkedList<>();
		}

		File file = new File("data/wind-farms", fileName + ".txt");
		int numTurbines = 0;

		try (BufferedReader fr = new BufferedReader(new FileReader(file))) {
			fr.readLine(); // Header is ignored.
			String line;
			while ((line = fr.readLine()) != null) {
				String[] cols = line.split("\\s+");
				String name = cols[0];
				double locX = (Double.parseDouble(cols[1]) - Globals.XLLCORNER) / 400;
				double locY = (Double.parseDouble(cols[2]) - Globals.YLLCORNER) / 400;
				double impact = Double.parseDouble(cols[3]);
				int startTick = 0;
				int endTick = Integer.MAX_VALUE;
				if (cols.length >= 5) {
					startTick = Integer.parseInt(cols[4]);
				}
				if (cols.length >= 6) {
					endTick = Integer.parseInt(cols[5]);
				}

				Turbine t = new Turbine(space, grid, name, impact, locX, locY, startTick, endTick, numTurbines);
				if (TURBINE_CREATE_QUEUE != null) {
					TURBINE_CREATE_QUEUE.add(t);
				} else {
					context.add(t);
					t.initialize();
				}

				numTurbines++;
			}
		}

		System.out.println("Showing wind turbines at: " + fileName);
		if (TURBINE_CREATE_QUEUE != null) {
			if (numTurbines < 1) {
				System.out.println("No wind turbines plotted");
			} else {
				Collections.sort(TURBINE_CREATE_QUEUE, new Comparator<Turbine>() {
					@Override
					public int compare(Turbine o1, Turbine o2) {
						if (o1.startTick > o2.startTick) {
							return 1;
						} else if (o1.startTick == o2.startTick) {
							return 0;
						} else {
							return -1;
						}
					}
				});
			}
		}
	}

	public static void activateTurbines(Context<Agent> context, ContinuousSpace<Agent> space, Grid<Agent> grid) {
		if (TURBINE_CREATE_QUEUE == null) {
			return; // Turbines not loaded or not using dynamic creation
		}

		double now = Globals.getTick();
		do {
			if (TURBINE_CREATE_QUEUE.isEmpty()) {
				break;
			}
			Turbine first = TURBINE_CREATE_QUEUE.getFirst();
			if (first != null && first.startTick <= now) {
				context.add(first);
				try {
					first.initialize();
				} catch (SpatialException e) {
					context.remove(first);
					System.err.println("Did not add turbine " + first.name + " due to an error." + e.getMessage());
				}
				TURBINE_CREATE_QUEUE.removeFirst();
			} else {
				break;
			}
		} while (true);
	}

	public static void deactiveTurbines(Context<Agent> context) {
		if (TURBINE_CREATE_QUEUE == null) {
			return;
		}

		double now = Globals.getTick();
		List<Turbine> turbinesToRemove = new LinkedList<>();
		for (Agent a : context.getObjects(Turbine.class)) {
			Turbine t = (Turbine) a;
			if (t.getEndTick() < now) {
				turbinesToRemove.add(t);
			} else {
				t.deterPorpoise();
			}
		}
		for (Turbine t : turbinesToRemove) {
			context.remove(t);
		}
	}

	private void initialize() {
		this.setPosition(new NdPoint(locX, locY));
	}

	public void deterPorpoise() {

		int simTick = (int) Globals.getTick();
		if (simTick >= startTick && simTick <= endTick) {
			// the actual distance up to which porpoises react to noise from 
			// a turbine with a specific impact (where impact = sound source level (SL), in dB).
			// this is the distance where the sound level drops below the threshold
			double radius = Math.pow(10, ((impact - Globals.DETER_RESPONSE_THRESHOLD) / 20));
			ContinuousWithin<Agent> affectedSpace = new ContinuousWithin<Agent>(this.space, this, radius);
			Iterable<Agent> agents = affectedSpace.query();
			for (Agent a : agents) {
				if (a instanceof Porpoise) {
					Porpoise p = (Porpoise) a;
					double distToTurb = this.space.getDistance(getPosition(), p.getPosition()) * 400;
					if (distToTurb <= Globals.DETER_MAX_DISTANCE) {
						// current amount of deterring
						// the received-level (RL) gives the amount of noise that the porpoise is exposed to 
						// at a given distance, assuming cylindrical sound spreading; RL = SL � 20Log10(dist)
						double currentDeterence = impact - (20 * Math.log10(distToTurb))
								- Globals.DETER_RESPONSE_THRESHOLD;

						if (currentDeterence > 0) {
							p.deter(currentDeterence, this);
						}

						if (Globals.DEBUG == 8) {
							Globals.print("(porp " + p.getId() + ") dist-to-turb " + this.name + ": "
									+ Math.round(distToTurb) + " m, curr.deter: " + Math.round(currentDeterence));
						}
					}
				}
			}
		}
	}

	public double getImpact() {
		return impact;
	}

	public int getStartTick() {
		return startTick;
	}

	public int getEndTick() {
		return endTick;
	}

}
