/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise;

import java.util.concurrent.atomic.AtomicLong;

import repast.simphony.context.Context;
import repast.simphony.query.space.continuous.ContinuousWithin;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.continuous.NdPoint;
import repast.simphony.space.grid.Grid;

/**
 * A generic sound source agent. This has been used for the deterrence testing.
 * It is not directly used in the DEPONS model.
 */
public class SoundSource extends Agent {

	private static AtomicLong SOUND_SOURCE_ID = new AtomicLong();

	private double impact;

	public SoundSource(ContinuousSpace<Agent> space, Grid<Agent> grid, double impact) {
		super(space, grid, SOUND_SOURCE_ID.incrementAndGet());
		this.impact = impact;
	}

	public SoundSource(Context<Agent> context, ContinuousSpace<Agent> space, Grid<Agent> grid, Porpoise p,
			double angleFromPorpoise, double distanceFromPorpoise, double impact) {
		this(space, grid, impact);

		context.add(this);
		setPosition(p.getPosition());
		NdPoint position = space.moveByVector(this, distanceFromPorpoise,
				((angleFromPorpoise - 90.0) * -Math.PI / 180.0), 0);
		this.setPosition(position);
	}

	/**
	 * Deters nearby porpoises
	 */
	public void deterPorpoise() {
		// number of grid-cells where a wind turbine or ship with impact 1 (standard deterrence strength) affects a porpoise
		double radius = Math.pow(10, ((impact - Globals.DETER_RESPONSE_THRESHOLD) / 20));

		// i.e. porps <deter-dist away (although porps can hear only ships <200 away, the dist has to be larger to account for porp jumping)
		ContinuousWithin<Agent> affectedSpace = new ContinuousWithin<Agent>(this.space, this, radius);
		Iterable<Agent> agents = affectedSpace.query();

		for (Agent a : agents) {
			if (a instanceof Porpoise) {
				Porpoise p = (Porpoise) a;
				double distToShip = this.space.getDistance(getPosition(), p.getPosition()) * 400;
				if (distToShip <= Globals.DETER_MAX_DISTANCE) {
					// deterring-strength decreases linearly with distance to turbine, decreases to 0 at 400 m
					double currentDeterence = impact - (20 * Math.log10(distToShip)) - Globals.DETER_RESPONSE_THRESHOLD;

					if (currentDeterence > 0) {
						p.deter(currentDeterence, this);
					}

					if (Globals.DEBUG == 8) {
						Globals.print("who: " + p.getId() + " dist-to-ship " + this + ": " + distToShip);
					}
				}
			}
		}
	}

	public double getImpact() {
		return this.impact;
	}

}
