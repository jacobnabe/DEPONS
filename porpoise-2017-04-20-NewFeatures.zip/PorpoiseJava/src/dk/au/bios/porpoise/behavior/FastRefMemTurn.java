/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.behavior;

import repast.simphony.space.continuous.NdPoint;
import repast.simphony.space.grid.GridPoint;
import dk.au.bios.porpoise.Agent;
import dk.au.bios.porpoise.CellData;
import dk.au.bios.porpoise.Globals;
import dk.au.bios.porpoise.Porpoise;
import dk.au.bios.porpoise.util.CircularBuffer;

/**
 * Improved implementation of the RefMemTurnCalculator.
 */
public class FastRefMemTurn implements RefMemTurnCalculator {

	@Override
	public double[] refMemTurn(Porpoise p, CellData cellData, CircularBuffer<Double> storedUtilList,
			CircularBuffer<NdPoint> posList) {
		// Move towards places visited previously if food was found there and they aren't too far away or forgotten.

		GridPoint pos = Agent.ndPointToGridPoint(p.getPosition());

		// Stationary food species. The stored intrisic patch utility for t=0. Initially it is either 0, 1, or -9999, 
		// but grows logistically after food is eaten
		double bb = cellData.getFoodLevel(pos);  

		if (Double.isNaN(bb)) { // bb = Na ?!
			// There are errors in food availability -- sometimes Na is calculated even though depth is > 0. Catch error here
			bb = 0;
			if (Globals.DEBUG == 4) {
				Globals.print("Replaced NaN food value with 0");
				Globals.print(pos.toString());
			}
		}

		storedUtilList.add(bb);
		// this.storedUtilList.addFirst(bb);

		double vectorLgt = 0;
		int ii = 1;

		double distToFoodpos = 0;
		double vtX = 0;
		double vtY = 0;

		while (ii < posList.size()) {
			if (storedUtilList.get(ii) != 0) {
				distToFoodpos = p.distanceXY(posList.get(ii));

				double factor;

				if (distToFoodpos < 1E-20) {
					factor = 9999;
				} else {
					factor = storedUtilList.get(ii) * Globals.REF_MEM_STRENGTH_LIST_FIXED[ii] / distToFoodpos;
				}

				NdPoint posII = posList.get(ii);
				NdPoint curPos = p.getPosition();
				double attrX = posII.getX() - curPos.getX();
				double attrY = posII.getY() - curPos.getY();

				if (attrX > Globals.WORLD_WIDTH / 2) {
					attrX -= Globals.WORLD_WIDTH;
				}
				if (attrX < -Globals.WORLD_WIDTH / 2) {
					attrX += Globals.WORLD_WIDTH;
				}
				if (attrY > Globals.WORLD_HEIGHT / 2) {
					attrY -= Globals.WORLD_HEIGHT;
				}
				if (attrY < -Globals.WORLD_HEIGHT / 2) {
					attrY += Globals.WORLD_HEIGHT;
				}

				vectorLgt = Math.sqrt(attrX * attrX + attrY * attrY);

				if (vectorLgt == 0) {
					if (Globals.DEBUG == 4) {
						Globals.print(p.getId() + " attr-vector-lgt = " + vectorLgt + " skipping to next porp");
					}
					return null;
				}

				attrX /= vectorLgt;
				attrY /= vectorLgt;

				vtX += (factor * attrX);
				vtY += (factor * attrY);
			}
			ii++;
		}

		if (Globals.DEBUG == 4) {
			Globals.print("Food here: " + bb + ", Attr.v: " + vtX + "," + vtY);

			/*
			if (Double.isNaN(vtX))
			 Globals.print("Perc.util " + perceivedUtilList);
			*/
		}

		return new double[] { vtX, vtY };
	}

}
