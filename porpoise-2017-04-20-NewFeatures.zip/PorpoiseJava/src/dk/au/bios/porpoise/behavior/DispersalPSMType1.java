/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.behavior;

import dk.au.bios.porpoise.Globals;
import dk.au.bios.porpoise.Porpoise;

/**
 * Implementation of PSM-Type1 dispersal behaviour.
 * 
 * NB! Not tested after refactoring!
 */
public class DispersalPSMType1 implements Dispersal {

	private final Porpoise owner;
	private boolean active = false;

	public DispersalPSMType1(Porpoise owner) {
		this.owner = owner;
	}

	@Override
	public boolean isDispersing() {
		return active;
	}

	@Override
	public int getDispersalType() {
		if (active) {
			return 3;
		} else {
			return 0;
		}
	}

	@Override
	public void activate() {
		active = true;
	}

	@Override
	public void deactivate() {
//		owner.getPersistentSpatialMemory().setActive(false);
		active = false;
	}

	public void disperse() {
		if (!active) {
			return;
		}

		if (owner.getPersistentSpatialMemory().hasTraveledDistance()) {
			owner.getPersistentSpatialMemory().setActive(false);
			this.active = false;
			return;
		}

		// int startUtmX = getUtmX(); // PSM Verification
		// int startUtmY = getUtmY(); // PSM Verification
		// double startHeading = getHeading(); // PSM Verification

		Globals.replayPrint("disp3-heading-before: {0}", owner.getHeading());

		owner.setHeading(owner.getPersistentSpatialMemory().getCalculatedHeading());
		Globals.replayPrint("disp3-heading-before after PSM: {0} mean-disp-dist ?mean-disp-dist?", owner.getHeading());

		if (!owner.isEnoughWaterAhead()) {
			this.deactivate();
			owner.getPersistentSpatialMemory().setActive(false);

			if (Globals.DEBUG == 7 && (owner.getId() == 0 || owner.getId() == 1)) {
				Globals.print("NO WATER, stop dispersing (3 - not enough water ahead) (porp " + owner.getId() + ")");
			}
		}

		if (!(owner.getCellData().getDepth(owner.getPointAhead(Globals.MEAN_DISP_DIST / 0.4)) > Globals.MIN_DEPTH)) {
			this.deactivate();
			owner.getPersistentSpatialMemory().setActive(false);

			if (Globals.DEBUG == 7 && (owner.getId() == 0 || owner.getId() == 1)) {
				Globals.print(owner.getId() + " LOW water, stop dispersing (3)");
			}
		}

		if (owner.getDispersalMode() == 3) {
			double percentageToTravel = owner.getPersistentSpatialMemory().calculateDistancePercentageToTravel();
			double distanceToTravel = percentageToTravel * (Globals.MEAN_DISP_DIST / 0.4);
			owner.forward(distanceToTravel);
			owner.getPersistentSpatialMemory().addDistanceTraveled(distanceToTravel);
			// FIXME Add this modification to the Porpoise owner!!: tickMoveAdjustMultiplier = tickMoveAdjustMultiplier - percentageToTravel;

			double consumed = 0.001 * Globals.E_USE_PER_KM * distanceToTravel;
			Globals.replayPrint("energy before consume food disp3 {0} consumed  {1}", owner.getEnergyLevel(), consumed);
			owner.consumeEnergy(consumed);

			if (owner.isWritePsmSteps()) {
				Globals.writePSMVerificationPSM("PSM", owner, distanceToTravel);
			}
		}
	}

}
