/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.behavior;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import repast.simphony.space.continuous.NdPoint;
import repast.simphony.space.grid.GridPoint;
import dk.au.bios.porpoise.Agent;
import dk.au.bios.porpoise.CellData;
import dk.au.bios.porpoise.Globals;
import dk.au.bios.porpoise.Porpoise;

/**
 * Implements a spatial memory. The memory cells are coarser grained than the general world grid. Each memory cell is 5
 * "world grid units" (2 km).
 */
public class PersistentSpatialMemory {

	private static final int MEM_CELL_SIZE = 5; // each grid cell is 400m, mem cells are 2 km.

	private Porpoise owner;
	private int targetMemCell;
	private NdPoint targetPos;
	private NdPoint startPos;
	private double targetHeading;
	private double distanceTraveled;
	private double targetDistanceAtActivation;
	private double previousStepHeading;
	private double preferredDistance;

	private static class MemCellData {
		private long ticksSpent = 0;
		private double foodObtained = 0.0d;

		public void updateFoodEaten(double foodEaten) {
			this.foodObtained += foodEaten;
			this.ticksSpent++;
		}

		public long getTicksSpent() {
			return ticksSpent;
		}

		public double getFoodObtained() {
			return foodObtained;
		}

		@Override
		public String toString() {
			return "[ticksSpent=" + ticksSpent + ", foodObtained=" + foodObtained + "]";
		}

	}

	// Map of cell data keyed by cellNumber (id). Only holds data for actually visited cells.
	private Map<Integer, MemCellData> memCellData = new HashMap<>();
	private volatile boolean active = false;
	final int cellsPerRow;
	private CellData cellData;

	public static double generatedPreferredDistance() {
		double prefDistance = Globals.RANDOM_SOURCE.nextPSMDistanceStddev();
		prefDistance = Math.max(prefDistance, 1.0); // Just a fail-safe to have at least 1KM

		return prefDistance;
	}

	public PersistentSpatialMemory(Porpoise owner, int worldWidth, int worldHeight, CellData cellData, double preferredDistance) {
		this.owner = owner;
		this.cellData = cellData;
		cellsPerRow = Globals.WORLD_WIDTH / MEM_CELL_SIZE;

		this.preferredDistance = preferredDistance;
	}

	/**
	 * Calculates the MemCell id for a map location.
	 * 
	 * @param position The location to calculate for.
	 * @return The MemCell for the location.
	 */
	public int calculateMemCellNumber(NdPoint position) {
		GridPoint gridPoint = Agent.ndPointToGridPoint(position);
		int x = gridPoint.getX();
		int y = gridPoint.getY();

		int cellX = (int) Math.floor(x / MEM_CELL_SIZE);
		int cellY = (int) Math.floor(y / MEM_CELL_SIZE);

		int cellNumber = (cellY * cellsPerRow) + cellX;

		return cellNumber;
	}

	/**
	 * Update the PSM. This is to be called at every tick.
	 * 
	 * @param position The current position.
	 * @param foodEaten The amount of food eaten at this position.
	 */
	public void updateMemory(NdPoint position, double foodEaten) {
		if (foodEaten > 0.0f) {
			int cellNumber = calculateMemCellNumber(position);
			MemCellData cell = memCellData.get(cellNumber);
			if (cell == null) {
				cell = new MemCellData();
				memCellData.put(cellNumber, cell);
			}

			cell.updateFoodEaten(foodEaten);
		}
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("PersistentSpatialMemory: ");

		boolean first = true;
		Set<Entry<Integer, MemCellData>> data = memCellData.entrySet();
		for (Entry<Integer, MemCellData> entry : data) {
			if (!first) {
				sb.append(", ");
			}
			sb.append("{");
			sb.append(entry.getKey()).append(": ");
			sb.append(entry.getValue().getTicksSpent());
			sb.append(", ").append(entry.getValue().getFoodObtained());
			sb.append("}");
			first = false;
		}
		return sb.toString();
	}

	public int findMostAttractiveMemCell() {
		// Ensure we have a reasonable memory
		if (memCellData.size() < 50) {
			return -1;
		}

		// Find candidate PSM cells considered preferred travel distance
		double preferredMinDist = (preferredDistance - Globals.PSM_PREFERRED_DISTANCE_TOLERANCE) / 0.4;
		double preferredMaxDist = (preferredDistance + Globals.PSM_PREFERRED_DISTANCE_TOLERANCE) / 0.4;
		Map<Integer, MemCellData> candidates = new HashMap<>();
		for (Entry<Integer, MemCellData> entry : memCellData.entrySet()) {
			NdPoint center = calcMemCellCenterPoint(entry.getKey());

			double distanceToCell = this.owner.distanceXY(center);
			if (distanceToCell >= preferredMinDist && distanceToCell <= preferredMaxDist) {
				candidates.put(entry.getKey(), entry.getValue());
			}
		}

		// Check the candidate cells for food over time
		int mostAttractiveCellNumber = -1;
		double mostAttractiveFitness = -1.0d;
		Set<Entry<Integer, MemCellData>> data = candidates.entrySet();
		for (Entry<Integer, MemCellData> entry : data) {
			// Cells fitness is determined by food eaten divided by time spent in cell.
			double cellFitness = entry.getValue().getFoodObtained() / entry.getValue().getTicksSpent();
			if (cellFitness > mostAttractiveFitness) {
				mostAttractiveFitness = cellFitness;
				mostAttractiveCellNumber = entry.getKey();
			}
		}

		return mostAttractiveCellNumber;
	}

	public NdPoint calcMemCellCenterPoint(int cellNumber) {
		int cellsPerRow = Globals.WORLD_WIDTH / MEM_CELL_SIZE;

		int cellX = (cellNumber % cellsPerRow) * MEM_CELL_SIZE;
		int cellY = (cellNumber / cellsPerRow) * MEM_CELL_SIZE;

		return new NdPoint(cellX + (MEM_CELL_SIZE / 2), cellY + (MEM_CELL_SIZE / 2));
	}

	public boolean isPointInTargetMemCell(GridPoint point) {
		if (targetMemCell < 0) {
			return false;
		}

		int cellX = (targetMemCell % cellsPerRow) * MEM_CELL_SIZE;
		int cellY = (targetMemCell / cellsPerRow) * MEM_CELL_SIZE;

		if (point.getX() >= cellX && point.getX() < (cellX + MEM_CELL_SIZE) && point.getY() >= cellY
				&& point.getY() < (cellY + MEM_CELL_SIZE)) {
			return true;
		}

		return false;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean activate) {
		//		System.err.println("PSM setActive(" + activate + ")");
		if (!active && activate) {
			if (Globals.DEBUG == 4) {
				Globals.print("PSM - activating. " + this.toString());
			}

			startPos = new NdPoint(owner.getPosition().getX(), owner.getPosition().getY());

			targetMemCell = findMostAttractiveMemCell();
			if (targetMemCell >= 0) {
				targetPos = calcMemCellCenterPoint(targetMemCell);
				double targetHeadingRadian = Math.atan2(targetPos.getY() - startPos.getY(),
						targetPos.getX() - startPos.getX());
				targetHeading = 90.0d - Math.toDegrees(targetHeadingRadian);
				if (targetHeading < 0.0) {
					targetHeading += 360.0;
				}
			} else {
				int maxAttempts = 1000;
				while (maxAttempts > 0) {
					maxAttempts--;
					double newTargetHeading = Globals.RANDOM_SOURCE.nextDouble() * 360; // Not sure where to go
					double targetHeadingRads = Math.toRadians(newTargetHeading);
					double randomToleranceAdjustment = (Globals.RANDOM_SOURCE.nextDouble() * (Globals.PSM_PREFERRED_DISTANCE_TOLERANCE * 2))
							- Globals.PSM_PREFERRED_DISTANCE_TOLERANCE;
					double distanceToTravel = (preferredDistance + randomToleranceAdjustment) / 0.4;
					NdPoint newTargetPos = new NdPoint(startPos.getX()
							+ (distanceToTravel * Math.sin(targetHeadingRads)), startPos.getY()
							+ (distanceToTravel * Math.cos(targetHeadingRads)));
					GridPoint targetGridPoint = Agent.ndPointToGridPoint(newTargetPos);

					if (cellData.getDepth(targetGridPoint) > 0 && !cellData.isPointMasked(targetGridPoint)) {
						if (cellData.getMaxEnt()[targetGridPoint.getX()][targetGridPoint.getY()] > 0.0f) {
							this.targetHeading = newTargetHeading;
							this.targetPos = newTargetPos;
							break;
						}
					}
				}
				if (maxAttempts < 1) {
					// Failed to find a suitable target, deactivate PSM
					System.err.println("" + owner.getId()
							+ "Failed to find a suitable random PSM cell! Current position: " + owner.getPosition());
					this.active = false;
					return;
				}
			}
			double startDistX = targetPos.getX() - startPos.getX();
			double startDistY = targetPos.getY() - startPos.getY();
			this.targetDistanceAtActivation = Math.hypot(startDistX, startDistY) * 0.95; // Stop when 95% of the distance has been travelled
			this.distanceTraveled = 0;
			this.previousStepHeading = targetHeading;
			this.active = true;
		} else {
			this.targetMemCell = -1;
			this.targetPos = null;
			this.startPos = null;
			this.targetHeading = 0;
			this.active = false;
			this.distanceTraveled = 0;
		}
	}

	/**
	 * Returns the target position (most attractive cell) if the PSM is active. If the PSM is not active,
	 * <code>null</code> is returned.
	 * 
	 * @return
	 */
	public NdPoint getTargetPosition() {
		return targetPos;
	}

	/**
	 * Returns the position where the PSM was activated. If the PSM is not active, <code>null</code> is returned.
	 * 
	 * @return
	 */
	public NdPoint getStartPosition() {
		return startPos;
	}

	public double getTargetHeading() {
		return targetHeading;
	}

	public double getPreferredDistance() {
		return preferredDistance;
	}

	public double getCalculatedHeading() {
		if (!isActive()) {
			return owner.getHeading();
		}

		return targetHeading;
	}

	/**
	 * Calculates the angle to turn during dispersal. The angle is a random angle in the range +/- parameter
	 * psm-type2-turn-angle multiplied by the output of a logistic increase function. The input to the logistic increase
	 * function is the distance traveled from the starting location (when dispersal was activated) to the PSM target
	 * cell.
	 * 
	 * This is used in PSM-Type2 dispersal.
	 * 
	 * @return
	 */
	public double calculateAdjustedRandomHeading() {
		if (!isActive()) {
			return owner.getHeading();
		}

		double angleDelta = ((Globals.PSM_TYPE2_RANDOM_ANGLE * 2) * Globals.RANDOM_SOURCE.nextDouble()) - (Globals.PSM_TYPE2_RANDOM_ANGLE);

		double distPerc = distanceTraveled / targetDistanceAtActivation;
		double distLogX = (3 * distPerc) - 1.5;
		double logDistPerc = Globals.PSM_LOGISTIC_DECREASE_FUNCTION.calculate(distLogX); // param must be distance traveled

		angleDelta = angleDelta * logDistPerc;

		double newHeading = previousStepHeading + angleDelta;
		previousStepHeading = newHeading;

		return newHeading;
	}

	/**
	 * Calculates the percentage of the maximum dispersal distance to travel in this tick. This depends on the distance
	 * already travelled compared to the distance from the starting point (when dispersal was activated) to the PSM
	 * target cell. The travelled percentage is used as input to a logistic decrease function.
	 * 
	 * This is used in PSM-Type1 dispersal.
	 * 
	 * @return
	 */
	public double calculateDistancePercentageToTravel() {
		double distPerc = (distanceTraveled / targetDistanceAtActivation);
		double distLogX = (3 * distPerc) - 1.5;
		double logDistPerc = 1 - (Globals.PSM_LOGISTIC_DECREASE_FUNCTION.calculate(distLogX)); // param must be distance traveled

		return logDistPerc;
	}

	public void addDistanceTraveled(double distance) {
		if (isActive()) {
			this.distanceTraveled += distance;
		}
	}

	public boolean hasTraveledDistance() {
		//		System.err.printf("PSM startPos: {%.2f, %.2f}, targetPos: {%.2f, %.2f}%n", refMemStartPos.getX(), refMemStartPos.getY(), refMemTargetPos.getX(), refMemTargetPos.getY());
		//		System.err.printf("PSM(%s) distStart: %.2f, distanceTraveled: %.2f, still to go: %.2f%n", Boolean.toString(active), distStart, distanceTraveled, distStart - distanceTraveled);
		if (distanceTraveled >= targetDistanceAtActivation) {
			return true;
		} else {
			return false;
		}
	}

	public double getDistanceLeftToTravel() {
		return targetDistanceAtActivation - distanceTraveled;
	}

}
