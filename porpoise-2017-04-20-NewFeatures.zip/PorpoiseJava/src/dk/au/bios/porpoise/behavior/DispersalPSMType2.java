/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.behavior;

import repast.simphony.space.continuous.NdPoint;
import dk.au.bios.porpoise.Globals;
import dk.au.bios.porpoise.Porpoise;

public class DispersalPSMType2 implements Dispersal {

	private final Porpoise owner;
	private boolean active = false;

	public DispersalPSMType2(Porpoise owner) {
		this.owner = owner;
	}

	@Override
	public boolean isDispersing() {
		return active;
	}

	@Override
	public int getDispersalType() {
		if (active) {
			return 3;
		} else {
			return 0;
		}
	}

	@Override
	public void activate() {
		active = true;
	}

	@Override
	public void deactivate() {
		active = false;
		owner.getPersistentSpatialMemory().setActive(false);
	}

	public void disperse() {
		if (!active) {
			return;
		}

		if (owner.getPersistentSpatialMemory().hasTraveledDistance()) {
			deactivate();
			return;
		}

		Globals.replayPrint("disp3-heading-before: {0}", owner.getHeading());

		double startHeading = owner.getHeading();
		owner.setHeading(owner.getPersistentSpatialMemory().calculateAdjustedRandomHeading());
		Globals.replayPrint("disp3-heading-before after PSM: {0} mean-disp-dist ?mean-disp-dist?", owner.getHeading());

		// Stop dispersing if wanting to move to low water (based on Porpoise.enoughWaterAhead property.
		if (!owner.isEnoughWaterAhead()) {
			deactivate();
			owner.setHeading(startHeading);

			if (Globals.DEBUG == 7 && (owner.getId() == 0 || owner.getId() == 1)) {
				Globals.print("NO WATER, stop dispersing (3 - not enough water ahead) (porp " + owner.getId() + ")");
			}

			return;
		}


		// Stop dispersing if trying to leave landscape
		NdPoint directPointAhead = owner.getPointAtHeadingAndDistNoBorder(owner.getHeading(), Globals.MEAN_DISP_DIST / 0.4);
		if (directPointAhead.getX() < 0.0 || directPointAhead.getY() < 0.0 || directPointAhead.getX() >= (Globals.WORLD_WIDTH - 0.5) || directPointAhead.getY() >= (Globals.WORLD_HEIGHT - 0.5)) {
			deactivate();
			owner.setHeading(startHeading);

			if (Globals.DEBUG == 7 && (owner.getId() == 0 || owner.getId() == 1)) {
				Globals.print(owner.getId() + " moving outside landscape, stop dispersing (3)");
			}

			return;
		}

		NdPoint pointAhead = owner.getPointAhead(Globals.MEAN_DISP_DIST / 0.4);

		// Stop dispersing if wanting to move to low water
		if (!(owner.getCellData().getDepth(pointAhead) > Globals.MIN_DEPTH)) {
			deactivate();
			owner.setHeading(startHeading);

			if (Globals.DEBUG == 7 && (owner.getId() == 0 || owner.getId() == 1)) {
				Globals.print(owner.getId() + " LOW water, stop dispersing (3)");
			}

			return;
		}

		// If still dispersing, we make the dispersal move
		if (isDispersing()) {
			double percentageToTravel = 1.0; // psm.calculateDistancePercentageToTravel();
			double distanceToTravel = percentageToTravel * (Globals.MEAN_DISP_DIST / 0.4);
			owner.forward(distanceToTravel);
			
//			NdPoint currentPos = owner.getPosition();
//			if (Math.abs(currentPos.getX() - pointAhead.getX()) > 0.005 || Math.abs(currentPos.getY() - pointAhead.getY()) > 0.005) {
//				System.out.println("" + owner.getId() + " @tick " + Globals.getTick() + " did not move full distance.");
//			}
			owner.getPersistentSpatialMemory().addDistanceTraveled(distanceToTravel);

			double consumed = 0.001 * Globals.E_USE_PER_KM * distanceToTravel;
			Globals.replayPrint("energy before consume food disp3 {0} consumed  {1}", owner.getEnergyLevel(), consumed);
			owner.consumeEnergy(consumed);

			if (owner.isWritePsmSteps()) {
				Globals.writePSMVerificationPSM("PSM", owner, distanceToTravel);
			}
		}
	}

}
