/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.behavior;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import repast.simphony.parameter.Parameters;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.continuous.NdPoint;
import cern.jet.random.Normal;
import cern.jet.random.Uniform;
import dk.au.bios.porpoise.Globals;

/**
 * Implementation of RandomSource which generates the random numbers using the Repast RandomHelper.
 * This is the implementation normally used in the simulation.
 */
public class GeneratedRandomSource implements RandomSource {

	private static final Pattern pattern = Pattern.compile("N\\((\\d+(\\.\\d+)?);(\\d+(\\.\\d+)?)\\)");

	private final Normal RANDOM_MATING_DAY_NORMAL;
	private final Normal ENERGY_RANDOM_NORMAL;
	private final Normal RANDOM_NORMAL_0_38;
	private final Normal RANDOM_NORMAL_96_28;
	private final Normal RANDOM_NORMAL_042_048;
	private final Normal RANDOM_PSM_DIST_STDDEV;
	private final Uniform RANDOM_STDMOVE;
	private final Uniform RANDOM_ENERGY;
	private final Uniform RANDOM_MORTALITY;
	private final Uniform RANDOM_PREG_CONCEIVE;
	private final Uniform RANDOM_PREG_GENDER;
	private final Uniform RANDOM_AVOID_LAND;
	private final Uniform RANDOM_DEFAULT_UNIFORM;

	public GeneratedRandomSource(Parameters params) {
		RANDOM_MATING_DAY_NORMAL = createNormalFromParameter("tmating", params);
		ENERGY_RANDOM_NORMAL = createNormalFromParameter("Einit", params);
		RANDOM_NORMAL_0_38 = createNormalFromParameter("R2", params);
		RANDOM_NORMAL_96_28 = createNormalFromParameter("R3", params);
		RANDOM_NORMAL_042_048 = createNormalFromParameter("R1", params);
		RANDOM_PSM_DIST_STDDEV = createNormalFromParameter("PSM_dist", params);
		RANDOM_STDMOVE = RandomHelper.createUniform(0, 20);
		RANDOM_ENERGY = RandomHelper.createUniform(0, 1);
		RANDOM_MORTALITY = RandomHelper.createUniform(0, 1);
		RANDOM_PREG_CONCEIVE = RandomHelper.createUniform(0, 1);
		RANDOM_PREG_GENDER = RandomHelper.createUniform(0, 1);
		RANDOM_AVOID_LAND = RandomHelper.createUniform(0, 10);
		RANDOM_DEFAULT_UNIFORM = RandomHelper.createUniform(0, 1);
	}

	private Normal createNormalFromParameter(String paramName, Parameters params) {
		String normalSpec = params.getString(paramName);
		Matcher matcher = pattern.matcher(normalSpec);
		if (matcher.matches()) {
			double mean = Double.parseDouble(matcher.group(1));
			double stddev = Double.parseDouble(matcher.group(3));

			return RandomHelper.createNormal(mean, stddev);
		} else {
			throw new IllegalArgumentException("The value of parameter " + paramName
					+ " is not a valid Random Normal. Value: " + normalSpec);
		}
	}

	@Override
	public double nextEnergeticUpdate(double from, double to) {
//		return Globals.randomFloat(from, to);
		return RANDOM_ENERGY.nextDouble();
	}

	@Override
	public double nextMortality(double from, double to) {
//		return Globals.randomFloat(from, to);
		return RANDOM_MORTALITY.nextDouble();
	}

	@Override
	public double nextPregnancyStatusConceive(double from, double to) {
//		return Globals.randomFloat(from, to);
		return RANDOM_PREG_CONCEIVE.nextDouble();
	}

	@Override
	public double nextPregnancyStatusBoyGirl(double from, double to) {
//		return Globals.randomFloat(from, to);
		return RANDOM_PREG_GENDER.nextDouble();
	}

	@Override
	public double nextDouble() {
		return RANDOM_DEFAULT_UNIFORM.nextDouble();
	}

	@Override
	public int nextAvoidLand(int from, int to) {
//		return Globals.random(from, to);
		return RANDOM_AVOID_LAND.nextInt();
	}

	@Override
	public int nextDisp3(int from, int to) {
		return Globals.random(from, to);
	}

	@Override
	public int nextDispTargetSelect(int from, int to) {
//		return Globals.random(from, to);
		return (int) (RANDOM_PREG_GENDER.nextDouble() * to);
	}

	@Override
	public int nextStdMove(int from, int to) {
//		return Globals.random(from, to);
		return RANDOM_STDMOVE.nextInt();
	}

	@Override
	public int nextAgeDistrib(int from, int to) {
		return Globals.random(from, to);
	}

	@Override
	public double nextEnergyNormal() {
		return ENERGY_RANDOM_NORMAL.nextDouble();
	}

	@Override
	public double nextMatingDayNormal() {
		return RANDOM_MATING_DAY_NORMAL.nextDouble();
	}

	@Override
	public double nextNormal_0_38() {
		return RANDOM_NORMAL_0_38.nextDouble();
	}

	@Override
	public double nextNormal_42_48() {
		return RANDOM_NORMAL_042_048.nextDouble();
	}

	@Override
	public double nextNormal_96_28() {
		return RANDOM_NORMAL_96_28.nextDouble();
	}

	@Override
	public int pastLoc(String id, int max) {
		return Globals.random(0, max);
	}

	@Override
	public NdPoint getInitialPoint() {
		return null;
	}

	@Override
	public Double getInitialHeading() {
		return null;
	}

	@Override
	public double nextPSMDistanceStddev() {
		return RANDOM_PSM_DIST_STDDEV.nextDouble();
	}

}
