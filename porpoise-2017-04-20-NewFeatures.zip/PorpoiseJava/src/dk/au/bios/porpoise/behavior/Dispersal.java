/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.behavior;

public interface Dispersal {

	/**
	 * Determine whether dispersal is currently activated.
	 *
	 * @return True if currently dispersing, false otherwise.
	 */
	boolean isDispersing();

	/**
	 * Get the integer number identifying the current dispersal state.
	 * @return
	 */
	int getDispersalType();

	/**
	 * Activates the dispersal.
	 */
	void activate();

	/**
	 * Deactivates the dispersal.
	 */
	void deactivate();

	/**
	 * Performs the dispersal step. If the dispersal step could not be performed (e.g. hitting land) then no movement
	 * should be performed (i.e. it should be as if no change has been made) and the dispersal should be deactivated.
	 */
	void disperse();

}
