/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise;

/**
 * Captures some statistics for the model. For for data output and not an active agent in the simulation.
 */
public class PorpoiseStatistics extends Agent {

	private int numBirths = 0;
	private int numDeaths = 0;
	private int numDeathsByStarvation = 0;
	private int numDeathsByOldAge = 0;
	private int numDeathsByByCatch = 0;

	public PorpoiseStatistics() {
		super(null, null, 0);
	}

	public void addBirth() {
		numBirths++;
		Globals.USER_PANEL.setNumberOfBirths(numBirths);
	}

	public void addDeath(CauseOfDeath cause) {
		numDeaths++;
		Globals.USER_PANEL.setNumberOfDeaths(numDeaths);

		switch (cause) {
		case ByCatch:
			numDeathsByByCatch++;
			Globals.USER_PANEL.setNumberOfDeathsByByCatch(numDeathsByByCatch);
			break;
		case OldAge:
			numDeathsByOldAge++;
			Globals.USER_PANEL.setNumberOfDeathsByOldAge(numDeathsByOldAge);
			break;
		case Starvation:
			numDeathsByStarvation++;
			Globals.USER_PANEL.setNumberOfDeathsStarvation(numDeathsByStarvation);
			break;
		}
	}

	public int getNumberOfBirths() {
		return numBirths;
	}

	public int getNumberOfDeaths() {
		return numDeaths;
	}

	/**
	 * Should be reset every month.
	 */
	public void resetStats() {
		numBirths = 0;
		numDeaths = 0;
		numDeathsByStarvation = 0;
		numDeathsByOldAge = 0;
		numDeathsByByCatch = 0;
		Globals.USER_PANEL.setNumberOfBirths(numBirths);
		Globals.USER_PANEL.setNumberOfDeaths(numDeaths);
		Globals.USER_PANEL.setNumberOfDeathsByByCatch(numDeathsByByCatch);
		Globals.USER_PANEL.setNumberOfDeathsByOldAge(numDeathsByOldAge);
		Globals.USER_PANEL.setNumberOfDeathsStarvation(numDeathsByStarvation);
	}

}
