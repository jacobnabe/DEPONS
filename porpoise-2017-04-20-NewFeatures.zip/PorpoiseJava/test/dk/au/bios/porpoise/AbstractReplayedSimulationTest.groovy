/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise;

import static org.junit.Assert.*
import static spock.util.matcher.HamcrestMatchers.closeTo
import groovy.json.JsonSlurper

import org.junit.BeforeClass
import org.junit.Test

import repast.simphony.context.Context
import repast.simphony.context.DefaultContext
import repast.simphony.engine.environment.DefaultScheduleRunner
import repast.simphony.engine.environment.RunEnvironment
import repast.simphony.engine.environment.RunState
import repast.simphony.engine.environment.Runner
import repast.simphony.engine.schedule.Schedule
import repast.simphony.engine.schedule.ScheduleParameters
import repast.simphony.parameter.ParametersParser
import repast.simphony.random.RandomHelper
import dk.au.bios.porpoise.behavior.RandomSource

/**
 * Unit test for the Porpoise agent.
 */
abstract class AbstractReplayedSimulationTest {

	private Context<Agent> context;
	private Runner testRunner;

//	private Porpoise p;
//	private RandomSource random;

//	private static UnitTestRunner runner;

//	@BeforeClass
	void setupContext(String paramsJson) {
		// Repast initialization
		ParametersParser paramSpecParser = new ParametersParser(new File("PorpoiseJava.rs/parameters.xml"));
		def params = paramSpecParser.getParameters()
		println "RandomSeed: " + params.getInteger("randomSeed");

		def jsonSlurper = new JsonSlurper()
		def jsonParams = jsonSlurper.parseText(paramsJson)
		
		jsonParams.parameters.each {
			params.setValue(it.key, it.value)
		}

		RandomHelper.setSeed(params.getInteger("randomSeed"))
		Schedule schedule = new Schedule();
		this.testRunner = new DefaultScheduleRunner();
		RunEnvironment.init(schedule, testRunner, params, false);

		context = new DefaultContext<>();
		PorpoiseSimBuilder simBuilder = new PorpoiseSimBuilder();
		context = simBuilder.build(context);
		RunState.init().setMasterContext(context);
		
		// The @ScheduledMethod annotation on Porpoise is not automatically processed
		Globals.CONTEXT.getObjects(Porpoise.class).each {
			RunEnvironment.getInstance().getCurrentSchedule().schedule(it)
		}
	}

	void "simulation"(String testDatafileName) {
		def testdata = new File(testDatafileName);
		if (!testdata.exists()) {
			fail("Missing testdata file")
		}
		def jsonSlurper = new JsonSlurper()
		def firstLine = true

		testdata.eachLine { String line -> 
			if (firstLine) {
				setupContext(line)
				firstLine = false
				return
			}
			def porpData = jsonSlurper.parseText(line) 
			if (porpData.tick == null) {
				return;
			}
//			println "tick ${Globals.tick} (${porpData.tick}) - porp ${porpData.porp.id}"
			while (porpData.tick > Globals.tick) {
				RunEnvironment.getInstance().getCurrentSchedule().execute()
			}
//			println "tick ${Globals.tick} (${porpData.tick}) - porp ${porpData.porp.id}"
			
			assert Globals.tick == porpData.tick
			def porp = findPorpoiseById(porpData.porp.id)

			assertEquals("Location X mismatch for porpoise " + porp.id + " at tick " + Globals.tick, porpData.porp.x, porp.getPosition().x, 0.09)
			assertEquals("Location Y mismatch for porpoise " + porp.id + " at tick " + Globals.tick, porpData.porp.y, porp.getPosition().y, 0.09)
			assertEquals("Heading mismatch for porpoise " + porp.id + " at tick " + Globals.tick, porpData.porp.heading, porp.getHeading(), 0.09)
			assertEquals("PrevAngle mismatch for porpoise " + porp.id + " at tick " + Globals.tick, porpData.porp.prevAngle, porp.prevAngle, 0.09)
			assertEquals("prevLogMov mismatch for porpoise " + porp.id + " at tick " + Globals.tick, porpData.porp.prevLogMov, porp.prevLogMov, 0.09)
		}
		
		
	}

	def Porpoise findPorpoiseById(int id) {
		for (porp in Globals.CONTEXT.getObjects(Porpoise.class)) {
			if (porp.id == id) {
				return porp;
			}
		}

		return null;
	}

}
