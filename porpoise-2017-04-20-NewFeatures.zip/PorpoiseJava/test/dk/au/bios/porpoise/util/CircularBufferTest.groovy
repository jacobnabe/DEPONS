/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.util;

import spock.lang.Specification;
import junit.framework.Assert;
import junit.framework.TestCase;

/**
 * Unit test for the CircularBuffer.
 */
public class CircularBufferTest extends Specification {

	def "add"() {
		given:
		CircularBuffer<Integer> buf = new CircularBuffer<Integer>(10);
		
		expect:
		buf.size() == 0

		when:		
		(0..9).each {
			buf.add(it)
			assert buf.size == it + 1
		}
		
		then:
		buf.size() == 10
		buf.get(9) == 0
		buf.get(0) == 9
		
		when:
		buf.add(10)
		
		then:
		buf.size == 10
		buf.get(9) == 1
		buf.get(0) == 10
		(0..9).every {
			buf.size() - it == buf.get(it)
		}
		
 	}

}
