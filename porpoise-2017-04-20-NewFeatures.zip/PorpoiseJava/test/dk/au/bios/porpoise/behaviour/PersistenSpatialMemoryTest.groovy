/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise.behaviour;

import static org.junit.Assert.*
import repast.simphony.context.Context
import repast.simphony.context.DefaultContext
import repast.simphony.context.space.continuous.ContinuousSpaceFactoryFinder
import repast.simphony.context.space.grid.GridFactoryFinder
import repast.simphony.engine.environment.RunEnvironment
import repast.simphony.engine.environment.RunState
import repast.simphony.engine.schedule.Schedule
import repast.simphony.space.continuous.BouncyBorders
import repast.simphony.space.continuous.NdPoint
import repast.simphony.space.continuous.RandomCartesianAdder
import repast.simphony.space.grid.GridBuilderParameters
import repast.simphony.space.grid.SimpleGridAdder
import spock.lang.Shared;
import spock.lang.Specification
import dk.au.bios.porpoise.Agent
import dk.au.bios.porpoise.CellDataTestData
import dk.au.bios.porpoise.Globals
import dk.au.bios.porpoise.Porpoise
import dk.au.bios.porpoise.behavior.FastRefMemTurn
import dk.au.bios.porpoise.behavior.PersistentSpatialMemory
import dk.au.bios.porpoise.behavior.RandomSource


/**
 * Unit test for the PersistentSpatialMemory.
 */
class PersistenSpatialMemoryTest extends Specification {

	private static Context<Agent> context;
	private static Schedule schedule;
	private static RandomSource random;
	
	def setupSpec() {
		Globals.WORLD_WIDTH = 100;
		Globals.WORLD_HEIGHT = 100;
		Globals.PSM_PREFERRED_DISTANCE_TOLERANCE = 10; 

		random = Mock(RandomSource)
		random.nextNormal_0_38() >>> [0.0]
		random.nextNormal_96_28() >>> [0.0]
		random.nextStdMove() >>> [0.0]
		random.nextNormal_42_48() >>> [0.0]
		Globals.RANDOM_SOURCE = random

		// Repast initialization
		schedule = new Schedule();
		RunEnvironment.init(schedule, null, null, true);
		context = new DefaultContext<>();
		RunState.init().setMasterContext(context);
	}

	def "Find Most Attractive MemCell"() {
		given: "A clear Persistent Spatial Memory"
		def factory = ContinuousSpaceFactoryFinder.createContinuousSpaceFactory(null)
		def space = factory.createContinuousSpace("space", context, new RandomCartesianAdder<Agent>(), new BouncyBorders(), [Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT] as double[], [0.5f, 0.5f] as double[])
		def gridFactory = GridFactoryFinder.createGridFactory(null);
		def grid = gridFactory.createGrid("grid", context, new GridBuilderParameters<Agent>(new repast.simphony.space.grid.BouncyBorders(), new SimpleGridAdder<Agent>(), true, Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT));
		def cellData = CellDataTestData.getCellData();
		def p = new Porpoise(space, grid, cellData, context, 1, new FastRefMemTurn())
		context.add(p);
		p.setPosition(new NdPoint(50.0, 50.0));
		p.setHeading(0.0);
		p.moveAwayFromLand();  // Weird side-effect here, updating the initial poslist
		
		assert p.getPosition() == new NdPoint(50.0f, 50.0f)
		assert p.getHeading() == 0.0
		assert p.getAge() == 1
		def psm = new PersistentSpatialMemory(p, Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT, cellData, 10);


		when: "the PSM is deactivated"
		psm.active = false
		then: "the PSM is not active"
		!psm.active

		when: "the PSM is activated"
		psm.active = true
		then: "the PSM is active"
		psm.active

		when: "the PSM is first updated"
		(1..20).each { it -> 
			psm.updateMemory(new NdPoint((double)it * 5, 0.0), 1.0f);
			psm.updateMemory(new NdPoint((double)it * 5, 5.0), 1.0f);
			psm.updateMemory(new NdPoint((double)it * 5, 10.0), 1.0f);
			psm.updateMemory(new NdPoint((double)it * 5, 15.0), 1.0f);
			psm.updateMemory(new NdPoint((double)it * 5, 20.0), 1.0f);
			psm.updateMemory(new NdPoint((double)it * 5, 25.0), 1.0f);
			psm.updateMemory(new NdPoint((double)it * 5, 30.0), 1.0f);
			psm.updateMemory(new NdPoint((double)it * 5, 35.0), 1.0f);
			psm.updateMemory(new NdPoint((double)it * 5, 40.0), 1.0f);
			psm.updateMemory(new NdPoint((double)it * 5, 45.0), 1.0f);
			psm.updateMemory(new NdPoint((double)it * 5, 50.0), 1.0f);
			psm.updateMemory(new NdPoint((double)it * 5, 55.0), 1.0f);
			psm.updateMemory(new NdPoint((double)it * 5, 60.0), 1.0f);
			psm.updateMemory(new NdPoint((double)it * 5, 65.0), 1.0f);
			psm.updateMemory(new NdPoint((double)it * 5, 70.0), 1.0f);
			psm.updateMemory(new NdPoint((double)it * 5, 75.0), 1.0f);
			psm.updateMemory(new NdPoint((double)it * 5, 80.0), 1.0f);
			psm.updateMemory(new NdPoint((double)it * 5, 85.0), 1.0f);
			psm.updateMemory(new NdPoint((double)it * 5, 90.0), 1.0f);
			psm.updateMemory(new NdPoint((double)it * 5, 95.0), 1.0f);
		}
		
		psm.updateMemory(new NdPoint(50.0f, 50.0f), 100.0f);
		then: "the most attractive cell is 210"
		psm.findMostAttractiveMemCell() == 210
	}

	def "testCalculateMemCellNumber"() {
		def final expectedCell = 210;

		given:
		def psm = new PersistentSpatialMemory(null, 100, 100, null, 10);

		expect:
		expectedCell == psm.calculateMemCellNumber(new NdPoint(50.0f, 50.0f))

		and: "NdPoint in same memory cell (5x5)"
		expectedCell == psm.calculateMemCellNumber(new NdPoint(50.0f, 50.0f))
		expectedCell == psm.calculateMemCellNumber(new NdPoint(50.0f, 54.49f))
		expectedCell == psm.calculateMemCellNumber(new NdPoint(49.5f, 50.0f))
		expectedCell == psm.calculateMemCellNumber(new NdPoint(49.5f, 54.49f))

		and:  "NdPoint outside memory cell"
		expectedCell != psm.calculateMemCellNumber(new NdPoint(47.0f, 50.0f))
		expectedCell != psm.calculateMemCellNumber(new NdPoint(49.49f, 50.0f))
		expectedCell != psm.calculateMemCellNumber(new NdPoint(47.0f, 50.0f))
		expectedCell != psm.calculateMemCellNumber(new NdPoint(47.0f, 50.0f))
	}


	def "Random Source"() {
		given: "Controlled randomness"
		def rando = Mock(RandomSource)
		rando.nextEnergyNormal() >>> [0.01f, 0.25f]

		expect: "Getting first random"
		rando.nextEnergyNormal() == 0.01f;
		rando.nextEnergyNormal() == 0.25f;
	}

}
