/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise;

import static org.junit.Assert.*
import static spock.util.matcher.HamcrestMatchers.closeTo
import groovy.json.JsonSlurper

import org.junit.BeforeClass
import org.junit.Test

import repast.simphony.context.Context
import repast.simphony.context.DefaultContext
import repast.simphony.engine.environment.DefaultScheduleRunner
import repast.simphony.engine.environment.RunEnvironment
import repast.simphony.engine.environment.RunState
import repast.simphony.engine.environment.Runner
import repast.simphony.engine.schedule.Schedule
import repast.simphony.engine.schedule.ScheduleParameters
import repast.simphony.parameter.ParametersParser
import repast.simphony.random.RandomHelper
import spock.lang.Unroll;
import dk.au.bios.porpoise.behavior.RandomSource
import dk.au.bios.porpoise.util.test.PorpoiseTestDataCapturer;

/**
 * Unit test for the Porpoise agent.
 */
class ReplayedSimulationTest2 extends AbstractReplayedSimulationTest {

	@Test
	void "DanTysk PSM Turbines 1 Porpoise"() {
//PorpoiseTestDataCapturer.capture = true;
//PorpoiseTestDataCapturer.tickMod = 1;
////PorpoiseTestDataCapturer.tickStartCapture = 40000;
////PorpoiseTestDataCapturer.tickEndCapture = 42010;
//PorpoiseTestDataCapturer.includePosList = false;

//		simulation("test/dk/au/bios/porpoise/testdata_DanTysk_PSM_Turbines_10porp.txt")
//		simulation("test/dk/au/bios/porpoise/testdata_DanTysk_PSM_Turbines.txt")
//		simulation("test/dk/au/bios/porpoise/testdata_DanTysk_DispOff_Turbines_10porp.txt");
//		simulation("test/dk/au/bios/porpoise/testdata_DanTysk_PSM_NoTurbines_10porp_5ksteps.txt")
//		simulation("test/dk/au/bios/porpoise/testdata_NorthSea_PSM_NoTurbines.txt")
		simulation("test/dk/au/bios/porpoise/testdata_NorthSea_PSM_Turbines.txt")
//		simulation("test/dk/au/bios/porpoise/testdata_NorthSea_PSM_NoTurbines_10porp_5ksteps.txt")
	}

}
