/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise;

import static org.junit.Assert.*
import static spock.util.matcher.HamcrestMatchers.closeTo
import groovy.json.JsonSlurper

import org.junit.BeforeClass
import org.junit.Test

import repast.simphony.context.Context
import repast.simphony.context.DefaultContext
import repast.simphony.engine.environment.DefaultScheduleRunner
import repast.simphony.engine.environment.RunEnvironment
import repast.simphony.engine.environment.RunState
import repast.simphony.engine.environment.Runner
import repast.simphony.engine.schedule.Schedule
import repast.simphony.engine.schedule.ScheduleParameters
import repast.simphony.parameter.ParametersParser
import repast.simphony.random.RandomHelper
import dk.au.bios.porpoise.behavior.RandomSource
import dk.au.bios.porpoise.util.test.PorpoiseTestDataCapturer;

PorpoiseTestDataCapturer.capture = true;
PorpoiseTestDataCapturer.tickMod = 1;
//PorpoiseTestDataCapturer.tickStartCapture = 40000;
//PorpoiseTestDataCapturer.tickEndCapture = 42010;
PorpoiseTestDataCapturer.includePosList = false;

// Repast initialization
ParametersParser paramSpecParser = new ParametersParser(new File("PorpoiseJava.rs/parameters.xml"));
def params = paramSpecParser.getParameters()

RandomHelper.setSeed(params.getInteger("randomSeed"))
Schedule schedule = new Schedule();
Runner testRunner = new DefaultScheduleRunner();
RunEnvironment.init(schedule, testRunner, params, false);

Context<Agent> context = new DefaultContext<>();
PorpoiseSimBuilder simBuilder = new PorpoiseSimBuilder();
context = simBuilder.build(context);
RunState.init().setMasterContext(context);

// The @ScheduledMethod annotation on Porpoise is not automatically processed
Globals.CONTEXT.getObjects(Porpoise.class).each {
	RunEnvironment.getInstance().getCurrentSchedule().schedule(it)
}

(0..5000).each {
	RunEnvironment.getInstance().getCurrentSchedule().execute()
	println "tick ${Globals.tick}"
} 
