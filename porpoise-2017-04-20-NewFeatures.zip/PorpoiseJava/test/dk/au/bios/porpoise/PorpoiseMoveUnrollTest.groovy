/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise;

import static org.junit.Assert.*
import static spock.util.matcher.HamcrestMatchers.closeTo
import repast.simphony.context.Context
import repast.simphony.context.DefaultContext
import repast.simphony.context.space.continuous.ContinuousSpaceFactoryFinder
import repast.simphony.context.space.grid.GridFactoryFinder
import repast.simphony.engine.environment.RunEnvironment
import repast.simphony.engine.environment.RunState
import repast.simphony.engine.schedule.Schedule
import repast.simphony.engine.schedule.ScheduleParameters
import repast.simphony.space.continuous.BouncyBorders
import repast.simphony.space.continuous.NdPoint
import repast.simphony.space.continuous.RandomCartesianAdder
import repast.simphony.space.grid.GridBuilderParameters
import repast.simphony.space.grid.SimpleGridAdder
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Unroll;
import dk.au.bios.porpoise.behavior.FastRefMemTurn;
import dk.au.bios.porpoise.behavior.RandomSource

/**
 * Unit test for the Porpoise agent.
 */
class PorpoiseMoveUnrollTest extends Specification {

	@Shared private Context<Agent> context;
	@Shared private Schedule schedule;

	@Shared Porpoise p;
	@Shared RandomSource random;
	
	def setupSpec() {
		Globals.WORLD_WIDTH = 100;
		Globals.WORLD_HEIGHT = 100;
		Globals.MODEL = 4;

		random = Mock(RandomSource)
		random.nextNormal_0_38() >>> [0.0]
		random.nextNormal_96_28() >>> [0.0]
		random.nextStdMove() >>> [0.0]
		random.nextNormal_42_48() >>> [0.0]
		Globals.RANDOM_SOURCE = random

		// Repast initialization
		this.schedule = new Schedule();
		RunEnvironment.init(schedule, null, null, true);
		context = new DefaultContext<>();
		RunState.init().setMasterContext(context);

		def factory = ContinuousSpaceFactoryFinder.createContinuousSpaceFactory(null)
		def space = factory.createContinuousSpace("space", context, new RandomCartesianAdder<Agent>(), new BouncyBorders(), [Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT] as double[], [0.5f, 0.5f] as double[])
		def gridFactory = GridFactoryFinder.createGridFactory(null);
		def grid = gridFactory.createGrid("grid", context, new GridBuilderParameters<Agent>(new repast.simphony.space.grid.BouncyBorders(), new SimpleGridAdder<Agent>(), true, Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT));
		def cellData = CellDataTestData.getCellData();

		p = new Porpoise(space, grid, cellData, context, 1, new FastRefMemTurn())
		context.add(p);
		p.setPosition(new NdPoint(10.0, 10.0));
		p.setHeading(0.0);
		p.moveAwayFromLand();  // Weird side-effect here, updating the initial poslist
		
		assert p.getPosition() == new NdPoint(10.0f, 10.0f)
		assert p.getHeading() == 0.0
		assert p.getAge() == 1
	}

	@Unroll
	def "movement without dispersal - #tick"() {
		when:
		p.move()
		
		then:
		new Double(x) closeTo(p.getPosition().x, 0.009)
		new Double(y) closeTo(p.getPosition().y, 0.009)
		new Double(heading) closeTo(p.getHeading(), 0.009)
		new Double(prevAngle) closeTo(p.prevAngle, 0.009)
		new Double(prevLogMov) closeTo(p.prevLogMov, 0.009)
		0.0 == p.presAngle
		0.0 == p.deterStrength
		p.enoughWaterAhead
		p.tickMoveAdjustMultiplier == 0.0  // Used up all movement for this tick
		
		where:
		tick |      x |       y |  heading | prevAngle | prevLogMov
		   1 |   9.78 |   11.39 |   351.16 |   (-8.84) |       0.75
		   2 |   9.77 |   12.67 |   359.70 |      8.54 |       0.71
		   3 |   9.60 |   13.81 |   351.24 |   (-8.46) |       0.66
		   4 |   9.59 |   14.86 |   359.68 |      8.44 |       0.62
		   5 |   9.45 |   15.82 |   351.24 |   (-8.43) |       0.59
		   6 |   9.45 |   16.71 |   359.68 |      8.43 |       0.55
		   7 |   9.32 |   17.52 |   351.24 |   (-8.43) |       0.52
		   8 |   9.31 |   18.29 |   359.68 |      8.43 |       0.49
		   9 |   9.20 |   19.00 |   351.24 |   (-8.43) |       0.46
		  10 |   9.20 |   19.68 |   359.68 |      8.43 |       0.43
	}

}
