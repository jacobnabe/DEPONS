/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise;

import java.util.Arrays;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * Unit tests for CellData.
 */
public class CellDataTestData {

	private static class TestDataFuture<D> implements Future<D> {

		private D data;

		public TestDataFuture(D data) {
			this.data = data;
		}

		@Override
		public boolean cancel(boolean mayInterruptIfRunning) {
			return false;
		}

		@Override
		public boolean isCancelled() {
			return false;
		}

		@Override
		public boolean isDone() {
			return true;
		}

		@Override
		public D get() throws InterruptedException, ExecutionException {
			return data;
		}

		@Override
		public D get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
			return data;
		}

	}

	public static CellData getCellData() throws Exception {
		CellData cellData = new CellData(getDistanceToCoast(), getDepth(), getBlocks(), getFoodProb(), getQuarter(),
				getQuarter(), getQuarter(), getQuarter(), false, null, false);
		return cellData;
	}

	public static Future<double[][]> getDistanceToCoast() {
		return fillArray(10000.0);
	}

	public static Future<double[][]> getDepth() {
		return fillArray(18.10);
	}

	public static Future<double[][]> getBlocks() {
		return fillArray(1.0);
	}

	public static Future<double[][]> getFoodProb() {
		return fillArray(1.0);
	}

	public static Future<double[][]> getQuarter() {
		return fillArray(0.386);
	}

	private static Future<double[][]> fillArray(double value) {
		double[][] data = new double[100][100];
		for (double[] ds : data) {
			Arrays.fill(ds, value);
		}

		return new TestDataFuture<double[][]>(data);
	}

}
