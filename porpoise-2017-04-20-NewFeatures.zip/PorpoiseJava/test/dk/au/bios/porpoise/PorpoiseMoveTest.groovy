/*
 * Copyright (C) 2017 Jacob Nabe-Nielsen <jnn@bios.au.dk>
 *
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License version 2 and only 
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dk.au.bios.porpoise;

import static org.junit.Assert.*
import static spock.util.matcher.HamcrestMatchers.closeTo
import repast.simphony.context.Context
import repast.simphony.context.DefaultContext
import repast.simphony.context.space.continuous.ContinuousSpaceFactoryFinder
import repast.simphony.context.space.grid.GridFactoryFinder
import repast.simphony.engine.environment.RunEnvironment
import repast.simphony.engine.environment.RunState
import repast.simphony.engine.schedule.Schedule
import repast.simphony.engine.schedule.ScheduleParameters
import repast.simphony.space.continuous.BouncyBorders
import repast.simphony.space.continuous.NdPoint
import repast.simphony.space.continuous.RandomCartesianAdder
import repast.simphony.space.grid.GridBuilderParameters
import repast.simphony.space.grid.SimpleGridAdder
import spock.lang.Shared
import spock.lang.Specification
import dk.au.bios.porpoise.behavior.FastRefMemTurn;
import dk.au.bios.porpoise.behavior.RandomSource

/**
 * Unit test for the Porpoise agent.
 */
class PorpoiseMoveTest extends Specification {

	private Context<Agent> context;
	private Schedule schedule;

	def setupSpec() {
		Globals.WORLD_WIDTH = 100;
		Globals.WORLD_HEIGHT = 100;
		Globals.MODEL = 4;
	}

	def setup() {
		// Repast initialization
		this.schedule = new Schedule();
		RunEnvironment.init(schedule, null, null, true);
		context = new DefaultContext<>();
		RunState.init().setMasterContext(context);
	}

	def "movement without dispersal"() {
		given: "test has been set up"
		def factory = ContinuousSpaceFactoryFinder.createContinuousSpaceFactory(null)
		def space = factory.createContinuousSpace("space", context, new RandomCartesianAdder<Agent>(), new BouncyBorders(), [Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT] as double[], [0.5f, 0.5f] as double[])
		def gridFactory = GridFactoryFinder.createGridFactory(null);
		def grid = gridFactory.createGrid("grid", context, new GridBuilderParameters<Agent>(new repast.simphony.space.grid.BouncyBorders(), new SimpleGridAdder<Agent>(), true, Globals.WORLD_WIDTH, Globals.WORLD_HEIGHT));
		def cellData = CellDataTestData.getCellData();

		and: "no randomness"
		def random = Mock(RandomSource)
		random.nextNormal_0_38() >>> [0.0]
		random.nextNormal_96_28() >>> [0.0]
		random.nextStdMove() >>> [0.0]
		random.nextNormal_42_48() >>> [0.0]
		Globals.RANDOM_SOURCE = random

		and: "a porpoise at 10,10 heading north"
		def p = new Porpoise(space, grid, cellData, context, 1, new FastRefMemTurn())
		context.add(p);
		p.setPosition(new NdPoint(10.0, 10.0));
		p.setHeading(0.0);
		p.moveAwayFromLand();  // Weird side-effect here, updating the initial poslist

		expect: "the porpoise at 10,10 heading north"
		p.getPosition() == new NdPoint(10.0f, 10.0f)
		p.getHeading() == 0.0
		p.getAge() == 1

		when: "moving one step"
		p.move()

		then: "new location"
		9.78 closeTo(p.getPosition().x, 0.009)
		11.39 closeTo(p.getPosition().y, 0.009)
		351.16 closeTo(p.getHeading(), 0.009)
		(-8.84) closeTo(p.prevAngle, 0.009)
		0.0 closeTo(p.presAngle, 0.009)
		
		when: "moving another step"
		p.move()
		
		then:
		9.77 closeTo(p.getPosition().x, 0.009)
		12.67 closeTo(p.getPosition().y, 0.009)
		359.70 closeTo(p.getHeading(), 0.009)
		8.54 closeTo(p.prevAngle, 0.009)
		0.0 closeTo(p.presAngle, 0.009)

		when: "moving 10 steps"
		10.times({ p.move() })

		then:
		9.10 closeTo(p.getPosition().x, 0.009)
		20.91 closeTo(p.getPosition().y, 0.009)
		359.68 closeTo(p.getHeading(), 0.009)
		8.43 closeTo(p.prevAngle, 0.009)
		0.0 closeTo(p.presAngle, 0.009)
		
/*		10.times({
			when:
			p.move()
			
			then:
			assert p.getPosition().x == 0
			
		}) */
	}

}
